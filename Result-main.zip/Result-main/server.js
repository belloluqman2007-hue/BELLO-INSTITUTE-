require("dotenv").config();
const helmet = require("helmet");

// NEW (Pack 63): Global Crash Shield - prevents Node.js from exiting on unhandled errors
process.on("uncaughtException", (err) => {
    console.error("Uncaught Exception caught:", err);
});
process.on("unhandledRejection", (reason, promise) => {
    console.error("Unhandled Rejection caught:", reason);
});

const express = require("express");
const path = require("path");
const multer = require("multer");
// RAM optimisation for Render free tier: XLSX is ~40 MB when loaded eagerly.
// Using a lazy getter means it only loads the first time an import/export
// route is actually called, not on every server start.
let _XLSX = null;
const XLSX = new Proxy({}, {
    get: function(_, prop) {
        if (!_XLSX) _XLSX = require("xlsx");
        return _XLSX[prop];
    }
});
const fs = require("fs");
const session = require("express-session");
const bcrypt = require("bcryptjs");
const connection = require("./db");

// NEW (Third Term Results feature): pure parser/export-builder for the
// school's internal grade workbook (one sheet per class). The module
// lazy-loads XLSX itself, so this require stays cheap at boot.
const thirdTermParser = require("./third-term-parser");

const app = express();
app.use(helmet({
    contentSecurityPolicy: false,
    crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: "25mb" })); // 25mb: Third Term Results export posts every parsed class back for the Excel builder
// Accept classic HTML form posts too, in case any page submits without JS.
app.use(express.urlencoded({ extended: true }));

/* ======================================================================
   SEO: one public URL to rule them all (canonical fix)
   ----------------------------------------------------------------------
   The app is deployed on TWO platforms running the SAME code:
     - Render:  https://result-cfn8.onrender.com/
     - Railway: https://result-production-69ea.up.railway.app/
   Google Search Console showed one deployment was not being indexed
   because the <link rel="canonical"> in index.html hardcoded the OTHER
   deployment's domain. The fix (all overridable via environment vars):
     1. index.html now carries __AMS_SITE_URL__ placeholders (canonical,
        og:url, og:image, twitter:image, JSON-LD) that this server
        rewrites to the correct base URL before the page is sent.
     2. robots.txt and sitemap.xml are generated per request with the
        same base (the old files hardcoded the Railway domain).
     3. Any browser/crawler page navigation that arrives at the
        NON-primary deployment gets a 301 redirect to the primary one,
        so Google only ever indexes a single site.
   Override on whichever platform you want as the canonical one:
     SITE_URL=https://result-cfn8.onrender.com   (explicit public base)
     PRIMARY_HOST=result-cfn8.onrender.com       (301 target host)
     AMS_CANONICAL_REDIRECT=off                  (disable the 301)
   ====================================================================== */
const AMS_KNOWN_PUBLIC_HOSTS = [
    "result-cfn8.onrender.com",
    "result-production-69ea.up.railway.app"
];
function amsPrimaryHost() {
    const fromEnv = String(process.env.PRIMARY_HOST || "").trim()
        .replace(/^https?:\/\//, "").replace(/\/.*$/, "").toLowerCase();
    return fromEnv || "result-cfn8.onrender.com"; // default: Render is the indexed domain
}
function amsRequestHost(req) {
    return String(req.headers.host || "").split(":")[0].trim().toLowerCase();
}
/* Base public URL used for canonical/OG/sitemap: an explicit SITE_URL
   env var wins; for the known public hosts we ALWAYS answer with the
   primary host (never self-canonicalize the non-primary deployment);
   unknown hosts (local development) fall back to the request's own
   host so localhost previews still work. */
function amsSiteBase(req) {
    const explicit = String(process.env.SITE_URL || "").trim().replace(/\/+$/, "");
    if (explicit) return explicit;
    const host = amsRequestHost(req);
    if (host && AMS_KNOWN_PUBLIC_HOSTS.indexOf(host) !== -1) {
        return "https://" + amsPrimaryHost();
    }
    // Local development (localhost / 127.0.0.1): keep scheme + port so
    // the canonical matches the address in the browser's bar.
    if (host === "localhost" || host === "127.0.0.1" || host === "::1") {
        return "http://" + String(req.headers.host || "localhost:3000");
    }
    return "https://" + (host || amsPrimaryHost());
}
function amsIndexHtml(req, res) {
    fs.readFile(path.join(__dirname, "index.html"), "utf8", (err, html) => {
        if (err) return res.status(500).send("Failed to load the website.");
        res.type("html");
        // no-cache: a canonical change must reach crawlers immediately.
        res.set("Cache-Control", "no-cache");
        res.send(html.split("__AMS_SITE_URL__").join(amsSiteBase(req)));
    });
}

// 301: page navigations that arrive at the non-primary deployment jump
// to the primary one (same path + query preserved). Only real HTML
// requests are redirected - crawlers and browsers navigating; API and
// asset fetches keep working on either host so nothing breaks.
app.use((req, res, next) => {
    if (String(process.env.AMS_CANONICAL_REDIRECT || "").toLowerCase() === "off") return next();
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    const host = amsRequestHost(req);
    if (!host || AMS_KNOWN_PUBLIC_HOSTS.indexOf(host) === -1) return next();
    if (host === amsPrimaryHost()) return next();
    if (String(req.headers.accept || "").indexOf("text/html") === -1) return next();
    res.redirect(301, "https://" + amsPrimaryHost() + req.originalUrl);
});

// NEW (Pack 54/55 + canonical fix): Explicit high-priority SEO routes for
// Google crawler & Search Console - the Sitemap line now always points
// at the primary public URL instead of a hardcoded domain.
app.get("/robots.txt", (req, res) => {
    res.type("text/plain");
    res.send("User-agent: Googlebot\nAllow: /\nDisallow: /api/\nDisallow: /sql/\n\nUser-agent: *\nAllow: /\nDisallow: /api/\nDisallow: /sql/\n\nSitemap: " + amsSiteBase(req) + "/sitemap.xml\n");
});

app.get("/sitemap.xml", (req, res) => {
    res.type("application/xml");
    res.set("Cache-Control", "no-cache");
    res.send(
        '<?xml version="1.0" encoding="UTF-8"?>\n' +
        "<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n" +
        "  <url>\n" +
        "    <loc>" + amsSiteBase(req) + "/</loc>\n" +
        "    <lastmod>2026-08-23</lastmod>\n" +
        "    <changefreq>weekly</changefreq>\n" +
        "    <priority>1.0</priority>\n" +
        "  </url>\n" +
        "</urlset>\n"
    );
});

const isProduction = process.env.NODE_ENV === "production";

// Railway (and most hosting platforms) sit your app behind a proxy that
// terminates HTTPS before forwarding to your app over plain HTTP. Without
// this, Express never recognizes the connection as secure, so a
// secure-only session cookie silently fails to persist - causing an
// infinite bounce back to the login page after a successful login.
if (isProduction) {
    app.set("trust proxy", 1);
}

if (!process.env.SESSION_SECRET) {
    console.log("WARNING: SESSION_SECRET is not set in your environment. Using an insecure default - fine for local development, but you MUST set a real SESSION_SECRET before deploying this online.");
}

/* NEW (pack 25 - owner: "Build it that it will accept 1000 users and
   will not collapse"): the default session store keeps every login in
   PROCESS MEMORY - it warns in production and grows without limit with
   hundreds of parents/staff. Sessions now live in a MySQL table
   (survives restarts too). Express-session Store contract, no new
   packages needed. */
class MySqlSessionStore extends session.Store {
    constructor(db) {
        super();
        this.db = db;
        this.tableReady = false;
        this.ready = new Promise((resolve) => {
            db.query(
                `CREATE TABLE IF NOT EXISTS app_sessions (
                    sid VARCHAR(128) PRIMARY KEY,
                    sess MEDIUMTEXT NOT NULL,
                    expires_at BIGINT NOT NULL,
                    INDEX (expires_at)
                )`,
                () => { this.tableReady = true; resolve(); }
            );
        });
        setInterval(() => {
            if (!this.tableReady) return;
            db.query("DELETE FROM app_sessions WHERE expires_at < ?", [Date.now()], () => {});
        }, 1000 * 60 * 60).unref(); // hourly sweep of expired rows
    }
    whenReady(cb) {
        if (this.tableReady) return cb();
        this.ready.then(cb);
    }
    get(sid, cb) {
        this.whenReady(() => {
            this.db.query("SELECT sess, expires_at FROM app_sessions WHERE sid = ?", [sid], (err, rows) => {
                if (err) return cb(null, null); // read hiccup -> treat as logged out, never crash
                if (!rows || !rows.length) return cb(null, null);
                if (rows[0].expires_at && rows[0].expires_at < Date.now()) {
                    return this.destroy(sid, () => cb(null, null));
                }
                try { cb(null, JSON.parse(rows[0].sess)); } catch (e) { cb(null, null); }
            });
        });
    }
    set(sid, sess, cb) {
        const maxAge = (sess.cookie && sess.cookie.maxAge) || (1000 * 60 * 60 * 8);
        const expires = Date.now() + maxAge;
        const data = JSON.stringify(sess);
        this.whenReady(() => {
            this.db.query(
                "INSERT INTO app_sessions (sid, sess, expires_at) VALUES (?,?,?) ON DUPLICATE KEY UPDATE sess = VALUES(sess), expires_at = VALUES(expires_at)",
                [sid, data, expires],
                (err) => cb && cb(err)
            );
        });
    }
    destroy(sid, cb) {
        this.whenReady(() => {
            this.db.query("DELETE FROM app_sessions WHERE sid = ?", [sid], (err) => cb && cb(err));
        });
    }
    touch(sid, sess, cb) {
        const maxAge = (sess.cookie && sess.cookie.maxAge) || (1000 * 60 * 60 * 8);
        this.whenReady(() => {
            this.db.query("UPDATE app_sessions SET expires_at = ? WHERE sid = ?", [Date.now() + maxAge, sid], (err) => cb && cb(err));
        });
    }
}
const sessionStore = new MySqlSessionStore(connection);

// SECURITY: in production a real SESSION_SECRET must be provided. The insecure
// dev fallback below is ONLY tolerated when NODE_ENV is not "production" - a
// predictable secret would let anyone forge session cookies.
if (isProduction && !process.env.SESSION_SECRET) {
    console.error(
        "FATAL: SESSION_SECRET is not set but NODE_ENV=production. Refusing to start " +
        "with the insecure development secret. Generate one with:\n" +
        "  node -e \"console.log(require('crypto').randomBytes(48).toString('hex'))\""
    );
    process.exit(1);
}

app.use(session({
    secret: process.env.SESSION_SECRET || "local-dev-only-insecure-secret-change-me",
    store: sessionStore, // pack 25: MySQL-backed sessions
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 1000 * 60 * 60 * 8, // 8 hour session
        secure: isProduction, // only send cookie over HTTPS in production
        httpOnly: true
    }
}));

// SECURITY: CSRF protection via double-submit cookie (csrf-csrf, Express 5 compatible)
// Uses SESSION_SECRET as the signing secret. Issues token via /api/csrf-token.
// Validates all state-changing POST/PUT/DELETE except login/portal-login/logout.
const crypto = require("crypto");

// Simple session-based CSRF - no external package needed
app.get("/api/csrf-token", (req, res) => {
    try {
        if (!req.session) {
            return res.status(500).json({ error: "Session not available" });
        }
        if (!req.session.csrfToken) {
            req.session.csrfToken = crypto.randomBytes(32).toString("hex");
        }
        res.json({ csrfToken: req.session.csrfToken });
    } catch (e) {
        console.error("CSRF ERROR:", e.message, e.stack);
        res.status(500).json({ error: e.message });
    }
});
function csrfMiddleware(req, res, next) {
    const exempt = ["/login", "/portal-login", "/logout", "/api/csrf-token"];
    if (exempt.includes(req.path)) return next();
    if (!["POST", "PUT", "DELETE", "PATCH"].includes(req.method)) return next();
    const token = req.headers["x-csrf-token"];
    if (!token || token !== req.session.csrfToken) {
        return res.status(403).json({ message: "Invalid CSRF token. Please refresh the page and try again." });
    }
    next();
}
app.use(csrfMiddleware);
// SECURITY: Rate limiting for sensitive write APIs (same in-memory bucket pattern as login)
const WRITE_MAX_ATTEMPTS = 30;
const WRITE_WINDOW_MS = 15 * 60 * 1000;
const writeHits = Object.create(null);
setInterval(function () {
    const now = Date.now();
    Object.keys(writeHits).forEach(function (k) { if (writeHits[k].resetAt < now) delete writeHits[k]; });
}, 600000).unref();
function writeRateLimit(req, res, next) {
    const ip = req.ip || (req.connection && req.connection.remoteAddress) || "?";
    const now = Date.now();
    let bucket = writeHits[ip];
    if (!bucket || bucket.resetAt < now) bucket = writeHits[ip] = { count: 0, resetAt: now + WRITE_WINDOW_MS };
    if (++bucket.count > WRITE_MAX_ATTEMPTS) {
        const waitMin = Math.max(1, Math.ceil((bucket.resetAt - now) / 60000));
        return res.status(429).json({ message: "Too many requests. Please try again in about " + waitMin + " minute(s)." });
    }
    next();
}

// Auth guard: blocks access to protected pages/routes if not logged in
function requireLogin(req, res, next) {
    if (req.session && req.session.userId) {
        return next();
    }
    // For page requests, redirect to login. For API requests, send 401.
    if (req.headers.accept && req.headers.accept.includes("text/html")) {
        return res.redirect("/login.html");
    }
    return res.status(401).json({ message: "Not logged in" });
}

// Auth guard for admin-only actions
function requireAdmin(req, res, next) {
    if (req.session && req.session.role === "admin") {
        return next();
    }
    return res.status(403).json({ message: "Admin access required" });
}


/* =====================================================================
   NEW (pack 13 - Student/Parent portal + publish gate, owner request)
   ---------------------------------------------------------------------
   "The result can show to student or parents except it is been publish
   by admin". STAFF behaviour is 100% UNCHANGED (they skip every gate).
   Everyone else must log in with Student ID + surname, may view ONLY
   their own child, and ONLY terms an admin has published.
   ===================================================================== */
/* FIX (pack 84): published results were invisible to students after
   admin published them. Causes:
     1) JOIN collation clash (results vs result_publish) -> 500 -> empty list
     2) class on the RESULT (when scores were entered) != current class
        after promotion, so the gate / list missed the row
     3) Arabic tashkeel / extra spaces on class names
   Matching is now done in JS against ALL published rows (no JOIN),
   and ANY of: whole-term publish, result class, current class. */
function normalizeClassName(s) {
    return String(s || "")
        .trim()
        .toLowerCase()
        .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u0640]/g, "")
        .replace(/\s+/g, " ");
}
function classNamesMatch(a, b) {
    return normalizeClassName(a) === normalizeClassName(b);
}
function isTermPublished(pubRows, term, session, className) {
    const nt = String(term || "").trim().toLowerCase();
    const ns = String(session || "").trim().toLowerCase();
    return (pubRows || []).some((r) => {
        if (Number(r.published) !== 1) return false;
        if (String(r.term || "").trim().toLowerCase() !== nt) return false;
        if (String(r.session || "").trim().toLowerCase() !== ns) return false;
        const cn = String(r.class_name || "").trim();
        if (!cn) return true; // whole-term switch
        return classNamesMatch(cn, className);
    });
}
function checkPublished(className, term, schoolSession, cb) {
    checkPublishedAny([className], term, schoolSession, cb);
}
function checkPublishedAny(classNames, term, schoolSession, cb) {
    connection.query(
        "SELECT class_name, term, session, published FROM result_publish WHERE published = 1",
        (err, rows) => {
            if (err) return cb(err);
            const list = (classNames || []).filter((c) => String(c || "").trim());
            const ok = isTermPublished(rows, term, schoolSession, "")
                || list.some((cn) => isTermPublished(rows, term, schoolSession, cn));
            cb(null, ok);
        }
    );
}

// Owner-only gate (basic records: student info / position). Staff skip it.
function portalOwnerGate(req, res, next) {
    if (req.session && req.session.userId) return next(); // staff: untouched
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(403).json({ message: "Please log in as a student or parent first." });
    // FIX (pack 13): compare trimmed + case-insensitively ('AM' vs 'Am ')
    if (String(sid).trim().toLowerCase() !== String(req.params.studentId).trim().toLowerCase()) {
        return res.status(403).json({ message: "You can only view your own child's record." });
    }
    next();
}

// Result gate (score sheets). Staff skip it; portal users need OWN child
// + a published term/session.
function publishResultGate(req, res, next) {
    if (req.session && req.session.userId) return next(); // staff: FULL old behaviour
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(403).json({ message: "Please log in as a student or parent to check results." });
    // FIX (pack 13): compare trimmed + case-insensitively ('AM' vs 'Am ')
    if (String(sid).trim().toLowerCase() !== String(req.params.studentId).trim().toLowerCase()) {
        return res.status(403).json({ message: "You can only view your own result." });
    }
    const term = req.query.term;
    const schoolSession = req.query.session;
    if (!term || !schoolSession) {
        return res.status(403).json({ message: "Pick a published term and session." });
    }
    connection.query(
        "SELECT class_name FROM students WHERE TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)) LIMIT 1",
        [sid, sid],
        (err, rows) => {
            if (err || !rows.length) return res.status(403).json({ message: "Student record not found." });
            const currentClass = rows[0].class_name;
            connection.query(
                "SELECT DISTINCT class_name FROM results WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?))) AND TRIM(term) = TRIM(?) AND TRIM(session) = TRIM(?)",
                [sid, sid, term, schoolSession],
                (err2, rrows) => {
                    const classes = [currentClass];
                    (rrows || []).forEach((r) => { if (r.class_name) classes.push(r.class_name); });
                    checkPublishedAny(classes, term, schoolSession, (err3, published) => {
                        if (err3) { console.log(err3); return res.status(500).json({ message: "Database error" }); }
                        if (!published) {
                            return res.status(403).json({ message: "This result has not been published by the school yet. Please check back later." });
                        }
                        next();
                    });
                }
            );
        }
    );
}


// NEW (pack 14): admin-only PAGE guard - teachers are sent back to their
// dashboard instead of seeing finance / publish / admissions / settings.
// (API-level guard stays requireAdmin; this one just redirects pages.)
function requireAdminPage(req, res, next) {
    if (req.session && req.session.userId) {
        if (req.session.role === "admin") return next();
        return res.redirect("teacher-dashboard.html");
    }
    if (req.headers.accept && req.headers.accept.includes("text/html")) {
        return res.redirect("/login.html");
    }
    return res.status(401).json({ message: "Not logged in" });
}

/* ---------- Brute-force protection for the two login routes -----------
   Simple in-memory, per-IP rate limiter (same bucket pattern used by the
   AI assistant limiter further down). Allows LOGIN_MAX_ATTEMPTS attempts
   per LOGIN_WINDOW_MS window per IP, then returns 429 until the window
   resets. In-memory is enough for a single-instance deployment. */
const LOGIN_MAX_ATTEMPTS = 10;
const LOGIN_WINDOW_MS = 15 * 60 * 1000; // 15 minutes
const loginHits = Object.create(null); // ip -> { count, resetAt }
setInterval(function () { // sweep expired buckets (memory hygiene)
    const now = Date.now();
    Object.keys(loginHits).forEach(function (k) { if (loginHits[k].resetAt < now) delete loginHits[k]; });
}, 600000).unref();

function loginRateLimit(req, res) {
    const ip = req.ip || (req.connection && req.connection.remoteAddress) || "?";
    const now = Date.now();
    let bucket = loginHits[ip];
    if (!bucket || bucket.resetAt < now) bucket = loginHits[ip] = { count: 0, resetAt: now + LOGIN_WINDOW_MS };
    if (++bucket.count > LOGIN_MAX_ATTEMPTS) {
        const waitMin = Math.max(1, Math.ceil((bucket.resetAt - now) / 60000));
        res.status(429).json({ message: "Too many login attempts. Please try again in about " + waitMin + " minute(s)." });
        return false;
    }
    return true;
}

app.post("/login", (req, res) => {
    if (!loginRateLimit(req, res)) return;
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: "Username and password required" });
    }

    connection.query(
        "SELECT * FROM users WHERE username = ?",
        [username],
        (err, results) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Database Error: " + (err.sqlMessage || err.message || "Could not check users table") });
            }
            if (results.length === 0) {
                return res.status(401).json({ message: "Invalid username or password" });
            }

            const user = results[0];

            bcrypt.compare(password, user.password_hash, (err, match) => {
                if (err || !match) {
                    return res.status(401).json({ message: "Invalid username or password" });
                }

                req.session.userId = user.id;
                req.session.username = user.username;
                req.session.role = user.role;

                res.json({
                    message: "Login successful",
                    role: user.role
                });
            });
        }
    );
});

app.post("/logout", (req, res) => {
    req.session.destroy(() => {
        res.json({ message: "Logged out" });
    });
});

app.get("/me", (req, res) => {
    if (req.session && req.session.userId) {
        res.json({
            loggedIn: true,
            username: req.session.username,
            role: req.session.role
        });
    } else {
        res.json({ loggedIn: false });
    }
});

// Protect the dashboard pages - must come before express.static
// NEW (pack 24 - owner: "add chat in the side bar for admin and
// teachers"): dedicated staff chat page, guarded exactly like the
// dashboard. Must stay BEFORE express.static.
app.get("/chat.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "chat.html"));
});

// NEW (pack 25): staff notifications / settings / timetable pages -
// same guard as the dashboard (admin AND teachers).
app.get("/notifications.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "notifications.html"));
});
app.get("/settings.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "settings.html"));
});
app.get("/timetable.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "timetable.html"));
});
// NEW (pack 35): certificate generator page (staff only, all client-side)
app.get("/certificates.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "certificates.html"));
});

// NEW (pack 26): the sections the owner moved OUT of the dashboard now
// live on their own pages - same guard as the dashboard (admin + teachers).
app.get("/scores.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "scores.html"));
});
app.get("/notices.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "notices.html"));
});
// NEW (pack 27): the AI Remarks helper page - staff only, same guard style.
app.get("/ai-remarks.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "ai-remarks.html"));
});
// NEW (pack 37 - owner: "give students AI chat for learning at home"):
// the AI Learning Tutor page. Only people signed in to the Student &
// Parent Portal (student ID + surname) - or staff - may open it.
app.get("/student-ai-tutor.html", (req, res) => {
    if (!req.session || (!req.session.portalStudentId && !req.session.userId)) {
        return res.redirect("/portal-login.html");
    }
    res.sendFile(path.join(__dirname, "student-ai-tutor.html"));
});

app.get("/teacher-dashboard.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "teacher-dashboard.html"));
});

app.get("/add-student.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "add-student.html"));
});

app.get("/add-subject.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "add-subject.html"));
});

app.get("/manage-signatures.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "manage-signatures.html"));
});



// ----------------------------------------------------------------
// NEW (pack 13): protect the new management pages exactly like the
// existing dashboard pages. Must stay BEFORE express.static.
// ----------------------------------------------------------------
app.get("/manage-publish.html", requireAdminPage, (req, res) => { // CHANGED (pack 14): admin-only (owner request: teachers must not access)
    res.sendFile(path.join(__dirname, "manage-publish.html"));
});

app.get("/manage-admissions.html", requireAdminPage, (req, res) => { // CHANGED (pack 14): admin-only (owner request: teachers must not access)
    res.sendFile(path.join(__dirname, "manage-admissions.html"));
});

app.get("/attendance.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "attendance.html"));
});

app.get("/staff-attendance.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "staff-attendance.html"));
});

// NEW (pack 15): calendar editor page - staff can view/print; saving,
// publishing and deleting stay admin-only at the API level.
app.get("/manage-calendars.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "manage-calendars.html"));
});

app.get("/finance.html", requireAdminPage, (req, res) => { // CHANGED (pack 14): admin-only (owner request: teachers must not access)
    res.sendFile(path.join(__dirname, "finance.html"));
});

app.get("/manage-users.html", requireAdminPage, (req, res) => {
    res.sendFile(path.join(__dirname, "manage-users.html"));
});

// NEW (staff profiles & payroll): admin-only page.
app.get("/staff.html", requireAdminPage, (req, res) => {
    res.sendFile(path.join(__dirname, "staff.html"));
});

app.get("/school-settings.html", requireAdminPage, (req, res) => {
    res.sendFile(path.join(__dirname, "school-settings.html"));
});

app.get("/id-card.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "id-card.html"));
});

app.get("/create-exam.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "create-exam.html"));
});

app.get("/students.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "students.html"));
});

// ----------------------------------------------------------------
// NEW (whole-class results page): serves the broadsheet page where
// staff pick Class + Session + Term and download ONE combined PDF.
// READ-ONLY: the page only SELECTs existing results. Additive.
// ----------------------------------------------------------------
app.get("/class-results.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "class-results.html"));
});

// NEW (Third Term Results feature): the page that uploads the school's
// internal grade workbook (.xlsx, one sheet per class) and generates
// third-term result sheets / PDFs / a consolidated Excel export.
app.get("/third-term-results.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "third-term-results.html"));
});

// NEW (bulk results / discipline / lesson planner pages).
app.get("/bulk-results.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "bulk-results.html"));
});

app.get("/discipline.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "discipline.html"));
});

app.get("/lesson-planner.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "lesson-planner.html"));
});

// NEW (quizzes / notify parents / appointments pages).
app.get("/quizzes.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "quizzes.html"));
});

app.get("/notify-parents.html", requireLogin, requireAdmin, (req, res) => {
    res.sendFile(path.join(__dirname, "notify-parents.html"));
});

app.get("/appointments.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "appointments.html"));
});

// ----------------------------------------------------------------
// NEW (PWA conversion): serve the app manifest with the correct
// content type so every browser accepts it. ADDITIVE ONLY - no
// existing route, page or query is modified. (Public, like login.)
// ----------------------------------------------------------------
app.get("/manifest.webmanifest", (req, res) => {
    res.type("application/manifest+json");
    res.sendFile(path.join(__dirname, "manifest.webmanifest"));
});

/* ==================================================================
   FIX (pack 20 - owner: "why is the signature disappearing after some
   time - fix that"): Render (and any cloud host) wipes the app's disk
   on every restart/deploy, so every uploaded image slowly vanished -
   signatures, class signatures, student photos, parent payment proofs
   and receipt snaps. From pack 20 every upload is ALSO stored in the
   database (LONGBLOB column, added by the guarded migration further
   down), and this middleware rebuilds any missing file from the
   database the moment it is requested again. Nothing about the stored
   file paths, routes or readers changes.
================================================================== */
const imageDbSources = [
    // [urlPrefix, table, pathColumn, dataColumn]
    ["/images/signatures/", "signatures", "signature_path", "signature_data"],
    ["/images/signatures/", "class_teacher_signatures", "signature_path", "signature_data"],
    ["/images/students/", "students", "photo_path", "photo_data"],
    ["/uploads/payment-evidence/", "payment_submissions", "evidence_path", "evidence_data"],
    ["/uploads/payment-evidence/", "fee_payments", "receipt_path", "receipt_data"]
];

function tryRestoreImage(relPath, sources, idx, done) {
    if (idx >= sources.length) return done(false);
    const [prefix, table, pathCol, dataCol] = sources[idx];
    if (relPath.indexOf(prefix.replace(/^\//, "")) !== 0) return tryRestoreImage(relPath, sources, idx + 1, done);
    // ?? = escaped identifier (mysql2 built-in), ? = value.
    connection.query(
        "SELECT ?? AS img FROM ?? WHERE ?? = ? LIMIT 1",
        [dataCol, table, pathCol, relPath],
        (err, rows) => {
            if (err || !rows || !rows.length || !rows[0].img) {
                return tryRestoreImage(relPath, sources, idx + 1, done);
            }
            try {
                const abs = path.join(__dirname, relPath);
                fs.mkdirSync(path.dirname(abs), { recursive: true });
                fs.writeFileSync(abs, rows[0].img);
                return done(true);
            } catch (wErr) {
                console.log("Image restore failed for", relPath, wErr.message || wErr);
                return done(false);
            }
        }
    );
}

app.use((req, res, next) => {
    // Only look at GETs under the upload folders; everything else passes.
    if (req.method !== "GET") return next();
    const urlPath = req.path;
    if (!/^\/(images\/(signatures|students)|uploads\/payment-evidence)\//.test(urlPath)) return next();
    if (urlPath.indexOf("..") !== -1) return next();
    const relPath = urlPath.replace(/^\//, "");
    const abs = path.join(__dirname, relPath);
    if (fs.existsSync(abs)) return next();          // file alive - normal static serve
    tryRestoreImage(relPath, imageDbSources, 0, (restored) => next()); // rebuilt or not - continue either way
});

/* FIX (pack 20): save-image queries now also store the bytes in the
   pack-20 backup columns. During the very first boot after deploy the
   migration may still be running (columns missing -> ER_BAD_FIELD_ERROR);
   then we silently retry with the pre-pack-20 columns so saves NEVER fail.
*/
function queryImageSave(sqlWithData, paramsWithData, sqlWithout, paramsWithout, cb) {
    connection.query(sqlWithData, paramsWithData, (err, result) => {
        if (err && err.code === "ER_BAD_FIELD_ERROR") {
            return connection.query(sqlWithout, paramsWithout, (err2, res2) => {
                if (err2 && err2.code === "ER_BAD_FIELD_ERROR") {
                    const cleanSql = sqlWithout.replace(/,\s*updated_at\s*=\s*CURRENT_TIMESTAMP/gi, "");
                    return connection.query(cleanSql, paramsWithout, cb);
                }
                cb(err2, res2);
            });
        }
        cb(err, result);
    });
}

/* FIX (pack 20): student photos get their database copy via a small
   follow-up UPDATE after any successful photo write (keeps the original
   multi-branch INSERT/UPDATE code untouched). Swallowed on failure - the
   photo itself is already saved to disk, the backup just waits for the
   next write or the migration window to pass. */
function backupStudentPhoto(studentId, filePath) {
    if (!filePath || !studentId) return;
    let data;
    try { data = fs.readFileSync(filePath); } catch (e) { return; }
    connection.query("UPDATE students SET photo_data = ? WHERE student_id = ?", [data, studentId], () => {});
}

/* SEO fix (canonical): serve the public website with __AMS_SITE_URL__
   rewritten to the correct public URL (resolver at the top of this
   file). MUST come before express.static so the raw placeholder never
   reaches the browser as-is. Covers both / and /index.html. */
app.get(["/", "/index.html"], amsIndexHtml);

app.use(express.static(__dirname));

/* ==================================================================
   ADD-ON MODULE  (added by the UI modernization project)
   ------------------------------------------------------------------
   ADDITIVE ONLY. This block:
     - creates TWO brand-new tables (announcements, school_events)
       with CREATE TABLE IF NOT EXISTS - it never alters, renames,
       or touches any existing table (students, results, users, ...)
     - exposes NEW endpoints whose names do not collide with any
       existing route: /students, /dashboard-stats, /recent-activity,
       /api/announcements, /api/events
     - performs READ-ONLY SELECTs against existing tables (for the
       dashboard widgets). The result system is never written to
       outside the original routes.
================================================================== */

// NEW (Pack 67): Zero-Configuration Auto-Schema & Default Admin Bootstrapper
// Automatically creates all core legacy tables if they don't exist in a new MySQL database
// (e.g. fresh Railway deployment) and seeds a default Admin account (username: admin) from ADMIN_DEFAULT_PASSWORD env var.
function ensureCoreTablesAndDefaultAdmin() {
    const coreTables = [
        `CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(100) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT 'teacher',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS students (
            student_id VARCHAR(64) PRIMARY KEY,
            full_name VARCHAR(160) NOT NULL,
            gender VARCHAR(20) DEFAULT '',
            class_name VARCHAR(100) DEFAULT '',
            date_of_birth DATE NULL,
            photo_path VARCHAR(255) DEFAULT '',
            photo_data LONGBLOB NULL,
            parent_name VARCHAR(160) DEFAULT '',
            parent_phone VARCHAR(60) DEFAULT '',
            address VARCHAR(255) DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            status_date DATE NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS results (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(64) NOT NULL,
            student_name VARCHAR(160) DEFAULT '',
            class_name VARCHAR(100) DEFAULT '',
            term VARCHAR(50) DEFAULT '',
            session VARCHAR(50) DEFAULT '',
            subject VARCHAR(120) DEFAULT '',
            first_test DECIMAL(5,2) DEFAULT 0,
            second_test DECIMAL(5,2) DEFAULT 0,
            note_score DECIMAL(5,2) DEFAULT 0,
            attendance_score DECIMAL(5,2) DEFAULT 0,
            ca_score DECIMAL(5,2) DEFAULT 0,
            exam_score DECIMAL(5,2) DEFAULT 0,
            total DECIMAL(5,2) DEFAULT 0,
            grade VARCHAR(10) DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS classes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            class_name VARCHAR(100) NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS subjects (
            id INT AUTO_INCREMENT PRIMARY KEY,
            class_name VARCHAR(100) NOT NULL,
            subject_name VARCHAR(120) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS exams (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            class_name VARCHAR(100) NOT NULL,
            subject VARCHAR(120) NOT NULL,
            term VARCHAR(50) NOT NULL,
            session VARCHAR(50) NOT NULL,
            duration VARCHAR(100) NULL,
            instructions TEXT NULL,
            body_html LONGTEXT NOT NULL,
            created_by VARCHAR(100) NULL,
            exam_date DATE NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS signatures (
            id INT AUTO_INCREMENT PRIMARY KEY,
            role VARCHAR(50) NOT NULL UNIQUE,
            signature_path VARCHAR(255) NOT NULL,
            signature_data LONGBLOB NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS class_teacher_signatures (
            id INT AUTO_INCREMENT PRIMARY KEY,
            class_name VARCHAR(150) NOT NULL UNIQUE,
            signature_path VARCHAR(255) NOT NULL,
            signature_data LONGBLOB NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS fee_structure (
            id INT AUTO_INCREMENT PRIMARY KEY,
            class_name VARCHAR(150) NOT NULL,
            term VARCHAR(50) NOT NULL,
            session VARCHAR(50) NOT NULL,
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_class_term_session (class_name, term, session)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS fee_structure2 (
            id INT AUTO_INCREMENT PRIMARY KEY,
            class_name VARCHAR(150) NOT NULL,
            term VARCHAR(50) NOT NULL,
            session VARCHAR(50) NOT NULL,
            fee_type VARCHAR(100) NOT NULL DEFAULT 'School Fee',
            amount DECIMAL(12,2) NOT NULL DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_class_term_sess_type (class_name, term, session, fee_type)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS fee_payments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(100) NOT NULL,
            term VARCHAR(50) NOT NULL,
            session VARCHAR(50) NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            method VARCHAR(60),
            note VARCHAR(255),
            received_by VARCHAR(100),
            paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            receipt_path VARCHAR(255) NULL,
            receipt_data LONGBLOB NULL,
            fee_type VARCHAR(100) NOT NULL DEFAULT 'School Fee'
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS expenses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            category VARCHAR(100),
            amount DECIMAL(12,2) NOT NULL,
            spent_on DATE,
            note VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS fee_types (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS school_settings (
            id INT PRIMARY KEY DEFAULT 1,
            school_name VARCHAR(255),
            school_name_ar VARCHAR(255),
            address VARCHAR(255),
            phone1 VARCHAR(50),
            phone2 VARCHAR(50),
            email VARCHAR(150),
            motto VARCHAR(255),
            motto_ar VARCHAR(255),
            result_notice TEXT,
            term_begins DATE NULL,
            term_ends DATE NULL,
            next_term_begins DATE NULL,
            due_day TINYINT UNSIGNED NULL,
            due_note VARCHAR(150) NULL,
            bank_name VARCHAR(120) NULL,
            account_name VARCHAR(120) NULL,
            account_number VARCHAR(40) NULL,
            pay_instructions TEXT NULL,
            portal_pay_enabled TINYINT(1) NOT NULL DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS staff (
            id INT AUTO_INCREMENT PRIMARY KEY,
            full_name VARCHAR(160) NOT NULL,
            subject VARCHAR(120) DEFAULT '',
            qualification VARCHAR(160) DEFAULT '',
            phone VARCHAR(60) DEFAULT '',
            salary DECIMAL(12,2) DEFAULT 0,
            bank_name VARCHAR(120) DEFAULT '',
            account_name VARCHAR(160) DEFAULT '',
            account_number VARCHAR(60) DEFAULT '',
            status VARCHAR(20) NOT NULL DEFAULT 'active',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS payroll (
            id INT AUTO_INCREMENT PRIMARY KEY,
            staff_id INT NOT NULL,
            pay_month VARCHAR(20) NOT NULL,
            amount DECIMAL(12,2) NOT NULL,
            method VARCHAR(60) DEFAULT '',
            note VARCHAR(255) DEFAULT '',
            paid_by VARCHAR(100) DEFAULT '',
            paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY idx_payroll_staff (staff_id)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS discipline (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(64) NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'warning',
            title VARCHAR(160) DEFAULT '',
            description TEXT,
            record_date DATE NOT NULL,
            recorded_by VARCHAR(100) DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY idx_discipline_student (student_id)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS lesson_plans (
            id INT AUTO_INCREMENT PRIMARY KEY,
            teacher VARCHAR(100) DEFAULT '',
            subject VARCHAR(120) DEFAULT '',
            class_name VARCHAR(100) DEFAULT '',
            week_start DATE NOT NULL,
            topic VARCHAR(255) DEFAULT '',
            objectives TEXT,
            activities TEXT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY idx_lessonplans_teacher (teacher)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS quizzes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            class_name VARCHAR(100) DEFAULT '',
            subject VARCHAR(120) DEFAULT '',
            questions LONGTEXT NOT NULL,
            due_date DATE NULL,
            created_by VARCHAR(100) DEFAULT '',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS quiz_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            quiz_id INT NOT NULL,
            student_id VARCHAR(64) NOT NULL,
            student_name VARCHAR(160) DEFAULT '',
            score INT NOT NULL DEFAULT 0,
            total INT NOT NULL DEFAULT 0,
            answers LONGTEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY idx_quizattempts_quiz (quiz_id),
            KEY idx_quizattempts_student (student_id)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
        `CREATE TABLE IF NOT EXISTS appointments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id VARCHAR(64) NOT NULL,
            student_name VARCHAR(160) DEFAULT '',
            class_name VARCHAR(100) DEFAULT '',
            parent_name VARCHAR(160) DEFAULT '',
            requested_date DATE NOT NULL,
            requested_time VARCHAR(20) DEFAULT '',
            reason TEXT,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            admin_note TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            KEY idx_appointments_student (student_id)
        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
    ];

    coreTables.forEach(sql => {
        connection.query(sql, (err) => {
            if (err) console.error("Core table creation error:", err.message || err);
        });
    });

    connection.query("SELECT COUNT(*) AS cnt FROM users", (err, rows) => {
        if (!err && rows && rows[0] && rows[0].cnt === 0) {
            const adminDefaultPassword = process.env.ADMIN_DEFAULT_PASSWORD;
            if (!adminDefaultPassword) {
                console.warn("WARNING: ADMIN_DEFAULT_PASSWORD not set - skipping default admin seed. Set ADMIN_DEFAULT_PASSWORD to create initial admin account.");
                return;
            }
            bcrypt.hash(adminDefaultPassword, 10, (herr, hash) => {
                if (!herr && hash) {
                    connection.query("INSERT IGNORE INTO users (username, password_hash, role) VALUES ('admin', ?, 'admin')", [hash], () => {
                        console.log("Seeded default admin account (username: admin)");
                    });
                    connection.query("INSERT IGNORE INTO users (username, password_hash, role) VALUES ('Proprietor', ?, 'admin')", [hash], () => {});
                }
            });
        }
    });
}
ensureCoreTablesAndDefaultAdmin();

// ONE-TIME: fix collation mismatch
// NOTE (pack 85): the health / library / remarks tables were created without an
// explicit collation, so on MySQL 8 databases they inherit utf8mb4_0900_ai_ci.
// Joining them to `students` (utf8mb4_unicode_ci) raises "Illegal mix of
// collations" -> 500 -> the student list was EMPTY in Student Health and in
// Teacher Comments. Converting every student-keyed table to the same collation
// as `students` heals existing databases; the CREATE TABLE statements below
// also pin the collation for fresh installs.
const COLLATION_FIX_TABLES = [
    "students", "results", "result_publish", "fee_structure2", "fee_payments",
    "payment_submissions", "users",
    // Pack 65/84 add-on tables (student-facing portal + clinic/library/remarks)
    "homework", "student_health", "transport_routes", "transport_assignments",
    "school_gallery", "leave_requests", "broadcasts", "clinic_visits",
    "vaccinations", "library_books", "library_loans", "term_remarks",
    /* NEW (pack 109): `attendance`, `classes` and `staff_attendance` were the
       three add-on tables still missing from this list, and that omission is
       the whole of the "Illegal mix of collations ... for operation '='" 500
       behind Load Report. They are created WITHOUT a pinned collation, so on a
       MySQL 8 database they inherit utf8mb4_0900_ai_ci while `students` and
       `users` are utf8mb4_unicode_ci — and ANY equality between a column of
       the two (not just class_name: the student_id / staff_username JOIN keys
       are strings too) is refused. The attendance routes no longer join
       across tables at all, so they survive even where this ALTER is not
       permitted; converting the tables heals every other query as well. */
    "attendance", "classes", "staff_attendance"
];
COLLATION_FIX_TABLES.forEach(function (tbl) {
    connection.query(`ALTER TABLE ${tbl} CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`, () => {});
});
const addonTables = [
    // Notice board / school news for the dashboard
    `CREATE TABLE IF NOT EXISTS announcements (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        body TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // School calendar events shown on the dashboard calendar widget
    `CREATE TABLE IF NOT EXISTS school_events (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        event_date DATE NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (per-class class-teacher signatures, owner request): MANY class
    // teacher signatures - one assigned per class - so each class's report
    // cards stamp ITS OWN teacher's signature ("appear on class teacher
    // class, not just random class"). The old signatures table and its
    // shared "class_teacher" role stay as the fallback for classes with
    // nothing assigned. Purely additive - no existing table/column touched.
    `CREATE TABLE IF NOT EXISTS class_teacher_signatures (
        class_name VARCHAR(150) PRIMARY KEY,
        signature_path VARCHAR(255) NOT NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,
    // NEW (pack 13 - results publish gate): class_name '' = WHOLE TERM
    // (admin publishes every class at once; per-class rows publish one
    // class only). Whole-term wins by design (owner decision).
    `CREATE TABLE IF NOT EXISTS result_publish (
        class_name VARCHAR(150) NOT NULL DEFAULT '',
        term VARCHAR(50) NOT NULL,
        session VARCHAR(50) NOT NULL,
        published TINYINT(1) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (class_name, term, session)
    )`,
    // NEW (pack 13 - admission enquiries from the school website):
    // visitors register interest; management reviews and admits.
    `CREATE TABLE IF NOT EXISTS admission_enquiries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        child_name VARCHAR(255) NOT NULL,
        parent_name VARCHAR(255),
        phone VARCHAR(50),
        class_applied VARCHAR(150),
        message TEXT,
        status ENUM('new','contacted','admitted') NOT NULL DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 13 - student attendance): one row per student per day.
    `CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        class_name VARCHAR(150) NOT NULL,
        att_date DATE NOT NULL,
        status ENUM('present','absent','late') NOT NULL DEFAULT 'present',
        marked_by VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_student_day (student_id, att_date)
    )`,
    // NEW (pack 13 - staff attendance): one row per staff per day.
    `CREATE TABLE IF NOT EXISTS staff_attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        staff_username VARCHAR(100) NOT NULL,
        att_date DATE NOT NULL,
        status ENUM('present','absent') NOT NULL DEFAULT 'present',
        marked_by VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_staff_day (staff_username, att_date)
    )`,
    // NEW (pack 13 - weekly teacher evaluations).
    `CREATE TABLE IF NOT EXISTS staff_evaluations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        staff_username VARCHAR(100) NOT NULL,
        week_start DATE NOT NULL,
        teaching TINYINT,
        punctuality TINYINT,
        conduct TINYINT,
        comment TEXT,
        created_by VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 13 - finance: fee structure per class per term/session).
    `CREATE TABLE IF NOT EXISTS fee_structure (
        id INT AUTO_INCREMENT PRIMARY KEY,
        class_name VARCHAR(150) NOT NULL,
        term VARCHAR(50) NOT NULL,
        session VARCHAR(50) NOT NULL,
        amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_class_term_session (class_name, term, session)
    )`,
    // NEW (pack 13 - finance: fee payments received).
    `CREATE TABLE IF NOT EXISTS fee_payments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        term VARCHAR(50) NOT NULL,
        session VARCHAR(50) NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        method VARCHAR(60),
        note VARCHAR(255),
        received_by VARCHAR(100),
        paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 14 - school settings, admin editable profile: name,
    // Arabic name, motto, address, phones, email). Single row (id = 1).
    `CREATE TABLE IF NOT EXISTS school_settings (
        id INT PRIMARY KEY,
        school_name VARCHAR(255),
        school_name_ar VARCHAR(255),
        motto VARCHAR(255),
        motto_ar VARCHAR(255),
        address VARCHAR(255),
        phone1 VARCHAR(50),
        phone2 VARCHAR(50),
        email VARCHAR(120),
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,
    // NEW (pack 15 - fee types, owner request: "school fee, developmental
    // fee, exam fee, and so on" - each with its own amount per class).
    `CREATE TABLE IF NOT EXISTS fee_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(120) NOT NULL UNIQUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 15): fee amounts per fee TYPE per class per term/session.
    // The older fee_structure table stays untouched (migrated as School Fee).
    `CREATE TABLE IF NOT EXISTS fee_structure2 (
        id INT AUTO_INCREMENT PRIMARY KEY,
        fee_type VARCHAR(120) NOT NULL DEFAULT 'School Fee',
        class_name VARCHAR(150) NOT NULL,
        term VARCHAR(50) NOT NULL,
        session VARCHAR(50) NOT NULL,
        amount DECIMAL(12,2) NOT NULL DEFAULT 0,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_ft_class_term_session (fee_type, class_name, term, session)
    )`,
    // NEW (pack 15): many bank accounts shown on the parent portal as
    // "where to pay" details.
    `CREATE TABLE IF NOT EXISTS bank_accounts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        bank_name VARCHAR(150) NOT NULL,
        account_name VARCHAR(150),
        account_number VARCHAR(60) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 15): parents upload a screenshot/PDF of their payment;
    // admin approves (it becomes a real payment) or rejects it.
    `CREATE TABLE IF NOT EXISTS payment_submissions (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(100) NOT NULL,
        fee_type VARCHAR(120) NOT NULL DEFAULT 'School Fee',
        term VARCHAR(50) NOT NULL,
        session VARCHAR(50) NOT NULL,
        amount DECIMAL(12,2) NOT NULL,
        note VARCHAR(255),
        evidence_path VARCHAR(255),
        status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
        reviewed_by VARCHAR(100),
        reviewed_at TIMESTAMP NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 15): termly madrasah calendar. published=1 shows it on
    // the parent portal; publishing one auto-unpublishes the rest so
    // parents never see duplicates from different terms (owner request).
    `CREATE TABLE IF NOT EXISTS calendars (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        doc LONGTEXT,
        published TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )`,
    // NEW (pack 14 - academic sessions the admin creates, e.g. 2027/2028).
    `CREATE TABLE IF NOT EXISTS sessions (
        session VARCHAR(50) PRIMARY KEY,
        is_current TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (pack 13 - finance: school expenses).
    `CREATE TABLE IF NOT EXISTS expenses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        category VARCHAR(100),
        amount DECIMAL(12,2) NOT NULL,
        spent_on DATE,
        note VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    // NEW (Pack 47 - School File Store & Digital Vault for documents/records).
    `CREATE TABLE IF NOT EXISTS school_file_store (
        id INT AUTO_INCREMENT PRIMARY KEY,
        folder_path VARCHAR(255) NOT NULL DEFAULT '/',
        file_name VARCHAR(255) NOT NULL,
        original_name VARCHAR(255) NOT NULL,
        file_size BIGINT UNSIGNED NOT NULL DEFAULT 0,
        file_type VARCHAR(120) NOT NULL DEFAULT 'application/octet-stream',
        file_path VARCHAR(500) NOT NULL DEFAULT '',
        is_folder TINYINT(1) NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    /* ===== NEW PORTAL FEATURE TABLES (Pack 65) ===== */
    `CREATE TABLE IF NOT EXISTS homework (
        id INT AUTO_INCREMENT PRIMARY KEY,
        class_name VARCHAR(100) NOT NULL,
        subject VARCHAR(120) NOT NULL,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        due_date DATE,
        posted_by VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS student_health (
        student_id VARCHAR(64) PRIMARY KEY,
        blood_group VARCHAR(10) DEFAULT '',
        allergies TEXT,
        medical_conditions TEXT,
        emergency_contact_name VARCHAR(160) DEFAULT '',
        emergency_contact_phone VARCHAR(60) DEFAULT '',
        notes TEXT,
        height_cm DECIMAL(5,2) NULL,
        weight_kg DECIMAL(5,2) NULL,
        bmi DECIMAL(4,1) NULL,
        genotype VARCHAR(10) DEFAULT '',
        doctor_name VARCHAR(160) DEFAULT '',
        doctor_phone VARCHAR(60) DEFAULT '',
        insurance_no VARCHAR(120) DEFAULT '',
        current_medications TEXT,
        last_checkup DATE NULL,
        special_needs TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS transport_routes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        route_name VARCHAR(100) NOT NULL,
        bus_number VARCHAR(50) DEFAULT '',
        driver_name VARCHAR(100) DEFAULT '',
        driver_phone VARCHAR(60) DEFAULT '',
        pickup_time VARCHAR(50) DEFAULT '',
        dropoff_time VARCHAR(50) DEFAULT '',
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS transport_assignments (
        student_id VARCHAR(64) PRIMARY KEY,
        route_id INT,
        pickup_point VARCHAR(255) DEFAULT '',
        notes VARCHAR(255) DEFAULT '',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS school_gallery (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL DEFAULT '',
        caption TEXT,
        image_data LONGBLOB,
        image_type VARCHAR(50) DEFAULT 'image/jpeg',
        uploaded_by VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS leave_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(64) NOT NULL,
        student_name VARCHAR(160) DEFAULT '',
        class_name VARCHAR(100) DEFAULT '',
        reason TEXT NOT NULL,
        from_date DATE NOT NULL,
        to_date DATE NOT NULL,
        status VARCHAR(20) DEFAULT 'pending',
        admin_note TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS broadcasts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        pinned TINYINT(1) DEFAULT 0,
        posted_by VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS clinic_visits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(64) NOT NULL,
        visit_date DATE NOT NULL,
        complaint TEXT,
        treatment TEXT,
        recorded_by VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_clinic_student (student_id)
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS vaccinations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(64) NOT NULL,
        vaccine_name VARCHAR(160) NOT NULL,
        given_date DATE NULL,
        notes VARCHAR(255) DEFAULT '',
        recorded_by VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_vax_student (student_id)
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS library_books (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        author VARCHAR(160) DEFAULT '',
        isbn VARCHAR(60) DEFAULT '',
        copies INT NOT NULL DEFAULT 1,
        available INT NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS library_loans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        book_id INT NOT NULL,
        student_id VARCHAR(64) NOT NULL,
        issued_at DATE NOT NULL,
        due_date DATE NULL,
        returned_at DATE NULL,
        issued_by VARCHAR(100) DEFAULT '',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_loan_student (student_id),
        KEY idx_loan_book (book_id)
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
    `CREATE TABLE IF NOT EXISTS term_remarks (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id VARCHAR(64) NOT NULL,
        term VARCHAR(50) NOT NULL,
        session VARCHAR(50) NOT NULL,
        teacher_remark TEXT,
        principal_remark TEXT,
        recorded_by VARCHAR(100) DEFAULT '',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_remark (student_id, term, session)
    ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`
];

// Provisions ONLY the two add-on tables. Deliberately uses its own
// short-lived connection (never the shared one from db.js) so that:
//   - nothing about the existing app's DB behaviour can change, and
//   - it can self-heal after "MySQL not ready yet" cold-start races.
// Retries a few times, then gives up gracefully: the rest of the app
// (login, results, exams, ...) is completely unaffected either way.
const mysql2 = require("mysql2");

function addonConnection() {
    const dbUrl = process.env.MYSQL_URL || process.env.DATABASE_URL || process.env.MYSQL_PUBLIC_URL;
    const dbPassword = process.env.MYSQLPASSWORD || process.env.MYSQL_PASSWORD || process.env.DB_PASSWORD;
    if (!dbUrl && !dbPassword) {
        console.error(
            "FATAL: No database password configured for addonConnection. Set DB_PASSWORD (or MYSQLPASSWORD / MYSQL_PASSWORD), or provide a full MYSQL_URL / DATABASE_URL. Refusing to start with a default password."
        );
        process.exit(1);
    }
    return mysql2.createConnection({
        host: process.env.MYSQLHOST || process.env.DB_HOST || "localhost",
        port: process.env.MYSQLPORT || process.env.DB_PORT || 3306,
        user: process.env.MYSQLUSER || process.env.DB_USER || "root",
        password: dbPassword,
        database: process.env.MYSQLDATABASE || process.env.DB_NAME || "railway"
    });
}

function addonRetryLater(attempt, err) {
    const reason = err.code || err.message || err;
    if (attempt >= 4) {
        console.log("Add-on setup warning: could not auto-create add-on tables after 4 attempts. Reason:", reason);
        console.log("  -> The app keeps working normally; only the Notice Board / Events / Calendar widgets will be unavailable.");
        if (reason === "ER_DBACCESS_DENIED_ERROR" || reason === "ER_TABLEACCESS_DENIED_ERROR") {
            console.log("  -> Cause: the database user has no CREATE privilege.");
        }
        console.log("  -> Fix: run the SQL in sql/addon_tables.sql against your database (or grant CREATE), then restart.");
        return;
    }
    console.log(`Add-on setup: attempt ${attempt} failed (${reason}); retrying in 4s...`);
    setTimeout(() => setupAddonTables(attempt + 1), 4000);
}

function setupAddonTables(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) {
            conn.destroy();
            return addonRetryLater(attempt, err);
        }
        let firstFailure = null;
        let finished = 0;
        addonTables.forEach((sql) => {
            conn.query(sql, (qErr) => {
                if (qErr && !firstFailure) firstFailure = qErr;
                finished++;
                if (finished === addonTables.length) {
                    conn.end();
                    if (firstFailure) return addonRetryLater(attempt, firstFailure);
                    console.log("Add-on tables ready (...,school_settings, sessions, fee_types, fee_structure2, bank_accounts, payment_submissions, calendars).");
                }
            });
        });
    });
}

setupAddonTables(1);

/* ==================================================================
   NEW (student profile fields - request #4): parent_name,
   parent_phone, address columns on the students table.
   ------------------------------------------------------------------
   Why this is here: the requested "Edit Student Profile" feature
   (parent name, parent phone, address) needs somewhere to live.
   This is the ONLY structural change in this update, and it is:
     - ADDITIVE: three NULL-able columns are APPENDED; no existing
       table, column, route or query is renamed or changed.
     - GUARDED: it first ASKS information_schema which columns exist,
       so it runs the ALTER once only and never errors on re-boots.
     - GRACEFUL: if the DB user has no ALTER privilege, the app keeps
       working exactly as before; editing of the 3 new fields is
       simply skipped (flag below stays false).
   The result system is untouched by this.
================================================================== */
let studentProfileColsReady = false;

function ensureStudentProfileColumns(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) {
            conn.destroy();
            return profileColsRetry(attempt, err);
        }
        conn.query(
            `SELECT COUNT(*) AS c
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'students'
               AND COLUMN_NAME IN ('parent_name', 'parent_phone', 'address')`,
            (qErr, rows) => {
                if (qErr) {
                    conn.end();
                    return profileColsRetry(attempt, qErr);
                }
                if (rows && rows[0] && Number(rows[0].c) === 3) {
                    conn.end();
                    studentProfileColsReady = true;
                    console.log("Student profile columns ready (parent_name, parent_phone, address).");
                    return;
                }
                // Columns missing - add them in ONE idempotent statement.
                conn.query(
                    `ALTER TABLE students
                        ADD COLUMN parent_name  VARCHAR(255) NULL,
                        ADD COLUMN parent_phone VARCHAR(50)  NULL,
                        ADD COLUMN address      VARCHAR(255) NULL`,
                    (aErr) => {
                        conn.end();
                        if (aErr) {
                            // Another boot raced us and added them first - treat as done.
                            if (aErr.code === "ER_DUP_FIELDNAME") {
                                studentProfileColsReady = true;
                                console.log("Student profile columns ready (added by a parallel boot).");
                                return;
                            }
                            return profileColsRetry(attempt, aErr);
                        }
                        studentProfileColsReady = true;
                        console.log("Student profile columns added (parent_name, parent_phone, address).");
                    }
                );
            }
        );
    });
}

function profileColsRetry(attempt, err) {
    const reason = err.code || err.message || err;
    if (attempt >= 3) {
        console.log("Student profile setup warning: could not add the 3 profile columns. Reason:", reason);
        console.log("  -> Everything keeps working; only Parent Name / Parent Phone / Address editing stays off.");
        console.log("  -> Fix: run the SQL in sql/student_profile_columns.sql, then restart.");
        return;
    }
    console.log(`Student profile setup: attempt ${attempt} failed (${reason}); retrying in 4s...`);
    setTimeout(() => ensureStudentProfileColumns(attempt + 1), 4000);
}

ensureStudentProfileColumns(1);

/* ------------------------------------------------------------------
   NEW (feature 2 - student status): Active / Withdrawn / Graduated.
   Same guarded information_schema pattern as the student-profile
   columns above: adds `status` (default 'active') and `status_date`
   to the students table once, never errors on re-boots, and the app
   keeps working (status editing just stays off) if ALTER is denied.
------------------------------------------------------------------ */
let studentStatusColsReady = false;

function ensureStudentStatusColumns(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) {
            conn.destroy();
            return statusColsRetry(attempt, err);
        }
        conn.query(
            `SELECT COUNT(*) AS c
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'students'
               AND COLUMN_NAME IN ('status', 'status_date')`,
            (qErr, rows) => {
                if (qErr) {
                    conn.end();
                    return statusColsRetry(attempt, qErr);
                }
                if (rows && rows[0] && Number(rows[0].c) === 2) {
                    conn.end();
                    studentStatusColsReady = true;
                    console.log("Student status columns ready (status, status_date).");
                    return;
                }
                conn.query(
                    `ALTER TABLE students
                        ADD COLUMN status VARCHAR(20) NOT NULL DEFAULT 'active',
                        ADD COLUMN status_date DATE NULL`,
                    (aErr) => {
                        conn.end();
                        if (aErr) {
                            if (aErr.code === "ER_DUP_FIELDNAME") {
                                studentStatusColsReady = true;
                                return;
                            }
                            return statusColsRetry(attempt, aErr);
                        }
                        studentStatusColsReady = true;
                        console.log("Student status columns added (status, status_date).");
                    }
                );
            }
        );
    });
}

function statusColsRetry(attempt, err) {
    const reason = err.code || err.message || err;
    if (attempt >= 3) {
        console.log("Student status setup warning: could not add status columns. Reason:", reason);
        console.log("  -> Everything keeps working; only Active/Withdrawn/Graduated stays off.");
        return;
    }
    console.log(`Student status setup: attempt ${attempt} failed (${reason}); retrying in 4s...`);
    setTimeout(() => ensureStudentStatusColumns(attempt + 1), 4000);
}

ensureStudentStatusColumns(1);

/* ==================================================================
   NEW (pack 15 - finance v2): safe, guarded migrations +
   one-time seeding. Same pattern as the student-profile columns:
   check information_schema first, ALTER only when needed, never
   error on re-boots, app keeps working if anything is denied.
     1. fee_payments gains a fee_type column (default 'School Fee').
     2. school_settings gains due_day + current_term columns.
     3. fee_types seeded with School Fee / Developmental Fee / Exam Fee.
     4. old fee_structure rows copied into fee_structure2 as School Fee
        (INSERT IGNORE - runs every boot but only ever inserts once).
================================================================== */
function runPack15Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack15Retry(attempt, err); }
        const steps = [
            // 1) fee_type on fee_payments
            `ALTER TABLE fee_payments
               ADD COLUMN fee_type VARCHAR(120) NOT NULL DEFAULT 'School Fee'`,
            // 2) due_day + current_term on school_settings
            `ALTER TABLE school_settings
               ADD COLUMN due_day INT NOT NULL DEFAULT 10,
               ADD COLUMN current_term VARCHAR(50) NOT NULL DEFAULT '1st Term'`,
            // 3) seed fee types
            `INSERT IGNORE INTO fee_types (name) VALUES ('School Fee'), ('Developmental Fee'), ('Exam Fee')`,
            // 4) copy v1 structure into v2 (idempotent)
            `INSERT IGNORE INTO fee_structure2 (fee_type, class_name, term, session, amount)
                SELECT 'School Fee', class_name, term, session, amount FROM fee_structure`
        ];
        let finished = 0;
        let missingTable = false;
        steps.forEach((sql, i) => {
            conn.query(sql, (qErr) => {
                // Duplicate-column race with a parallel boot is fine.
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME" && qErr.code !== "ER_DUP_ENTRY") {
                    console.log("Pack 15 migration step " + (i + 1) + " notice:", qErr.code || qErr.message);
                    // FIX: the add-on tables are created by a SEPARATE boot
                    // task - if it hasn't finished yet, retry the whole
                    // batch a few seconds later so seeding never gets lost.
                    if (qErr.code === "ER_NO_SUCH_TABLE") missingTable = true;
                }
                finished++;
                if (finished === steps.length) {
                    conn.end();
                    if (missingTable) return pack15Retry(attempt, { code: "ER_NO_SUCH_TABLE" });
                    console.log("Pack 15 setup ready (fee types, structure v2, settings v2).");
                }
            });
        });
    });
}
function pack15Retry(attempt, err) {
    if (attempt >= 6) {
        console.log("Pack 15 setup warning:", err.code || err.message || err);
        return;
    }
    setTimeout(() => runPack15Migrations(attempt + 1), 4000);
}
runPack15Migrations(1);

/* ------------------------------------------------------------------
   NEW (pack 17 - owner request): receipt photo on each recorded payment.
   Admin snaps/uploads the receipt written in school; parents see it in
   their portal; admin can remove it. Guarded + idempotent, same pattern
   as the pack-15 migrations above.
------------------------------------------------------------------ */
function runPack17Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack17Retry(attempt, err); }
        let missingTable = false;
        conn.query(
            `ALTER TABLE fee_payments ADD COLUMN receipt_path VARCHAR(255) NULL`,
            (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") {
                    console.log("Pack 17 migration notice:", qErr.code || qErr.message);
                    if (qErr.code === "ER_NO_SUCH_TABLE") missingTable = true;
                }
                conn.end();
                if (missingTable) return pack17Retry(attempt, { code: "ER_NO_SUCH_TABLE" });
                console.log("Pack 17 setup ready (payment receipt photos).");
            }
        );
    });
}
function pack17Retry(attempt, err) {
    if (attempt >= 6) {
        console.log("Pack 17 setup warning:", err.code || err.message || err);
        return;
    }
    setTimeout(() => runPack17Migrations(attempt + 1), 4000);
}
runPack17Migrations(1);

/* ------------------------------------------------------------------
   FIX (pack 20 - owner: "signature disappearing after some time"):
   keep a DATABASE COPY of every uploaded image, so a wiped disk can
   always be rebuilt. Same guarded/idempotent pattern as packs 15/17:
   ADD COLUMN is swallowed when it already exists (ER_DUP_FIELDNAME).
   Then a one-time hydration pass re-materialises any files already
   lost for rows that DO have a database copy.
------------------------------------------------------------------ */
function runPack20Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack20Retry(attempt, err); }
        const alters = [
            "ALTER TABLE signatures ADD COLUMN signature_data LONGBLOB NULL",
            "ALTER TABLE class_teacher_signatures ADD COLUMN signature_data LONGBLOB NULL",
            "ALTER TABLE students ADD COLUMN photo_data LONGBLOB NULL",
            "ALTER TABLE students ADD COLUMN city VARCHAR(120) NULL",
            "ALTER TABLE students ADD COLUMN state VARCHAR(120) NULL",
            "ALTER TABLE students ADD COLUMN country VARCHAR(120) NULL",
            "ALTER TABLE payment_submissions ADD COLUMN evidence_data LONGBLOB NULL",
            "ALTER TABLE fee_payments ADD COLUMN receipt_data LONGBLOB NULL"
        ];
        let missingTable = false;
        let i = 0;
        (function nextAlter() {
            if (i >= alters.length) {
                conn.end();
                console.log("Pack 20 setup ready (database-backed uploads).");
                return hydrateUploadedImages();
            }
            conn.query(alters[i++], (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") {
                    console.log("Pack 20 migration notice:", qErr.code || qErr.message);
                    if (qErr.code === "ER_NO_SUCH_TABLE") missingTable = true;
                }
                if (missingTable) { conn.destroy(); return pack20Retry(attempt, { code: "ER_NO_SUCH_TABLE" }); }
                nextAlter();
            });
        })();
    });
}
function pack20Retry(attempt, err) {
    if (attempt >= 6) {
        console.log("Pack 20 setup warning:", err.code || err.message || err);
        return;
    }
    setTimeout(() => runPack20Migrations(attempt + 1), 4000);
}
runPack20Migrations(1);

/* ------------------------------------------------------------------
   PACK 85 — Student Health Clinic upgrade:
   adds many medical fields (height, weight, BMI, genotype, family
   doctor, NHIS/insurance, current medications, last check-up, special
   needs) to the student_health table on EXISTING databases. Fresh
   installs already get them from the CREATE TABLE above. Uses the same
   guarded/idempotent ADD COLUMN pattern (ER_DUP_FIELDNAME swallowed),
   retried a few times in case the add-on tables are still being made.
------------------------------------------------------------------ */
function runPack85Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack85Retry(attempt, err); }
        const alters = [
            "ALTER TABLE student_health ADD COLUMN height_cm DECIMAL(5,2) NULL",
            "ALTER TABLE student_health ADD COLUMN weight_kg DECIMAL(5,2) NULL",
            "ALTER TABLE student_health ADD COLUMN bmi DECIMAL(4,1) NULL",
            "ALTER TABLE student_health ADD COLUMN genotype VARCHAR(10) DEFAULT ''",
            "ALTER TABLE student_health ADD COLUMN doctor_name VARCHAR(160) DEFAULT ''",
            "ALTER TABLE student_health ADD COLUMN doctor_phone VARCHAR(60) DEFAULT ''",
            "ALTER TABLE student_health ADD COLUMN insurance_no VARCHAR(120) DEFAULT ''",
            "ALTER TABLE student_health ADD COLUMN current_medications TEXT",
            "ALTER TABLE student_health ADD COLUMN last_checkup DATE NULL",
            "ALTER TABLE student_health ADD COLUMN special_needs TEXT"
        ];
        let missingTable = false;
        let i = 0;
        (function nextAlter() {
            if (i >= alters.length) {
                conn.end();
                console.log("Pack 85 setup ready (health record medical fields).");
                return;
            }
            conn.query(alters[i++], (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") {
                    console.log("Pack 85 migration notice:", qErr.code || qErr.message);
                    if (qErr.code === "ER_NO_SUCH_TABLE") missingTable = true;
                }
                if (missingTable) { conn.destroy(); return pack85Retry(attempt, { code: "ER_NO_SUCH_TABLE" }); }
                nextAlter();
            });
        })();
    });
}
function pack85Retry(attempt, err) {
    if (attempt >= 6) {
        console.log("Pack 85 setup warning:", err.code || err.message || err);
        return;
    }
    setTimeout(() => runPack85Migrations(attempt + 1), 4000);
}
runPack85Migrations(1);

/* ==================================================================
   NEW (pack 28 - owner: "Allow voice note ... also different chat for
   admin and teacher"): messages table grows:
     1. thread    - 'admin' or 'teacher' so the parent portal shows TWO
                    separate conversations (office vs class teacher).
     2. kind      - 'text' or 'voice'.
     3. duration  - voice-note length in seconds.
     4. voice_data + voice_mime - the audio lives IN the database
        (Render's disk is wiped on every deploy; DB is forever).
   Guarded + idempotent, same pattern as packs 15/17/20/22.
================================================================== */
function runPack28Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack28Retry(attempt, err); }
        const alters = [
            "ALTER TABLE messages ADD COLUMN thread VARCHAR(8) NOT NULL DEFAULT 'admin'",
            "ALTER TABLE messages ADD COLUMN kind VARCHAR(8) NOT NULL DEFAULT 'text'",
            "ALTER TABLE messages ADD COLUMN duration INT NULL",
            "ALTER TABLE messages ADD COLUMN voice_data LONGBLOB NULL",
            "ALTER TABLE messages ADD COLUMN voice_mime VARCHAR(64) NULL"
        ];
        let missingTable = false;
        let i = 0;
        (function nextAlter() {
            if (i >= alters.length) {
                // backfill: parent mail's thread is exactly who it was sent to
                conn.query("UPDATE messages SET thread = recipient_type WHERE sender_type = 'portal'", () => {
                    conn.end();
                    console.log("Pack 28 setup ready (voice notes + admin/teacher chat threads).");
                });
                return;
            }
            conn.query(alters[i++], (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") {
                    console.log("Pack 28 migration notice:", qErr.code || qErr.message);
                    if (qErr.code === "ER_NO_SUCH_TABLE") missingTable = true;
                }
                if (missingTable) { conn.destroy(); return pack28Retry(attempt, { code: "ER_NO_SUCH_TABLE" }); }
                nextAlter();
            });
        })();
    });
}
function pack28Retry(attempt, err) {
    if (attempt >= 6) {
        console.log("Pack 28 setup warning:", err.code || err.message || err);
        return;
    }
    setTimeout(() => runPack28Migrations(attempt + 1), 4000);
}
runPack28Migrations(1);

/* ==================================================================
   NEW (pack 29 - owner: "make all the ai working"): the admin can now
   add the free AI key INSIDE the app (AI Chat page) - it is stored in
   the `ai_config` table below and instantly wakes up EVERY AI feature
   (staff AI chat, exam question writer, website assistant). No Render
   dashboard, no redeploy. Guarded + idempotent like the packs above.
================================================================== */
function runPack29Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack29Retry(attempt, err); }
        conn.query(
            "CREATE TABLE IF NOT EXISTS ai_config (" +
            "id TINYINT PRIMARY KEY DEFAULT 1, " +
            "api_key VARCHAR(512) NULL, " +
            "base_url VARCHAR(255) NULL, " +
            "model VARCHAR(128) NULL, " +
            "updated_by VARCHAR(60) NULL, " +
            "updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)",
            (qErr) => {
                if (qErr) console.log("Pack 29 migration notice:", qErr.code || qErr.message);
                conn.end();
                if (!qErr) console.log("Pack 29 setup ready (AI key can be saved inside the app).");
            }
        );
    });
}
function pack29Retry(attempt, err) {
    if (attempt >= 6) { console.log("Pack 29 setup warning:", err.code || err.message || err); return; }
    setTimeout(() => runPack29Migrations(attempt + 1), 4000);
}
runPack29Migrations(1);

/* ==================================================================
   NEW (pack 32 - owner picked "push notifications" from the ideas
   menu): WEB PUSH. phones ring even when the app is fully closed.
   Two tables:
     push_keys          - the school's VAPID identity is created BY THE
                          APP on first boot and kept here forever (no
                          Render env vars needed - set them if you prefer).
     push_subscriptions - one row per phone that tapped "Enable alerts".
================================================================== */
function runPack32Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack32Retry(attempt, err); }
        const creates = [
            "CREATE TABLE IF NOT EXISTS push_keys (" +
            "id TINYINT PRIMARY KEY DEFAULT 1, " +
            "public_key VARCHAR(128) NOT NULL, " +
            "private_key VARCHAR(128) NOT NULL, " +
            "created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP)",
            "CREATE TABLE IF NOT EXISTS push_subscriptions (" +
            "id INT AUTO_INCREMENT PRIMARY KEY, " +
            "endpoint TEXT NOT NULL, " +
            "user_type VARCHAR(8) NOT NULL, " +
            "user_ref VARCHAR(64) NOT NULL, " +
            "keys_p256dh VARCHAR(128) NOT NULL, " +
            "keys_auth VARCHAR(64) NOT NULL, " +
            "created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP, " +
            "last_seen_at TIMESTAMP NULL, " +
            "UNIQUE KEY uq_push_endpoint (endpoint(180)))"
        ];
        let i = 0;
        (function nextC() {
            if (i >= creates.length) {
                conn.end();
                console.log("Pack 32 setup ready (web push).");
                pushInit(1); // identity comes after tables exist
                return;
            }
            conn.query(creates[i++], (qErr) => {
                if (qErr) console.log("Pack 32 migration notice:", qErr.code || qErr.message);
                nextC();
            });
        })();
    });
}
function pack32Retry(attempt, err) {
    if (attempt >= 6) { console.log("Pack 32 setup warning:", err.code || err.message || err); return; }
    setTimeout(() => runPack32Migrations(attempt + 1), 4000);
}
runPack32Migrations(1);

/* ------------------------------------------------------------------
   NEW (pack 22 - owner requests): announcement AUDIENCES
   (teacher/student/parent/general) + announcement-or-EVENT kind +
   exam timetable dates. Guarded + idempotent like packs 15/17/20.
------------------------------------------------------------------ */
function runPack22Migrations(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return pack22Retry(attempt, err); }
        const alters = [
            "ALTER TABLE announcements ADD COLUMN audience VARCHAR(16) NOT NULL DEFAULT 'general'",
            "ALTER TABLE announcements ADD COLUMN kind VARCHAR(16) NOT NULL DEFAULT 'announcement'",
            "ALTER TABLE announcements ADD COLUMN event_date DATE NULL",
            "ALTER TABLE exams ADD COLUMN exam_date DATE NULL"
        ];
        let missingTable = false;
        let i = 0;
        (function nextAlter() {
            if (i >= alters.length) {
                conn.end();
                console.log("Pack 22 setup ready (announcement audiences, exam dates).");
                return;
            }
            conn.query(alters[i++], (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") {
                    console.log("Pack 22 migration notice:", qErr.code || qErr.message);
                    if (qErr.code === "ER_NO_SUCH_TABLE") missingTable = true;
                }
                if (missingTable) { conn.destroy(); return pack22Retry(attempt, { code: "ER_NO_SUCH_TABLE" }); }
                nextAlter();
            });
        })();
    });
}
function pack22Retry(attempt, err) {
    if (attempt >= 6) {
        console.log("Pack 22 setup warning:", err.code || err.message || err);
        return;
    }
    setTimeout(() => runPack22Migrations(attempt + 1), 4000);
}
runPack22Migrations(1);

/* ------------------------------------------------------------------
   NEW (pack 23 - owner requests): messaging (parent<->teacher,
   parent<->school), portal + staff SETTINGS, teacher->class
   assignment, friendly receipt view. Guarded + idempotent, additive.
------------------------------------------------------------------ */
function runPack23Migrations() {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return setTimeout(runPack23Migrations, 4000); }
        const steps = [
            // Parent<->school message thread table (+ read_at drives notifications).
            `CREATE TABLE IF NOT EXISTS messages (
                id INT AUTO_INCREMENT PRIMARY KEY,
                sender_type VARCHAR(8) NOT NULL,
                sender_ref VARCHAR(64) NOT NULL,
                sender_name VARCHAR(160) DEFAULT '',
                recipient_type VARCHAR(8) NOT NULL,
                recipient_ref VARCHAR(64) DEFAULT '',
                recipient_class VARCHAR(120) DEFAULT '',
                body TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                read_at TIMESTAMP NULL DEFAULT NULL
            )`,
            // Which teacher teaches which class. Empty table = every teacher
            // sees all parent messages (safe default - nothing gets hidden).
            `CREATE TABLE IF NOT EXISTS teacher_classes (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(64) NOT NULL,
                class_name VARCHAR(120) NOT NULL,
                UNIQUE KEY tc_uniq (username, class_name)
            )`,
            // Optional portal password: when set it REPLACES the surname login.
            "ALTER TABLE students ADD COLUMN portal_password VARCHAR(255) NULL"
        ];
        let i = 0;
        (function next() {
            if (i >= steps.length) { conn.end(); console.log("Pack 23 setup ready (messages, settings, teacher classes)."); return; }
            conn.query(steps[i++], (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") console.log("Pack 23 migration notice:", qErr.code || qErr.message);
                next();
            });
        })();
    });
}
runPack23Migrations();

/* ------------------------------------------------------------------
   NEW (pack 86): staff-to-staff chat reuses the existing messages
   table with a message_type column ('parent' default, 'staff' for
   internal mail). Guarded + idempotent — never touches existing rows.
------------------------------------------------------------------ */
function runPack86Migrations() {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return setTimeout(runPack86Migrations, 4000); }
        conn.query(
            "ALTER TABLE messages ADD COLUMN message_type VARCHAR(20) NOT NULL DEFAULT 'parent'",
            (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME" && qErr.code !== "ER_NO_SUCH_TABLE") {
                    console.log("Pack 86 migration notice:", qErr.code || qErr.message);
                }
                conn.end();
                if (!qErr || qErr.code === "ER_DUP_FIELDNAME") {
                    console.log("Pack 86 setup ready (staff chat message_type).");
                }
            }
        );
    });
}
runPack86Migrations();

/* ------------------------------------------------------------------
   NEW (pack 37 - admission pipeline): enquiries can now carry gender /
   date of birth (collected at the one-tap ADMIT step), record WHICH
   student id the child became, and a 'declined' status. All guarded +
   idempotent + additive - existing enquiries keep working exactly as
   they did on pack 13.
------------------------------------------------------------------ */
function runPack37Migrations() {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return setTimeout(runPack37Migrations, 4000); }
        const steps = [
            "ALTER TABLE admission_enquiries ADD COLUMN gender VARCHAR(10) NULL",
            "ALTER TABLE admission_enquiries ADD COLUMN date_of_birth DATE NULL",
            "ALTER TABLE admission_enquiries ADD COLUMN admitted_student_id VARCHAR(64) NULL",
            "ALTER TABLE admission_enquiries ADD COLUMN admitted_at TIMESTAMP NULL DEFAULT NULL",
            "ALTER TABLE admission_enquiries MODIFY status ENUM('new','contacted','admitted','declined') NOT NULL DEFAULT 'new'"
        ];
        let i = 0;
        (function next() {
            if (i >= steps.length) { conn.end(); console.log("Pack 37 setup ready (admission pipeline)."); return; }
            conn.query(steps[i++], (qErr) => {
                if (qErr && qErr.code !== "ER_DUP_FIELDNAME") console.log("Pack 37 migration notice:", qErr.code || qErr.message);
                next();
            });
        })();
    });
}
runPack37Migrations();

/* ------------------------------------------------------------------
   NEW (pack 25 - owner: "Add exam and class timetable for admin and
   teachers, and it will display for students after been published").
   Two tables + publish gate: staff build freely, students/parents only
   ever see what admin has PUBLISHED. Guarded + idempotent.
------------------------------------------------------------------ */
function runPack25Migrations() {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return setTimeout(runPack25Migrations, 4000); }
        const steps = [
            `CREATE TABLE IF NOT EXISTS exam_timetable (
                id INT AUTO_INCREMENT PRIMARY KEY,
                class_name VARCHAR(120) NOT NULL,
                subject VARCHAR(160) NOT NULL,
                exam_date DATE NULL,
                start_time VARCHAR(10) DEFAULT '',
                end_time VARCHAR(10) DEFAULT '',
                published TINYINT(1) NOT NULL DEFAULT 0,
                created_by VARCHAR(64) DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )`,
            `CREATE TABLE IF NOT EXISTS class_timetable (
                id INT AUTO_INCREMENT PRIMARY KEY,
                class_name VARCHAR(120) NOT NULL,
                day_of_week VARCHAR(12) NOT NULL,
                period_no INT NOT NULL DEFAULT 1,
                start_time VARCHAR(10) DEFAULT '',
                end_time VARCHAR(10) DEFAULT '',
                subject VARCHAR(160) NOT NULL,
                published TINYINT(1) NOT NULL DEFAULT 0,
                created_by VARCHAR(64) DEFAULT '',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )`
        ];
        let i = 0;
        (function next() {
            if (i >= steps.length) { conn.end(); console.log("Pack 25 setup ready (timetables)."); return; }
            conn.query(steps[i++], (qErr) => {
                if (qErr) console.log("Pack 25 migration notice:", qErr.code || qErr.message);
                next();
            });
        })();
    });
}
runPack25Migrations();

/* =====================================================================
   NEW (pack 25): TIMETABLE API - staff CRUD + admin publish + portal.
===================================================================== */
["exam", "class"].forEach(function (kind) {
    const table = kind === "exam" ? "exam_timetable" : "class_timetable";

    // staff: read one class's rows
    app.get("/api/timetable/" + kind, requireLogin, (req, res) => {
        const cls = String(req.query.class_name || "");
        const orderBy = kind === "exam"
            ? "ORDER BY exam_date IS NULL, exam_date ASC, start_time ASC, id ASC"
            : "ORDER BY FIELD(day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), period_no ASC, id ASC";
        connection.query(
            "SELECT * FROM " + table + " WHERE class_name = ? " + orderBy + " LIMIT 400",
            [cls],
            (err, rows) => {
                if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
                res.json(rows);
            }
        );
    });

    // staff (admin + teacher): add a row
    app.post("/api/timetable/" + kind, requireLogin, (req, res) => {
        const cls = String(req.body.class_name || "").trim();
        const subject = String(req.body.subject || "").trim();
        if (!cls || !subject) return res.status(400).json({ message: "Class and subject are required." });
        let cols, vals;
        if (kind === "exam") {
            cols = "(class_name, subject, exam_date, start_time, end_time, created_by)";
            vals = [cls, subject, req.body.exam_date || null, String(req.body.start_time || ""), String(req.body.end_time || ""), req.session.username];
        } else {
            const day = String(req.body.day_of_week || "").trim();
            if (!day) return res.status(400).json({ message: "Day is required." });
            cols = "(class_name, day_of_week, period_no, start_time, end_time, subject, created_by)";
            vals = [cls, day, Number(req.body.period_no) || 1, String(req.body.start_time || ""), String(req.body.end_time || ""), subject, req.session.username];
        }
        connection.query(
            "INSERT INTO " + table + " " + cols + " VALUES (" + cols.replace(/\(|\)/g, "").split(",").map(() => "?").join(",") + ")",
            vals,
            (err) => {
                if (err) return res.status(500).json({ message: "Database error" });
                res.json({ message: "Added - remember to Publish when it is ready." });
            }
        );
    });

    app.delete("/api/timetable/" + kind + "/:id", requireLogin, (req, res) => {
        connection.query("DELETE FROM " + table + " WHERE id = ?", [req.params.id], (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Removed." });
        });
    });

    // publish gate: ADMIN ONLY - students never see unpublished rows
    app.post("/api/timetable/" + kind + "/publish", requireLogin, requireAdmin, (req, res) => {
        const cls = String(req.body.class_name || "").trim();
        const pub = req.body.published ? 1 : 0;
        if (!cls) return res.status(400).json({ message: "Class is required." });
        connection.query(
            "UPDATE " + table + " SET published = ? WHERE class_name = ?",
            [pub, cls],
            (err) => {
                if (err) return res.status(500).json({ message: "Database error" });
                res.json({ message: pub ? "Published - students & parents of " + cls + " can see it now." : "Unpublished - hidden from students again." });
            }
        );
    });

    // portal: student/parent reads ONLY published rows of their own class
    app.get("/portal/timetable/" + kind, (req, res) => {
        const sid = req.session && req.session.portalStudentId;
        if (!sid) return res.status(401).json({ message: "Not logged in" });
        connection.query("SELECT class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, stu) => {
            if (err || !stu.length) return res.json([]);
            const orderBy = kind === "exam"
                ? "ORDER BY exam_date IS NULL, exam_date ASC, start_time ASC, id ASC"
                : "ORDER BY FIELD(day_of_week,'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), period_no ASC, id ASC";
            connection.query(
                "SELECT * FROM " + table + " WHERE class_name = ? AND published = 1 " + orderBy + " LIMIT 400",
                [stu[0].class_name],
                (err2, rows) => {
                    if (err2) { if (err2.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.json([]); }
                    res.json(rows);
                }
            );
        });
    });
});

// Rebuild every missing upload file that HAS a database copy (runs once
// at boot; the request-time middleware covers anything saved later).
function hydrateUploadedImages() {
    const jobs = [
        ["signatures", "signature_path", "signature_data"],
        ["class_teacher_signatures", "signature_path", "signature_data"],
        ["students", "photo_path", "photo_data"],
        ["payment_submissions", "evidence_path", "evidence_data"],
        ["fee_payments", "receipt_path", "receipt_data"]
    ];
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return; }
        let done = 0, restored = 0;
        jobs.forEach(([table, pathCol, dataCol]) => {
            conn.query("SELECT ?? AS p, ?? AS d FROM ?? WHERE ?? IS NOT NULL", [pathCol, dataCol, table, dataCol], (qErr, rows) => {
                if (!qErr && rows) {
                    rows.forEach((r) => {
                        if (!r.p || !r.d) return;
                        const abs = path.join(__dirname, r.p);
                        if (fs.existsSync(abs)) return;
                        try {
                            fs.mkdirSync(path.dirname(abs), { recursive: true });
                            fs.writeFileSync(abs, r.d);
                            restored++;
                        } catch (e) { /* disk read-only? middleware will retry */ }
                    });
                }
                if (++done === jobs.length) {
                    if (restored) console.log(`Pack 20: rebuilt ${restored} uploaded image(s) from the database.`);
                    conn.end();
                }
            });
        });
    });
}

/* ==================================================================
   NEW (subject enable/disable - request #3): is_active column on the
   subjects table. Same guarded/idempotent pattern as above: check
   information_schema first, add once, fall back gracefully. When the
   column is missing the app behaves exactly as before (all subjects
   visible everywhere).
================================================================== */
let subjectActiveColReady = false;

function ensureSubjectActiveColumn(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) {
            conn.destroy();
            return subjectActiveRetry(attempt, err);
        }
        conn.query(
            `SELECT COUNT(*) AS c
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'subjects'
               AND COLUMN_NAME = 'is_active'`,
            (qErr, rows) => {
                if (qErr) {
                    conn.end();
                    return subjectActiveRetry(attempt, qErr);
                }
                if (rows && rows[0] && Number(rows[0].c) === 1) {
                    conn.end();
                    subjectActiveColReady = true;
                    console.log("Subject is_active column ready.");
                    return;
                }
                conn.query(
                    `ALTER TABLE subjects ADD COLUMN is_active TINYINT(1) NOT NULL DEFAULT 1`,
                    (aErr) => {
                        conn.end();
                        if (aErr) {
                            if (aErr.code === "ER_DUP_FIELDNAME") {
                                subjectActiveColReady = true;
                                console.log("Subject is_active column ready (added by a parallel boot).");
                                return;
                            }
                            return subjectActiveRetry(attempt, aErr);
                        }
                        subjectActiveColReady = true;
                        console.log("Subject is_active column added.");
                    }
                );
            }
        );
    });
}

function subjectActiveRetry(attempt, err) {
    const reason = err.code || err.message || err;
    if (attempt >= 3) {
        console.log("Subject setup warning: could not add the is_active column. Reason:", reason);
        console.log("  -> Everything keeps working; the Enable/Disable switch just stays off.");
        return;
    }
    console.log(`Subject setup: attempt ${attempt} failed (${reason}); retrying in 4s...`);
    setTimeout(() => ensureSubjectActiveColumn(attempt + 1), 4000);
}

ensureSubjectActiveColumn(1);

// Friendly fallback for add-on endpoints when the add-on tables do not
// exist yet (setup above failed and sql/addon_tables.sql was not run).
function addonTableMissing(res, err, verb) {
    if (err && err.code === "ER_NO_SUCH_TABLE") {
        return res.status(503).json({
            message: `Could not ${verb}: notice board / events storage is not initialised yet. Run the SQL in sql/addon_tables.sql and restart.`
        });
    }
    return null;
}

// Helper: run a widget query that must NEVER crash the dashboard -
// on error it logs and resolves with an empty array instead.
function safeQuery(sql, params) {
    return new Promise((resolve) => {
        connection.query(sql, params || [], (err, rows) => {
            if (err) {
                console.log("Dashboard widget query failed:", err.code || err);
                return resolve([]);
            }
            resolve(rows);
        });
    });
}

function countOf(rows) {
    return rows && rows[0] ? Number(rows[0].c) : 0;
}

// Aggregated stats for the NEW dashboard cards + charts.
// All SELECTs below are read-only and do not modify any data.
app.get("/dashboard-stats", requireLogin, async (req, res) => {
    try {
        const students = await safeQuery(`SELECT COUNT(*) AS c FROM students`);
        const subjects = await safeQuery(`SELECT COUNT(*) AS c FROM subjects`);
        const results  = await safeQuery(`SELECT COUNT(*) AS c FROM results`);
        const classes  = await safeQuery(`SELECT COUNT(*) AS c FROM classes`);
        const staff    = await safeQuery(`SELECT COUNT(*) AS c FROM users`);
        const exams    = await safeQuery(`SELECT COUNT(*) AS c FROM exams`);

        const studentsPerClass = await safeQuery(
            `SELECT class_name, COUNT(*) AS count
             FROM students
             GROUP BY class_name
             ORDER BY count DESC
             LIMIT 14`
        );

        const gradeDistribution = await safeQuery(
            `SELECT grade, COUNT(*) AS count
             FROM results
             GROUP BY grade`
        );

        res.json({
            students: countOf(students),
            subjects: countOf(subjects),
            results:  countOf(results),
            classes:  countOf(classes),
            staff:    countOf(staff),
            exams:    countOf(exams),
            studentsPerClass,
            gradeDistribution
        });
    } catch (err) {
        console.log(err);
        res.status(500).json({ message: "Could not load dashboard stats." });
    }
});

// Recent activity feed - composed from READ-ONLY queries on existing
// tables (latest saved results, updated exams, signatures on file).
app.get("/recent-activity", requireLogin, async (req, res) => {
    const items = [];

    const latestResults = await safeQuery(
        `SELECT student_name, subject, term, session, class_name
         FROM results ORDER BY id DESC LIMIT 5`
    );
    latestResults.forEach((r) => {
        items.push({
            type: "result",
            text: `Result saved: ${r.student_name} - ${r.subject} (${r.class_name}, ${r.term}, ${r.session})`,
            when: null
        });
    });

    const latestExams = await safeQuery(
        `SELECT title, updated_at FROM exams ORDER BY updated_at DESC LIMIT 3`
    );
    latestExams.forEach((x) => {
        items.push({
            type: "exam",
            text: `Exam saved/updated: "${x.title}"`,
            when: x.updated_at || null
        });
    });

    const signatures = await safeQuery(
        `SELECT role, updated_at FROM signatures`
    );
    signatures.forEach((s) => {
        items.push({
            type: "signature",
            text: `${s.role === "class_teacher" ? "Class Teacher" : "Principal"} signature is on file`,
            when: s.updated_at || null
        });
    });

    // Items with timestamps first (newest), then the rest
    items.sort((a, b) => {
        const ta = a.when ? new Date(a.when).getTime() : Infinity;
        const tb = b.when ? new Date(b.when).getTime() : Infinity;
        return tb - ta;
    });

    res.json(items.slice(0, 10));
});

// NEW: full student list for the read-only Students Directory page.
// (Named /students to complement - not replace - the existing
//  single-student route /student/:studentId, which is untouched.)
app.get("/students", requireLogin, (req, res) => {
    const status = String(req.query.status || "").trim().toLowerCase();
    let sql = "SELECT * FROM students";
    const params = [];

    /* Attendance and other pickers can request only active students. NULL
       is treated as active for records created before student statuses were
       introduced, matching the attendance register's roster rule. */
    if (status === "active") {
        sql += " WHERE status IS NULL OR LOWER(TRIM(status)) = 'active'";
    } else if (status) {
        sql += " WHERE LOWER(TRIM(status)) = ?";
        params.push(status);
    }
    sql += " ORDER BY class_name, full_name";

    connection.query(
        sql,
        params,
        (err, rows) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json(rows || []);
        }
    );
});

/* ---------------- Announcements (notice board) ---------------- */

// NEW (pack 22): whitelisted values shared by the announcement routes.
const ANN_AUDIENCES = ["teacher", "student", "parent", "general"];
// CHANGED (pack 21/22): audience + kind + event_date come along; older
// client pages that only read title/body are unaffected.
app.get("/api/announcements", requireLogin, (req, res) => {
    connection.query(
        `SELECT id, title, body, audience, kind, event_date, created_at
         FROM announcements ORDER BY created_at DESC LIMIT 50`,
        (err, rows) => {
            if (err) {
                console.log(err);
                const handled = addonTableMissing(res, err, "load announcements");
                if (handled) return handled;
                return res.status(500).json({ message: "Could not load announcements." });
            }
            res.json(rows);
        }
    );
});

app.post("/api/announcements", requireLogin, (req, res) => {
    const title = (req.body.title || "").trim();
    const body = (req.body.body || "").trim();
    /* NEW (pack 22 - owner: "let me decide if it will be for teacher or
       student or parents or general and also event"): audience + kind are
       whitelisted; an EVENT with a date also lands on the school events
       list, so it shows in Upcoming Events and calendars automatically. */
    const audience = ANN_AUDIENCES.includes(req.body.audience) ? req.body.audience : "general";
    const kind = req.body.kind === "event" ? "event" : "announcement";
    const eventDate = /^\d{4}-\d{2}-\d{2}$/.test(req.body.event_date || "") ? req.body.event_date : null;

    if (!title) {
        return res.status(400).json({ message: "Announcement title is required." });
    }
    if (kind === "event" && !eventDate) {
        return res.status(400).json({ message: "Pick the event date (or choose \"Announcement\" instead)." });
    }

    connection.query(
        `INSERT INTO announcements (title, body, audience, kind, event_date) VALUES (?, ?, ?, ?, ?)`,
        [title, body, audience, kind, eventDate],
        (err, result) => {
            if (err) {
                if (err.code === "ER_BAD_FIELD_ERROR") {
                    // first-boot window: pack-22 columns still migrating -
                    // fall back to the legacy columns so posting never fails.
                    return connection.query(
                        `INSERT INTO announcements (title, body) VALUES (?, ?)`,
                        [title, body],
                        () => res.json({ message: "Announcement posted (audience options unlock in one minute)." })
                    );
                }
                console.log(err);
                const handled = addonTableMissing(res, err, "save the announcement");
                if (handled) return handled;
                return res.status(500).json({ message: "Could not save announcement." });
            }
            if (kind === "event" && eventDate) {
                connection.query(
                    `INSERT INTO school_events (title, event_date, description) VALUES (?, ?, ?)`,
                    [title, eventDate, body || "Announcement event"],
                    () => {}
                );
            }
            /* NEW (pack 32): alert the audience's phones straight away.
               parent/student/general -> portal users; teacher/general ->
               staff. The bell already showed it inside the app; now the
               phone itself rings. */
            if (["parent", "student", "general"].indexOf(audience) !== -1) {
                amsPushAll("portal", {
                    title: "\u{1F4E2} " + title.slice(0, 60),
                    body: (body || title).slice(0, 100),
                    url: "/portal.html", tag: "ann-" + result.insertId
                });
            }
            if (["teacher", "general"].indexOf(audience) !== -1) {
                amsPushAll("staff", {
                    title: "\u{1F4E2} " + title.slice(0, 60),
                    body: (body || title).slice(0, 100),
                    url: "/teacher-dashboard.html", tag: "ann-" + result.insertId
                });
            }
            res.json({ message: kind === "event" ? "Event announced - it also appears in Upcoming Events." : "Announcement posted.", id: result.insertId });
        }
    );
});

// NEW (pack 22 - owner: "let me control what we were doing also"):
// EDIT an existing announcement/event (delete already existed).
app.put("/api/announcements/:id", requireLogin, (req, res) => {
    const title = (req.body.title || "").trim();
    const body = (req.body.body || "").trim();
    const audience = ANN_AUDIENCES.includes(req.body.audience) ? req.body.audience : "general";
    const kind = req.body.kind === "event" ? "event" : "announcement";
    const eventDate = kind === "event" && /^\d{4}-\d{2}-\d{2}$/.test(req.body.event_date || "") ? req.body.event_date : null;
    if (!title) return res.status(400).json({ message: "Announcement title is required." });
    connection.query(
        `UPDATE announcements SET title = ?, body = ?, audience = ?, kind = ?, event_date = ? WHERE id = ?`,
        [title, body, audience, kind, eventDate, req.params.id],
        (err, result) => {
            if (err) {
                if (err.code === "ER_BAD_FIELD_ERROR") return res.status(503).json({ message: "Announcements are warming up - try again in one minute." });
                console.log(err);
                return res.status(500).json({ message: "Could not update announcement." });
            }
            if (!result.affectedRows) return res.status(404).json({ message: "Announcement not found." });
            res.json({ message: "Announcement updated." });
        }
    );
});

// NEW (pack 22): the PORTAL's own notice board - everything for parents
// and students plus general news. Teacher-only items stay staff-only.
app.get("/portal/announcements", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        `SELECT id, title, body, audience, kind, event_date, created_at
         FROM announcements
         WHERE audience IN ('general', 'student', 'parent')
         ORDER BY created_at DESC LIMIT 20`,
        (err, rows) => {
            if (err) {
                if (err.code === "ER_BAD_FIELD_ERROR") return res.json([]);
                console.log(err);
                return res.status(500).json({ message: "Database error" });
            }
            res.json(rows);
        }
    );
});

// NEW (pack 22 - owner: "I can't see messages... in the website"): the
// PUBLIC notice board for the school website - general announcements +
// upcoming events only, nothing internal ever leaves this gate.
app.get("/api/announcements-public", (req, res) => {
    const out = { announcements: [], events: [] };
    connection.query(
        `SELECT id, title, body, created_at FROM announcements
         WHERE audience = 'general' AND kind = 'announcement'
         ORDER BY created_at DESC LIMIT 10`,
        (err, rows) => {
            if (!err && rows) out.announcements = rows;
            connection.query(
                `SELECT id, title, event_date, description FROM school_events
                 WHERE event_date >= CURDATE() ORDER BY event_date ASC LIMIT 10`,
                (err2, evs) => {
                    if (!err2 && evs) out.events = evs;
                    res.json(out);
                }
            );
        }
    );
});

app.delete("/api/announcements/:id", requireLogin, (req, res) => {
    connection.query(
        `DELETE FROM announcements WHERE id = ?`,
        [req.params.id],
        (err) => {
            if (err) {
                console.log(err);
                const handled = addonTableMissing(res, err, "delete the announcement");
                if (handled) return handled;
                return res.status(500).json({ message: "Could not delete announcement." });
            }
            res.json({ message: "Announcement deleted." });
        }
    );
});

/* ---------------- School events (calendar) ---------------- */

app.get("/api/events", requireLogin, (req, res) => {
    connection.query(
        `SELECT id, title, event_date, description
         FROM school_events ORDER BY event_date ASC LIMIT 200`,
        (err, rows) => {
            if (err) {
                console.log(err);
                const handled = addonTableMissing(res, err, "load events");
                if (handled) return handled;
                return res.status(500).json({ message: "Could not load events." });
            }
            res.json(rows);
        }
    );
});

app.post("/api/events", requireLogin, (req, res) => {
    const title = (req.body.title || "").trim();
    const eventDate = (req.body.event_date || "").trim();
    const description = (req.body.description || "").trim();

    if (!title || !eventDate) {
        return res.status(400).json({ message: "Event title and date are required." });
    }

    connection.query(
        `INSERT INTO school_events (title, event_date, description) VALUES (?, ?, ?)`,
        [title, eventDate, description || null],
        (err, result) => {
            if (err) {
                console.log(err);
                const handled = addonTableMissing(res, err, "save the event");
                if (handled) return handled;
                return res.status(500).json({ message: "Could not save event." });
            }
            res.json({ message: "Event added.", id: result.insertId });
        }
    );
});

app.delete("/api/events/:id", requireLogin, (req, res) => {
    connection.query(
        `DELETE FROM school_events WHERE id = ?`,
        [req.params.id],
        (err) => {
            if (err) {
                console.log(err);
                const handled = addonTableMissing(res, err, "delete the event");
                if (handled) return handled;
                return res.status(500).json({ message: "Could not delete event." });
            }
            res.json({ message: "Event deleted." });
        }
    );
});

/* ================== END OF ADD-ON MODULE ================== */

// Ensure the uploads folder exists
const uploadDir = path.join(__dirname, "images", "students");
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer config: store photos in images/students, named by student ID
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        const rawId = req.body.student_id || "unknown";
        // Strip anything that isn't a letter, number, dash, or underscore -
        // prevents path traversal (e.g. "../../something") via this field.
        const studentId = rawId.replace(/[^a-zA-Z0-9_-]/g, "") || "unknown";
        const ext = path.extname(file.originalname).replace(/[^a-zA-Z0-9.]/g, "");
        cb(null, `${studentId}${ext}`);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
    fileFilter: (req, file, cb) => {
        const allowed = ["image/jpeg", "image/png", "image/jpg"];
        if (allowed.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error("Only JPG and PNG images are allowed."));
        }
    }
});

// Separate multer instance for bulk student uploads - keeps the file in
// memory only (never written to disk) since we just need to read its rows.
// FIX: accept by file EXTENSION as well as MIME type. Phones (Android
// file pickers, iOS Safari, Google Drive) routinely send .xlsx/.xls/.csv
// as application/octet-stream or with an empty MIME type; a strict MIME
// whitelist made those uploads fail with "Only .xlsx, .xls, or .csv files
// are allowed" / a fake network error. The rows are parsed and validated
// afterwards, so being permissive here is safe.
const uploadExcel = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 20 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const name = String((file && file.originalname) || "").toLowerCase();
        if (/\.(xlsx|xls|csv)$/.test(name)) return cb(null, true);
        const allowed = [
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "text/csv",
            "application/csv",
            "application/octet-stream",
            "application/zip"
        ];
        if (allowed.includes(String((file && file.mimetype) || "").toLowerCase())) {
            cb(null, true);
        } else {
            cb(new Error("Only .xlsx, .xls, or .csv files are allowed."));
        }
    }
});

/* FIX: dedicated receiver for Third Term Results. The shared uploadExcel
   instance rejected common browser MIME types (application/octet-stream,
   empty, zip) and answered LIMIT_FILE_SIZE as plain text — the page's
   r.json() then threw and showed "Network error while parsing the workbook."
   Accept by file extension, allow 20 MB, and always reply with JSON. */
const THIRD_TERM_MAX_BYTES = 20 * 1024 * 1024;
const uploadThirdTermExcel = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: THIRD_TERM_MAX_BYTES },
    fileFilter: (req, file, cb) => {
        const name = String((file && file.originalname) || "").toLowerCase();
        if (/\.(xlsx|xls)$/.test(name)) return cb(null, true);
        const mime = String((file && file.mimetype) || "").toLowerCase();
        const okMime = [
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-excel",
            "application/octet-stream",
            "application/zip",
            "application/x-zip-compressed"
        ].indexOf(mime) !== -1;
        if (okMime) return cb(null, true);
        cb(new Error("Only .xlsx or .xls workbooks are allowed."));
    }
});

function receiveThirdTermWorkbook(req, res, next) {
    uploadThirdTermExcel.single("file")(req, res, function (err) {
        if (!err) return next();
        if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
            return res.status(400).json({
                message: "The workbook is too large (maximum 20 MB). Remove unused sheets or images and try again."
            });
        }
        return res.status(400).json({
            message: (err && err.message) || "Could not receive the uploaded workbook."
        });
    });
}

const storeDir = path.join(__dirname, "uploads", "store");
try { fs.mkdirSync(storeDir, { recursive: true }); } catch (e) { /* exists */ }

const storeStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, storeDir),
    filename: (req, file, cb) => {
        const cleanName = typeof fixUtf8 === "function" ? fixUtf8(file.originalname || "file") : (file.originalname || "file");
        const safe = cleanName.replace(/[^a-zA-Z0-9.\-_؀-ۿ]/g, "_");
        cb(null, "store_" + Date.now() + "_" + safe);
    }
});
const uploadStore = multer({
    storage: storeStorage,
    limits: { fileSize: 50 * 1024 * 1024 } // 50MB max per file
});

// Signatures: stored in images/signatures, named by role (class_teacher.png, principal.png)
const signatureDir = path.join(__dirname, "images", "signatures");
if (!fs.existsSync(signatureDir)) {
    fs.mkdirSync(signatureDir, { recursive: true });
}

const signatureStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, signatureDir);
    },
    filename: (req, file, cb) => {
        const rawRole = req.body.role || "unknown";
        const role = rawRole.replace(/[^a-zA-Z0-9_-]/g, "") || "unknown";
        cb(null, `${role}.png`);
    }
});

// NEW (per-class class-teacher signatures): class-named files
// (ct_<class>.png) live beside the role files, so every class keeps its own
// signature image. The client appends class_name BEFORE the image field,
// exactly like req.body.role is read above, so the filename callback can
// see it.
const classSignatureStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, signatureDir);
    },
    filename: (req, file, cb) => {
        const rawClass = req.body.class_name || "unknown";
        const safeClass = rawClass.replace(/[^a-zA-Z0-9_-]/g, "_") || "unknown";
        cb(null, `ct_${safeClass}.png`);
    }
});

const uploadClassSignature = multer({
    storage: classSignatureStorage,
    limits: { fileSize: 2 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowed = ["image/jpeg", "image/png", "image/jpg"];
        if (allowed.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error("Only JPG and PNG images are allowed."));
        }
    }
});

const uploadSignature = multer({
    storage: signatureStorage,
    limits: { fileSize: 2 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowed = ["image/jpeg", "image/png", "image/jpg"];
        if (allowed.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error("Only JPG and PNG images are allowed."));
        }
    }
});

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"));
});

console.log("THIS IS MY SERVER.JS")
app.post("/save-result", requireLogin, writeRateLimit, (req, res) => {

    const {
        student_id,
        student_name,
        class_name,
        term,
        session,
        subject,
        first_test,
        second_test,
        note_score,
        attendance_score,
        ca_score,
        exam_score,
        total_score,
        grade
    } = req.body;

    const sql = `
    INSERT INTO results
        (student_id, student_name, class_name, term, session, subject,
        first_test, second_test, note_score, attendance_score,
        ca_score, exam_score, total, grade)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

    `;
console.log(req.body);
    connection.query(
        sql,
        [
            student_id,
            student_name,
            class_name,
            term,
            session,
            subject,
            first_test,
            second_test,
            note_score,
            attendance_score,
            ca_score,
            exam_score,
            total_score,
            grade
        ],
        (err, result) => {

            if (err) {
                console.log(err);
                res.status(500).send("Error saving result");
            } else {
                res.json({
                    message: "Result saved successfully",
                id: result.insertId
            });
            }

        }
    );

});

app.put("/update-result/:id", requireLogin, writeRateLimit, (req, res) => {

    const id = req.params.id;

    const {
        student_id,
        student_name,
        class_name,
        term,
        session,
        subject,
        first_test,
        second_test,
        note_score,
        attendance_score,
        ca_score,
        exam_score,
        total_score,
        grade
    } = req.body;

    const sql = `
        UPDATE results SET
            student_id = ?,
            student_name = ?,
            class_name = ?,
            term = ?,
            session = ?,
            subject = ?,
            first_test = ?,
            second_test = ?,
            note_score = ?,
            attendance_score = ?,
            ca_score = ?,
            exam_score = ?,
            total = ?,
            grade = ?
        WHERE id = ?
    `;

    connection.query(
        sql,
        [
            student_id,
            student_name,
            class_name,
            term,
            session,
            subject,
            first_test,
            second_test,
            note_score,
            attendance_score,
            ca_score,
            exam_score,
            total_score,
            grade,
            id
        ],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Error updating result");
            }
            if (result.affectedRows === 0) {
                return res.status(404).json({ message: "Result not found" });
            }
            res.json({ message: "Result updated successfully" });
        }
    );

});

app.get("/search-result/:studentId", publishResultGate, (req, res) => { // CHANGED (pack 13): portal/anon users need login + published term; staff skip the gate completely
    const studentId = req.params.studentId;
    const term = req.query.term;
    const session = req.query.session;

    // FIX (teacher dashboard "Load Results" was erroring): term and session
    // are OPTIONAL again. The student result page always sends both and gets
    // EXACTLY the same behaviour as before (including the 3rd Term
    // cumulative-average enrichment below); the teacher dashboard "Student
    // Scores" loader sends neither because it wants EVERY saved row for the
    // student - requiring them turned its call into a 400 error.
    let sql = "SELECT * FROM results WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))";
    const params = [studentId, studentId];
    if (term) { sql += " AND TRIM(term) = TRIM(?)"; params.push(term); }
    if (session) { sql += " AND TRIM(session) = TRIM(?)"; params.push(session); }

    connection.query(sql, params, (err, currentTermResults) => {
        if (err) {
            console.log(err);
            return res.status(500).send("Database Error");
        }

        // For 3rd Term, also pull 1st and 2nd Term results for the same
        // student and session so we can show a cumulative subject average.
        if (term === "3rd Term" && currentTermResults.length > 0) {
            const priorSql = "SELECT * FROM results WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?))) AND session = ? AND term IN ('1st Term','2nd Term')";

            connection.query(priorSql, [studentId, studentId, session], (err2, priorResults) => {
                if (err2) {
                    console.log(err2);
                    return res.status(500).send("Database Error");
                }

                const firstTermBySubject = {};
                const secondTermBySubject = {};

                priorResults.forEach(row => {
                    // Match subjects tolerantly (tashkeel / spacing / case
                    // differences between terms must not hide a score).
                    const key = normalizeClassName(row.subject);
                    if (!key) return;
                    if (row.term === "1st Term") {
                        firstTermBySubject[key] = row.total;
                    } else if (row.term === "2nd Term") {
                        secondTermBySubject[key] = row.total;
                    }
                });

                const enriched = currentTermResults.map(row => {
                    const subjectKey = normalizeClassName(row.subject);
                    const firstTotal = subjectKey && firstTermBySubject.hasOwnProperty(subjectKey) ? Number(firstTermBySubject[subjectKey]) : null;
                    const secondTotal = subjectKey && secondTermBySubject.hasOwnProperty(subjectKey) ? Number(secondTermBySubject[subjectKey]) : null;
                    const thirdTotal = Number(row.total);

                    // The three term scores are combined per subject: the
                    // cumulative average uses whichever of the 1st/2nd/3rd
                    // term totals exist for that subject.
                    const termsPresent = [firstTotal, secondTotal, thirdTotal].filter(v => v !== null);
                    // Per-subject cumulative total shown on the 3rd-term
                    // report: the available 1st + 2nd + 3rd term scores.
                    // Keep it separate from the /100 cumulative average.
                    const cumulativeTotal = [firstTotal, secondTotal, thirdTotal].reduce(
                        (sum, value) => Number.isFinite(value) ? sum + value : sum,
                        0
                    );
                    const cumulativeAverage = termsPresent.length > 0
                        ? Math.round((termsPresent.reduce((a, b) => a + b, 0) / termsPresent.length) * 100) / 100
                        : null;
                    // Grade is now based on the THREE-TERM average (not just
                    // the 3rd term), matching the pass rule (50% and above).
                    const cumulativeGrade = cumulativeAverage !== null && cumulativeAverage !== undefined
                        ? amsGradeForTotal(cumulativeAverage)
                        : (row.grade || "");

                    return {
                        ...row,
                        first_term_total: firstTotal,
                        second_term_total: secondTotal,
                        third_term_total: thirdTotal,
                        cumulative_total: cumulativeTotal,
                        cumulative_average: cumulativeAverage,
                        cumulative_grade: cumulativeGrade
                    };
                });

                return res.json(enriched);
            });
        } else {
            res.json(currentTermResults);
        }
    });
});

/* FIX (pack 88): /student-position was returning position 0 (report
   shows "-") whenever the student's current class name differed from the
   class stored on their result rows - e.g. after promotion, or when
   Arabic class names differed by tashkeel / extra spaces. Now the class
   is resolved from the student's OWN result rows, all class/subject/id
   matching is tolerant, and the 3rd Term ranking uses the cumulative
   three-term average - exactly the number the report sheet displays. */
function amsTolerantId(a, b) {
    return String(a || "").trim().toLowerCase() === String(b || "").trim().toLowerCase();
}
function amsTermOrder(term) {
    const t = String(term || "").trim();
    if (t === "3rd Term") return 3;
    if (t === "2nd Term") return 2;
    return 1;
}
/* rows: {student_id, class_name, subject, term, total} for ONE class +
   session. Ranks students by their average total (per-term) or, for
   3rd Term, by Grand Total ÷ (subjects × 3):
     Grand Total = every 1st + 2nd + 3rd term score
       (13 subjects → 13×100×3 = 3900)
     Average     = Grand Total ÷ (subjects × 3)
       (3900 ÷ 39 = 100)
   That average decides class position. Ties share the same position.
   Returns { position, total }. */
function amsRankClassResults(rows, term, targetStudentId) {
    const isThird = term === "3rd Term";
    const perSubject = {};   // sid -> subjectKey -> { term: total }
    const perTermAvg = {};   // sid -> { sum, count }
    const hasThird = {};     // sid -> true (only rank 3rd-term students)

    (rows || []).forEach(r => {
        const sid = String(r.student_id || "").trim();
        if (!sid) return;
        const total = Number(r.total);
        if (!isFinite(total)) return;
        if (isThird) {
            const key = normalizeClassName(r.subject);
            if (!key) return;
            if (!perSubject[sid]) perSubject[sid] = {};
            if (!perSubject[sid][key]) perSubject[sid][key] = {};
            perSubject[sid][key][String(r.term || "").trim()] = total;
            if (String(r.term || "").trim() === "3rd Term") hasThird[sid] = true;
        } else {
            if (!perTermAvg[sid]) perTermAvg[sid] = { sum: 0, count: 0 };
            perTermAvg[sid].sum += total;
            perTermAvg[sid].count++;
        }
    });

    const averages = {};
    if (isThird) {
        Object.keys(perSubject).forEach(sid => {
            if (!hasThird[sid]) return; // only rank students with a 3rd term result
            const subjects = perSubject[sid];
            let grand = 0;
            let nSubjects = 0;
            Object.keys(subjects).forEach(key => {
                const terms = subjects[key];
                // Count only subjects the student sat in 3rd Term — same
                // set the report sheet lists. Missing 1st/2nd scores are
                // 0, and the divisor is always subjects × 3.
                if (!Object.prototype.hasOwnProperty.call(terms, "3rd Term")) return;
                nSubjects++;
                grand += (Number(terms["1st Term"]) || 0)
                    + (Number(terms["2nd Term"]) || 0)
                    + (Number(terms["3rd Term"]) || 0);
            });
            averages[sid] = nSubjects ? grand / (nSubjects * 3) : 0;
        });
    } else {
        Object.keys(perTermAvg).forEach(sid => {
            const a = perTermAvg[sid];
            averages[sid] = a.count ? a.sum / a.count : 0;
        });
    }

    const sids = Object.keys(averages);
    sids.sort((a, b) => averages[b] - averages[a] || String(a).localeCompare(String(b)));

    let position = 0;
    let lastAvg = null;
    let lastPos = 0;
    sids.forEach((sid, idx) => {
        if (lastAvg === null || averages[sid] < lastAvg) {
            lastPos = idx + 1;
            lastAvg = averages[sid];
        }
        if (amsTolerantId(sid, targetStudentId)) position = lastPos;
    });

    return { position: position, total: sids.length };
}
/* A student's 1st/2nd-term rows may sit under a DIFFERENT class name
   than their 3rd-term class (promotion / class change mid-session).
   The report sheet still combines those terms (it looks the student up
   by id), so the ranking must use the same numbers - append the target
   student's own prior-term rows to the class rows before ranking. */
function amsAppendOwnPriorRows(classRows, ownPriorRows, targetStudentId) {
    const out = Array.isArray(classRows) ? classRows.slice() : [];
    (ownPriorRows || []).forEach(r => {
        if (amsTolerantId(r.student_id, targetStudentId)) out.push(r);
    });
    return out;
}

app.get("/student-position/:studentId", portalOwnerGate, (req, res) => { // CHANGED (pack 13): portal/anon users - owner only; staff unchanged
    const studentId = String(req.params.studentId || "").trim();
    const className = (req.query.className || "").trim();
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();

    if (!className || !term || !session) {
        return res.status(400).json({ message: "className, term, and session are required." });
    }

    // Resolve the class from the student's OWN result rows for this
    // term/session (prefer one matching the caller's hint). This survives
    // promotion and Arabic spelling differences.
    connection.query(
        `SELECT DISTINCT class_name FROM results
         WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))
           AND TRIM(term) = TRIM(?) AND TRIM(session) = TRIM(?)`,
        [studentId, studentId, term, session],
        (err, ownRows) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            const ownClasses = (ownRows || []).map(r => r.class_name).filter(Boolean);
            const resolvedClass = ownClasses.find(c => classNamesMatch(c, className)) || ownClasses[0] || className;

            const termFilter = term === "3rd Term" ? "term IN ('1st Term','2nd Term','3rd Term')" : "term = ?";
            const sql = `SELECT student_id, class_name, subject, term, total
                         FROM results WHERE session = ? AND ${termFilter}`;
            const params = term === "3rd Term" ? [session] : [session, term];
            connection.query(sql, params, (err2, rows) => {
                if (err2) {
                    console.log(err2);
                    return res.status(500).send("Database Error");
                }
                // JS-side class filter: tashkeel / spacing differences in
                // other students' class names never hide ranking rows.
                const classRows = (rows || []).filter(r => classNamesMatch(r.class_name, resolvedClass));
                const doRank = (finalRows) => {
                    const rank = amsRankClassResults(finalRows, term, studentId);
                    res.json({ position: rank.position, total: rank.total, class_name: resolvedClass });
                };
                if (term !== "3rd Term") return doRank(classRows);
                // Merge the student's own 1st/2nd-term rows (any class) so
                // their cumulative average matches the report sheet exactly.
                connection.query(
                    `SELECT student_id, class_name, subject, term, total FROM results
                     WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))
                       AND session = ? AND term IN ('1st Term','2nd Term')`,
                    [studentId, studentId, session],
                    (eOwn, ownRows) => {
                        if (eOwn) { console.log(eOwn); return doRank(classRows); }
                        doRank(amsAppendOwnPriorRows(classRows, ownRows, studentId));
                    }
                );
            });
        }
    );
});



app.get("/student/:studentId", portalOwnerGate, (req, res) => { // CHANGED (pack 13): portal/anon users - owner only; staff unchanged

    const studentId = String(req.params.studentId || "").trim();

    const sql = "SELECT * FROM students WHERE TRIM(student_id) = ? OR LOWER(TRIM(student_id)) = LOWER(?) LIMIT 1";

    connection.query(sql, [studentId, studentId], (err, results) => {

        if (err) {
            console.log(err);
            res.status(500).send("Database Error");
        } else {
            res.json(results || []);
        }

    });

});

// SECURITY (audited, INTENTIONALLY PUBLIC): the public result-checking
// page (student-result.html -> js/result.js) renders report cards for
// parents/students who are NOT logged in, and needs the head-teacher /
// principal / class-teacher signature images to do so. This endpoint only
// returns role labels + signature image file paths (no financial or
// personal data), so it is deliberately left open. If report cards ever
// move fully behind a login, add requireLogin here.
app.get("/signatures", (req, res) => {
    const isStaff = !!(req.session && req.session.userId);
    const isPortal = !!(req.session && req.session.portalStudentId);
    if (!isStaff && !isPortal) return res.status(401).json({ message: "Not logged in" });
    connection.query("SELECT role, signature_path FROM signatures", (err, rows) => {
        if (err) {
            console.log(err);
            return res.status(500).send("Database Error");
        }
        res.json(rows);
    });
});

// Handles both a drawn signature (canvas converted to a PNG file on the
// client) and a real uploaded image - both arrive here as a normal file
// upload, so the server treats them identically.
app.post("/save-signature", requireLogin, writeRateLimit, uploadSignature.single("signature"), (req, res) => {
    const role = req.body.role;

    // CHANGED (signature management, request #4): four staff roles are
    // now accepted instead of two. Same route, same storage, same
    // signatures table - only the allowed role list grew.
    const ALLOWED_SIGNATURE_ROLES = ["class_teacher", "principal", "vice_principal", "head_teacher"];
    // NEW (pack 17 - owner: "add all user space for signature"): every
    // login user's own slot is also accepted (staff_<username>, letters/
    // numbers/underscore only, so no path tricks are possible).
    const isStaffSlot = /^staff_[a-z0-9_]{1,40}$/.test(role || "");
    if (!role || (!ALLOWED_SIGNATURE_ROLES.includes(role) && !isStaffSlot)) {
        return res.status(400).json({ message: "Role must be one of: " + ALLOWED_SIGNATURE_ROLES.join(", ") + " (or a staff_ user slot)." });
    }

    if (!req.file) {
        return res.status(400).json({ message: "No signature image received." });
    }

    const signaturePath = `images/signatures/${req.file.filename}`;
    // FIX (pack 20): also store the image bytes in the database so the
    // signature survives the host wiping its disk (auto-rebuilt on request).
    const sigData = fs.readFileSync(req.file.path);

    queryImageSave(
        `INSERT INTO signatures (role, signature_path, signature_data) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE signature_path = VALUES(signature_path), signature_data = VALUES(signature_data), updated_at = CURRENT_TIMESTAMP`,
        [role, signaturePath, sigData],
        `INSERT INTO signatures (role, signature_path) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE signature_path = VALUES(signature_path), updated_at = CURRENT_TIMESTAMP`,
        [role, signaturePath],
        (err) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error saving signature." });
            }
            res.json({ message: "Signature saved successfully.", path: signaturePath });
        }
    );
});

app.delete("/delete-signature/:role", requireLogin, (req, res) => {
    const role = req.params.role;

    connection.query(
        "DELETE FROM signatures WHERE role = ?",
        [role],
        (err) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error deleting signature." });
            }
            res.json({ message: "Signature removed." });
        }
    );
});

/* ==================================================================
   NEW (per-class class-teacher signatures, owner request):
   "space to accept many signatures and assign them to classes, so the
   signature appears on its own class, not just random class."
   Public read (the result pages need it, mirror of /signatures);
   save/delete stay behind login. Nothing here replaces the existing
   /signatures flow - classes without an assignment still fall back to
   the shared class_teacher signature exactly as before.

   SECURITY (audited, INTENTIONALLY PUBLIC): like /signatures, this feeds
   the public result-checking page and only returns class names +
   signature image file paths (no financial/personal data), so it stays
   open on purpose. Writes (save/delete below) remain behind requireLogin.
================================================================== */

app.get("/class-signatures", (req, res) => {
    const isStaff = !!(req.session && req.session.userId);
    const isPortal = !!(req.session && req.session.portalStudentId);
    if (!isStaff && !isPortal) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        "SELECT class_name, signature_path FROM class_teacher_signatures ORDER BY class_name",
        (err, rows) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json(rows);
        }
    );
});

app.post("/save-class-signature", requireLogin, writeRateLimit, uploadClassSignature.single("signature"), (req, res) => {
    const className = (req.body.class_name || "").trim();

    if (!className) {
        return res.status(400).json({ message: "Please choose the class first." });
    }
    if (!req.file) {
        return res.status(400).json({ message: "No signature image received." });
    }

    const signaturePath = `images/signatures/${req.file.filename}`;
    // FIX (pack 20): database copy, same as /save-signature.
    const sigData = fs.readFileSync(req.file.path);

    queryImageSave(
        `INSERT INTO class_teacher_signatures (class_name, signature_path, signature_data) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE signature_path = VALUES(signature_path), signature_data = VALUES(signature_data), updated_at = CURRENT_TIMESTAMP`,
        [className, signaturePath, sigData],
        `INSERT INTO class_teacher_signatures (class_name, signature_path) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE signature_path = VALUES(signature_path), updated_at = CURRENT_TIMESTAMP`,
        [className, signaturePath],
        (err) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error saving signature." });
            }
            res.json({ message: "Signature saved for " + className + ".", path: signaturePath });
        }
    );
});

app.delete("/class-signature/:className", requireLogin, (req, res) => {
    connection.query(
        "DELETE FROM class_teacher_signatures WHERE class_name = ?",
        [req.params.className],
        (err) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error deleting signature." });
            }
            res.json({ message: "Class signature removed." });
        }
    );
});

function autoStoreExamToVault(title, class_name, subject, term, session, duration, instructions, body_html) {
    const vaultDir = path.join(__dirname, "uploads", "store");
    try { fs.mkdirSync(vaultDir, { recursive: true }); } catch (e) {}

    connection.query(
        "SELECT id FROM school_file_store WHERE folder_path = '/' AND file_name = 'Saved Exams' AND is_folder = 1",
        (err, rows) => {
            if (err) return;
            if (!rows || !rows.length) {
                connection.query("INSERT INTO school_file_store (folder_path, file_name, original_name, is_folder) VALUES ('/', 'Saved Exams', 'Saved Exams', 1)", () => {});
            }
        }
    );

    const safeName = `${class_name}_${subject}_${title}`.replace(/[^a-zA-Z0-9\-_]/g, "_");
    const timestamp = Date.now();

    /* CHANGED (pack 82): ONE self-contained printable .html per exam - no more
       duplicate bare-Arial .doc + "_sheet.html" pair. body_html already carries
       the full letterhead cover markup, so linking the REAL /css/exam.css makes
       the stored copy render EXACTLY like Create Exam (letterhead, Sakkal
       Majalla + fallbacks, spacing, margins, A4, Arabic) - and it auto-opens
       the print dialog on load. */
    const printContent = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${title} - ${class_name} - ${subject}</title>
<link rel="stylesheet" href="/css/exam.css">
<style>
/* Inline fallback so the exam renders correctly even if /css/exam.css is unreachable */
body.exam-body{font-family:'Sakkal Majalla','Traditional Arabic','Amiri',serif;direction:rtl;text-align:right;padding:12mm 18mm;background:#fff;}
.exam-flow{direction:ltr;}
.page-one{padding:3mm 24mm 12mm 14mm;display:flex;flex-direction:column;}
.cover-header{text-align:center;}
.cover-bismillah{display:block;width:42mm;margin:0 auto 3mm;}
.cover-logo{display:block;width:40mm;margin:0 auto 2mm;}
.cover-arabic-name{font-size:30pt;font-weight:700;line-height:1.3;text-align:center;margin:2mm 0 2.5mm;}
.cover-english-name{font-family:'Times New Roman',serif;font-size:17pt;font-weight:700;text-align:center;margin:0 0 5mm;}
.cover-divider{height:5mm;background:#000;margin:0 -20mm 6mm -10mm;}
.cover-address,.cover-tel,.cover-email{font-family:'Times New Roman',serif;font-size:16pt;font-weight:700;text-align:center;margin:0 0 3mm;}
.cover-motto{display:flex;justify-content:space-between;font-family:'Times New Roman',serif;font-size:18pt;font-weight:700;margin:0 0 4mm;}
.cover-exam-period{font-size:20pt;font-weight:700;line-height:1.6;text-align:center;margin:0 0 8mm;}
.cover-info-table{width:100%;border-collapse:collapse;margin:0 0 4mm;}
.cover-info-table td{font-size:20pt;font-weight:700;line-height:1.8;padding:1.5mm 2px;border:none;text-align:right;}
.cover-info-table .blank-line{border-bottom:2px solid #000;}
.cover-info-table .blank-line-short{border-bottom:2px solid #000;width:45mm;}
.cover-instructions{margin:4mm 0 0;font-size:20pt;font-weight:700;line-height:1.58;}
.cover-instructions ol{list-style-type:decimal;padding-right:1.4em;margin:0;font-size:20pt;font-weight:700;line-height:1.58;}
.cover-footer{margin-top:auto;}
.cover-wish{font-size:10pt;text-align:left;}
.cover-code{font-size:16pt;font-weight:700;text-align:center;margin:2mm 0 0;}
p,li{font-size:inherit;line-height:inherit;margin-bottom:10px;}
@page{size:A4;margin:0;}
@media print{body{padding:0;margin:0;}}
</style>
</head>
<body class="exam-body">
<div class="exam-flow">
${body_html}
</div>
<script>window.addEventListener("load", function () { window.print(); });</script>
</body>
</html>`;

    const printFilename = `store_exam_${timestamp}_${safeName}.html`;
    const printPath = path.join(vaultDir, printFilename);
    const printOriginalName = `${class_name} - ${subject} - ${title} (Printable).html`;

    fs.writeFile(printPath, printContent, "utf8", (err) => {
        if (!err) {
            connection.query(
                "INSERT INTO school_file_store (folder_path, file_name, original_name, file_size, file_type, file_path, is_folder) VALUES (?, ?, ?, ?, ?, ?, 0)",
                ["/Saved Exams", printOriginalName, printOriginalName, Buffer.byteLength(printContent, "utf8"), "text/html", printFilename],
                () => {}
            );
        }
    });
}

app.post("/save-exam", requireLogin, writeRateLimit, (req, res) => {
    const { id, title, class_name, subject, term, session, duration, instructions, body_html } = req.body;
    const examDate = /^\d{4}-\d{2}-\d{2}$/.test(req.body.exam_date || "") ? req.body.exam_date : null;

    if (!title || !class_name || !subject || !term || !session || !body_html) {
        return res.status(400).json({ message: "Title, class, subject, term, session, and content are all required." });
    }

    autoStoreExamToVault(title, class_name, subject, term, session, duration, instructions, body_html);

    if (id) {
        // Update an existing exam
        connection.query(
            `UPDATE exams SET title=?, class_name=?, subject=?, term=?, session=?, duration=?, instructions=?, body_html=?, exam_date=? WHERE id=?`,
            [title, class_name, subject, term, session, duration || null, instructions || null, body_html, examDate, id],
            (err) => {
                if (err && err.code === "ER_BAD_FIELD_ERROR") {
                    return connection.query(
                        `UPDATE exams SET title=?, class_name=?, subject=?, term=?, session=?, duration=?, instructions=?, body_html=? WHERE id=?`,
                        [title, class_name, subject, term, session, duration || null, instructions || null, body_html, id],
                        (err2) => {
                            if (err2) { console.log(err2); return res.status(500).json({ message: "Error updating exam." }); }
                            res.json({ message: "Exam updated successfully.", id });
                        }
                    );
                }
                if (err) {
                    console.log(err);
                    return res.status(500).json({ message: "Error updating exam." });
                }
                res.json({ message: "Exam updated successfully.", id });
            }
        );
    } else {
        // Create a new exam
        connection.query(
            `INSERT INTO exams (title, class_name, subject, term, session, duration, instructions, body_html, created_by, exam_date)
             VALUES (?,?,?,?,?,?,?,?,?,?)`,
            [title, class_name, subject, term, session, duration || null, instructions || null, body_html, req.session.username, examDate],
            (err, result) => {
                if (err && err.code === "ER_BAD_FIELD_ERROR") {
                    return connection.query(
                        `INSERT INTO exams (title, class_name, subject, term, session, duration, instructions, body_html, created_by)
                         VALUES (?,?,?,?,?,?,?,?,?)`,
                        [title, class_name, subject, term, session, duration || null, instructions || null, body_html, req.session.username],
                        (err2, result2) => {
                            if (err2) { console.log(err2); return res.status(500).json({ message: "Error saving exam." }); }
                            res.json({ message: "Exam saved successfully.", id: result2.insertId });
                        }
                    );
                }
                if (err) {
                    console.log(err);
                    return res.status(500).json({ message: "Error saving exam." });
                }
                res.json({ message: "Exam saved successfully.", id: result.insertId });
            }
        );
    }
});

// NEW (pack 22 - owner: exam timetable visible to parents/students):
// the pupil's OWN class papers only, newest dated first. Nothing about
// the exam content ever leaves this route - just the schedule.
app.get("/portal/exams", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        "SELECT class_name FROM students WHERE student_id = ? LIMIT 1",
        [sid],
        (err, stu) => {
            if (err || !stu.length) return res.json([]);
            connection.query(
                `SELECT id, title, subject, term, session, duration, exam_date
                 FROM exams WHERE class_name = ?
                 ORDER BY exam_date IS NULL, exam_date DESC, updated_at DESC LIMIT 40`,
                [stu[0].class_name],
                (err2, rows) => {
                    if (err2) {
                        if (err2.code === "ER_BAD_FIELD_ERROR") return res.json([]);
                        console.log(err2);
                        return res.status(500).json({ message: "Database error" });
                    }
                    res.json(rows);
                }
            );
        }
    );
});

/* =====================================================================
   NEW (pack 23): PORTAL SETTINGS - change password + contact details.
===================================================================== */
app.post("/portal/change-password", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    const current = String(req.body.current || "");
    const nextPw  = String(req.body.newPassword || "");
    if (!current || nextPw.length < 4) {
        return res.status(400).json({ message: "New password must be at least 4 characters." });
    }
    connection.query("SELECT * FROM students WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err || !rows.length) return res.status(500).json({ message: "Database error" });
        const st = rows[0];
        const setNew = () => {
            bcrypt.hash(nextPw, 10, (hErr, hash) => {
                if (hErr) return res.status(500).json({ message: "Could not set password" });
                connection.query(
                    "UPDATE students SET portal_password = ? WHERE student_id = ?",
                    [hash, sid],
                    (uErr) => {
                        if (uErr) return res.status(500).json({ message: "Database error" });
                        res.json({ message: "Password changed. Use it next time you log in." });
                    }
                );
            });
        };
        // Verify the CURRENT one first: custom hash if set, else legacy surname rule.
        if (st.portal_password) {
            return bcrypt.compare(current, st.portal_password, (cErr, match) => {
                if (cErr || !match) return res.status(401).json({ message: "Current password is wrong." });
                setNew();
            });
        }
        const fullName = (st.full_name || "").trim();
        const surname  = fullName ? fullName.split(/\s+/).pop() : "";
        const ok = current.toLowerCase() === surname.toLowerCase()
                || current.toLowerCase() === fullName.toLowerCase();
        if (!ok) return res.status(401).json({ message: "Current password (surname) is wrong." });
        setNew();
    });
});

app.post("/portal/profile", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    // Only the contact fields a parent may correct - nothing academic.
    connection.query(
        "UPDATE students SET parent_name = ?, parent_phone = ?, address = ? WHERE student_id = ?",
        [String(req.body.parent_name || "").slice(0, 160), String(req.body.parent_phone || "").slice(0, 40), String(req.body.address || "").slice(0, 255), sid],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Details saved." });
        }
    );
});

/* =====================================================================
   NEW (pack 23 - owner: "View takes me to a blank page - fix that"):
   friendly receipt viewer for school-recorded payments. If the file or
   its database copy is missing, the parent sees a clear message instead
   of a blank tab.
===================================================================== */
app.get("/portal/receipt/:id", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).send("Not logged in");
    const friendly = (title, msg) => res.status(200).send(
        "<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<title>Receipt</title><style>body{font-family:Arial,sans-serif;background:#f4f7f5;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;}" +
        ".card{background:#fff;border-radius:14px;padding:28px 24px;max-width:340px;text-align:center;box-shadow:0 8px 24px rgba(0,0,0,.08);}" +
        "h2{color:#14532d;margin:0 0 8px;font-size:18px;}p{color:#5B6B62;font-size:14px;line-height:1.5;margin:0;}</style></head>" +
        "<body><div class='card'><h2>" + title + "</h2><p>" + msg + "</p></div></body></html>"
    );
    connection.query("SELECT receipt_path, receipt_data FROM fee_payments WHERE id = ? AND student_id = ? LIMIT 1", [req.params.id, sid], (err, rows) => {
        if (err) return res.status(500).send("Database error");
        if (!rows.length) return friendly("Not found", "This payment does not belong to your child.");
        const pay = rows[0];
        if (!pay.receipt_path) return friendly("No receipt yet", "The school has not snapped the receipt for this payment yet. Please check back later or ask at the office.");
        const rel = String(pay.receipt_path).replace(/^\/+/, "");
        const abs = path.join(__dirname, rel);
        if (fs.existsSync(abs)) return res.sendFile(abs);
        // File wiped by the host? Rebuild it from the pack-20 database copy.
        if (pay.receipt_data) {
            try {
                fs.mkdirSync(path.dirname(abs), { recursive: true });
                fs.writeFileSync(abs, pay.receipt_data);
                return res.sendFile(abs);
            } catch (e) { /* fall through to friendly note */ }
        }
        return friendly("Receipt unavailable", "This receipt was recorded before photo-backup started, so the picture is no longer on the server. The PAYMENT itself is safely recorded - the school can re-snap the receipt at the office if you need the image.");
    });
});

/* =====================================================================
   NEW (pack 23): MESSAGING + NOTIFICATIONS
   Parent/Student <-> Class Teacher, Parent/Student <-> Administration.
   read_at = NULL drives the unread badges (the "notifications").
===================================================================== */

// ---- PORTAL side ----
app.get("/portal/messages", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        `SELECT id, sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, created_at, read_at,
                thread, kind, duration
         FROM messages
         WHERE (sender_type = 'portal' AND sender_ref = ?)
            OR (recipient_type = 'parent' AND recipient_ref = ?)
         ORDER BY created_at ASC LIMIT 300`,
        [sid, sid],
        (err, rows) => {
            if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

app.get("/portal/messages/unread", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        "SELECT COUNT(*) AS c FROM messages WHERE recipient_type = 'parent' AND recipient_ref = ? AND read_at IS NULL",
        [sid],
        (err, rows) => {
            if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json({ count: 0 }); return res.status(500).json({ message: "Database error" }); }
            res.json({ count: rows[0].c });
        }
    );
});

app.post("/portal/messages", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    const to = req.body.to === "teacher" ? "teacher" : "admin";
    const body = String(req.body.body || "").trim().slice(0, 2000);
    if (!body) return res.status(400).json({ message: "Write a message first." });
    connection.query("SELECT full_name, class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, stu) => {
        if (err || !stu.length) return res.status(500).json({ message: "Database error" });
        const student = stu[0];
        // CHANGED (pack 28): thread = who the parent wrote to, so the two
        // conversations (office / class teacher) stay separate.
        connection.query(
            `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread)
             VALUES ('portal', ?, ?, ?, '', ?, ?, ?)`,
            [sid, (student.full_name || sid) + " (parent)", to, to === "teacher" ? (student.class_name || "") : "", body, to],
            (iErr) => {
                if (iErr) return res.status(500).json({ message: "Database error" });
                /* NEW (pack 32): ping the right staff phones. office mail
                   rings the admins; class-teacher mail rings the teachers
                   mapped to that class (confidentiality rules kept). */
                const payload = {
                    title: "\u{1F4AC} New message from " + (student.full_name || "a parent") + "'s parent",
                    body: body.slice(0, 90),
                    url: "/chat.html", tag: "chat-" + sid + "-" + to
                };
                if (to === "admin") {
                    connection.query("SELECT username FROM users WHERE role = 'admin'", [], (aErr, adm) => {
                        if (!aErr && adm) amsPushSend("staff", adm.map(r => r.username), payload);
                    });
                } else if (student.class_name) {
                    connection.query("SELECT username FROM teacher_classes WHERE class_name = ?", [student.class_name], (tErr, tch) => {
                        if (!tErr && tch) amsPushSend("staff", tch.map(r => r.username), payload);
                    });
                }
                res.json({ message: "Message sent to the " + (to === "teacher" ? "class teacher" : "school office") + "." });
            }
        );
    });
});

app.post("/portal/messages/read", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        "UPDATE messages SET read_at = NOW() WHERE recipient_type = 'parent' AND recipient_ref = ? AND read_at IS NULL",
        [sid],
        () => res.json({ message: "ok" })
    );
});

// ---- STAFF side ----
// Which messages may this staff member see?
// CHANGED (pack 25 - owner: "Build confidentiality in the project -
// teacher can't be seeing chat between admin and parents and at others
// also"): teachers ONLY ever see parent->teacher mail for THEIR OWN
// assigned classes. No more "no classes = see everything" fallback
// (that leaked other classes' chats). Admin->parent replies stay
// invisible to teachers; admins keep full oversight.
function staffMessageFilter(req, cb) {
    const me = req.session.username;
    const isAdmin = req.session.role === "admin";
    if (isAdmin) return cb(null, null); // admins see everything school-bound
    connection.query("SELECT class_name FROM teacher_classes WHERE username = ?", [me], (err, rows) => {
        if (err) return cb(null, false); // treat as no mapping
        cb(null, (rows || []).map(r => r.class_name));
    });
}

app.get("/api/messages", requireLogin, (req, res) => {
    const me = req.session.username;
    const isAdmin = req.session.role === "admin";
    staffMessageFilter(req, (fErr, myClasses) => {
        connection.query(
            `SELECT id, sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, created_at, read_at,
                    thread, kind, duration
             FROM messages ORDER BY created_at DESC LIMIT 400`,
            (err, rows) => {
                if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
                const mine = (rows || []).filter(m => {
                    if (m.sender_type === "staff" && m.sender_ref === me) return true; // my own replies
                    if (m.recipient_type === "staff" && m.recipient_ref === me) return true; // messages sent to me!
                    if (m.sender_type !== "portal") return false;                      // other staff's threads
                    if (isAdmin) return true;                                          // admin sees all parent mail
                    // teacher: parent mail bound for teachers; honour class mapping,
                    // empty mapping = see NOTHING (pack 25 - confidentiality).
                    if (m.recipient_type === "teacher") {
                        if (!myClasses || !myClasses.length) return false; // pack 25: no fallback - confidentiality
                        return myClasses.indexOf(m.recipient_class) !== -1;
                    }
                    return false;
                });
                res.json(mine);
            }
        );
    });
});

app.get("/api/messages/unread", requireLogin, (req, res) => {
    const me = req.session.username;
    const isAdmin = req.session.role === "admin";
    staffMessageFilter(req, (fErr, myClasses) => {
        connection.query(
            `SELECT recipient_type, recipient_class FROM messages
             WHERE sender_type = 'portal' AND read_at IS NULL`, // only unread INCOMING parent mail
            (err, rows) => {
                if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json({ count: 0 }); return res.status(500).json({ message: "Database error" }); }
                const count = (rows || []).filter(m => {
                    if (isAdmin) return true;
                    if (m.recipient_type === "teacher") {
                        if (!myClasses || !myClasses.length) return false; // pack 25: no fallback - confidentiality
                        return myClasses.indexOf(m.recipient_class) !== -1;
                    }
                    return false;
                }).length;
                res.json({ count });
            }
        );
    });
});

app.post("/api/messages", requireLogin, (req, res) => {
    const me = req.session.username;
    const studentId = String(req.body.student_id || "").trim();
    const body = String(req.body.body || "").trim().slice(0, 2000);
    if (!studentId || !body) return res.status(400).json({ message: "Recipient and message are required." });
    const thread = req.body.thread === "teacher" ? "teacher" : "admin";
    connection.query("SELECT full_name FROM students WHERE student_id = ? LIMIT 1", [studentId], (err, stu) => {
        if (err) return res.status(500).json({ message: "Database error" });
        if (!stu.length) {
            // Check if recipient is a teacher/admin user
            connection.query("SELECT username AS full_name, role FROM users WHERE username = ? LIMIT 1", [studentId], (err2, uRows) => {
                if (err2 || !uRows || !uRows.length) {
                    return res.status(404).json({ message: "No recipient with that ID - check it and try again." });
                }
                const rec = uRows[0];
                connection.query(
                    `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread)
                     VALUES ('staff', ?, ?, 'staff', ?, '', ?, ?)`,
                    [me, me + " (" + req.session.role + ")", studentId, body, thread],
                    (iErr) => {
                        if (iErr) return res.status(500).json({ message: "Database error" });
                        res.json({ message: "Message sent to staff member." });
                    }
                );
            });
            return;
        }
        connection.query(
            `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread)
             VALUES ('staff', ?, ?, 'parent', ?, '', ?, ?)`,
            [me, me + " (" + req.session.role + ")", studentId, body, thread],
            (iErr) => {
                if (iErr) return res.status(500).json({ message: "Database error" });
                amsPushSend("portal", [studentId], {
                    title: "\u{1F4AC} New message from " + (thread === "teacher" ? "your class teacher" : "the school office"),
                    body: body.slice(0, 90),
                    url: "/portal.html", tag: "chat-" + studentId + "-" + thread
                });
                res.json({ message: "Reply sent to the parent." });
            }
        );
    });
});

app.post("/api/messages/read", requireLogin, (req, res) => {
    const me = req.session.username;
    const isAdmin = req.session.role === "admin";
    staffMessageFilter(req, (fErr, myClasses) => {
        connection.query(
            `SELECT id, recipient_type, recipient_class FROM messages WHERE sender_type = 'portal' AND read_at IS NULL`,
            (err, rows) => {
                if (err) return res.json({ message: "ok" });
                const ids = (rows || []).filter(m => {
                    if (isAdmin) return true;
                    if (m.recipient_type === "teacher") {
                        if (!myClasses || !myClasses.length) return false; // pack 25: no fallback - confidentiality
                        return myClasses.indexOf(m.recipient_class) !== -1;
                    }
                    return false;
                }).map(m => m.id);
                if (!ids.length) return res.json({ message: "ok" });
                const safeIds = ids.map(function(id){ return parseInt(id, 10); }).filter(function(n){ return Number.isFinite(n); });
                if (!safeIds.length) return res.json({ message: "ok" });
                connection.query("UPDATE messages SET read_at = NOW() WHERE id IN (" + safeIds.join(",") + ")", () => res.json({ message: "ok" }));
            }
        );
    });
});

/* ==========================================================================
   NEW (pack 28 - owner requests): CHAT EXTRAS.
   1) /api/chat-students  - staff searches for a parent to START a chat
      with ("select who I want to chat with"). Teachers are limited to
      their mapped classes (pack-25 confidentiality, same rule as mail).
   2) /api/messages/voice + /portal/messages/voice - voice notes. The
      audio is stored IN the messages table (voice_data) - never on the
      ephemeral server disk, so it survives every Render deploy.
   3) GET /voice/:id - streams one voice note, only to people allowed to
      see that conversation.
   ========================================================================== */
// NEW (Pack 50): Delete a single chat message
app.delete("/api/messages/:id", requireLogin, (req, res) => {
    const id = req.params.id;
    connection.query("DELETE FROM messages WHERE id = ?", [id], (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ message: "Database Error" });
        }
        res.json({ message: "Message deleted.", count: result.affectedRows });
    });
});

// NEW (Pack 50/53): Clear an entire conversation with a student/parent
app.delete("/api/messages/thread/:sid", requireLogin, (req, res) => {
    const sid = req.params.sid;
    connection.query(
        "DELETE FROM messages WHERE (sender_type = 'portal' AND sender_ref = ?) OR (recipient_type = 'parent' AND recipient_ref = ?) OR sender_ref = ? OR recipient_ref = ?",
        [sid, sid, sid, sid],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Database Error" });
            }
            res.json({ message: "Conversation cleared.", count: result.affectedRows });
        }
    );
});

app.get("/api/chat-students", requireLogin, (req, res) => {
    const q = String(req.query.q || "").trim();
    const isAdmin = req.session.role === "admin";
    staffMessageFilter(req, (fErr, myClasses) => {
        let sql = "SELECT student_id, full_name, class_name, gender, 'student' AS account_type FROM students";
        const params = [];
        const where = [];
        if (q) {
            where.push("(full_name LIKE ? OR student_id LIKE ?)");
            params.push("%" + q + "%", "%" + q + "%");
        }
        if (!isAdmin) {
            if (!myClasses || !myClasses.length) {
                where.push("1 = 0");
            } else {
                where.push("class_name IN (" + myClasses.map(() => "?").join(",") + ")");
                params.push.apply(params, myClasses);
            }
        }
        if (where.length) sql += " WHERE " + where.join(" AND ");
        sql += " ORDER BY full_name LIMIT 100";

        connection.query(sql, params, (err, students) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            let userSql = "SELECT username AS student_id, username AS full_name, role AS class_name, 'user' AS account_type FROM users";
            const userParams = [];
            if (q) {
                userSql += " WHERE username LIKE ? OR role LIKE ?";
                userParams.push("%" + q + "%", "%" + q + "%");
            }
            userSql += " ORDER BY username LIMIT 50";
            connection.query(userSql, userParams, (uErr, users) => {
                const combined = (students || []).concat(users || []);
                res.json(combined);
            });
        });
    });
});

// multer keeps the audio in memory only (it goes straight to the DB)
const uploadVoice = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: 6 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const ok = /^(audio|video)\/(webm|ogg|mpeg|mp3|mp4|x-m4a|m4a|aac|wav)/.test(file.mimetype || "");
        cb(ok ? null : new Error("Only audio recordings are allowed."), ok);
    }
});

app.post("/api/messages/voice", requireLogin, (req, res) => {
    uploadVoice.single("voice")(req, res, (upErr) => {
        if (upErr || !req.file) return res.status(400).json({ message: (upErr && upErr.message) || "No recording received." });
        const me = req.session.username;
        const studentId = String(req.body.student_id || "").trim();
        const thread = req.body.thread === "teacher" ? "teacher" : "admin";
        const duration = Math.max(1, Math.min(600, parseInt(req.body.duration, 10) || 0)) || null;
        if (!studentId) return res.status(400).json({ message: "Student is required." });
        connection.query("SELECT full_name FROM students WHERE student_id = ? LIMIT 1", [studentId], (err, stu) => {
            if (err) return res.status(500).json({ message: "Database error" });
            if (!stu.length) return res.status(404).json({ message: "No student with that ID." });
            connection.query(
                `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread, kind, duration, voice_data, voice_mime)
                 VALUES ('staff', ?, ?, 'parent', ?, '', ?, ?, 'voice', ?, ?, ?)`,
                [me, me + " (" + req.session.role + ")", studentId, "\u{1F3D9} Voice note", thread, duration, req.file.buffer, req.file.mimetype],
                (iErr) => {
                    if (iErr) { console.log(iErr); return res.status(500).json({ message: "Database error" }); }
                    res.json({ message: "Voice note sent." });
                }
            );
        });
    });
});

app.post("/portal/messages/voice", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    uploadVoice.single("voice")(req, res, (upErr) => {
        if (upErr || !req.file) return res.status(400).json({ message: (upErr && upErr.message) || "No recording received." });
        const to = req.body.to === "teacher" ? "teacher" : "admin";
        const duration = Math.max(1, Math.min(600, parseInt(req.body.duration, 10) || 0)) || null;
        connection.query("SELECT full_name, class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, stu) => {
            if (err || !stu.length) return res.status(500).json({ message: "Database error" });
            const student = stu[0];
            connection.query(
                `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread, kind, duration, voice_data, voice_mime)
                 VALUES ('portal', ?, ?, ?, '', ?, ?, ?, 'voice', ?, ?, ?)`,
                [sid, (student.full_name || sid) + " (parent)", to, to === "teacher" ? (student.class_name || "") : "",
                 "\u{1F3D9} Voice note", to, duration, req.file.buffer, req.file.mimetype],
                (iErr) => {
                    if (iErr) { console.log(iErr); return res.status(500).json({ message: "Database error" }); }
                    res.json({ message: "Voice note sent to the " + (to === "teacher" ? "class teacher" : "school office") + "." });
                }
            );
        });
    });
});

// stream ONE voice note; only people who may see the conversation
app.get("/voice/:id", (req, res) => {
    const id = Number(req.params.id) || 0;
    const sid = req.session && req.session.portalStudentId;
    const staffUser = req.session && req.session.userId;
    if (!sid && !staffUser) return res.status(401).send("Not logged in");
    connection.query(
        "SELECT id, sender_type, sender_ref, recipient_ref, recipient_class, voice_data, voice_mime, kind FROM messages WHERE id = ? LIMIT 1",
        [id],
        (err, rows) => {
            if (err) return res.status(500).send("Database error");
            const m = rows && rows[0];
            if (!m || m.kind !== "voice" || !m.voice_data) return res.status(404).send("Voice note not found");
            const serve = () => {
                res.setHeader("Content-Type", m.voice_mime || "audio/webm");
                res.setHeader("Content-Length", m.voice_data.length);
                res.setHeader("Cache-Control", "private, max-age=86400");
                res.send(m.voice_data);
            };
            if (sid) {
                // parent may only open their own conversation's audio
                if (m.sender_ref === sid || m.recipient_ref === sid) return serve();
                return res.status(403).send("Not your conversation");
            }
            if (req.session.role === "admin") return serve();
            if (m.sender_type === "staff" && m.sender_ref === req.session.username) return serve(); // my own note
            staffMessageFilter(req, (fErr, myClasses) => {
                if (m.sender_type === "portal" && myClasses && myClasses.indexOf(m.recipient_class) !== -1) return serve();
                return res.status(403).send("Not your conversation");
            });
        }
    );
});

/* ==========================================================================
   NEW (pack 27 - owner: "Can we build ai inside the project"): AI CORE.
   --------------------------------------------------------------------------
   The AI brain lives OUTSIDE this server. It speaks the standard OpenAI
   chat-completions format, so it works out of the box with a FREE Google
   Gemini key and also with Groq/OpenRouter/OpenAI - just set environment
   values (Render dashboard -> Environment):
     AI_API_KEY  = the secret key (free one: aistudio.google.com -> Get API key)
     AI_BASE_URL = default https://generativelanguage.googleapis.com/v1beta/openai
     AI_MODEL    = default gemini-2.5-flash. When the configured model is
                   retired/unavailable the automatic fallback chain below
                   keeps working (CHANGED pack 106 - see AI_FALLBACK_MODELS)
   With no key set, every AI endpoint answers a friendly "not switched on
   yet" message and the rest of the system is completely unaffected.
   Privacy: only the prompt text (e.g. a topic, or an average score) is
   ever sent to the AI service - never passwords or whole databases.
   ========================================================================== */
/* CHANGED (pack 29): the AI key can now come from TWO places -
     1) the ai_config row the admin saves inside the app (wins), or
     2) the classic environment variables (still work exactly as before).
   aiConfig() resolves them with a 10-second cache so chats stay fast. */
const AI_ENV = {
    key:  String(process.env.AI_API_KEY || "").trim(),
    base: String(process.env.AI_BASE_URL || "https://generativelanguage.googleapis.com/v1beta/openai").trim().replace(/\/+$/, ""),
    model:String(process.env.AI_MODEL || "gemini-2.5-flash").trim()
};
let aiCfgCache = { at: 0, cfg: null };
function aiConfig() {
    if (aiCfgCache.cfg && Date.now() - aiCfgCache.at < 10000) return Promise.resolve(aiCfgCache.cfg);
    return new Promise(function (resolve) {
        connection.query("SELECT * FROM ai_config WHERE id = 1", function (err, rows) {
            let cfg;
            if (err) { // table not created yet (or db hiccup) - env still works
                cfg = { key: AI_ENV.key, base: AI_ENV.base, model: AI_ENV.model, source: AI_ENV.key ? "env" : "" };
            } else {
                const db = rows && rows.length ? rows[0] : {};
                const dbKey = String(db.api_key || "").trim();
                cfg = {
                    key:  dbKey || AI_ENV.key,
                    base: String(db.base_url || "").trim().replace(/\/+$/, "") || AI_ENV.base,
                    model:String(db.model || "").trim() || AI_ENV.model,
                    source: dbKey ? "app" : (AI_ENV.key ? "env" : ""),
                    updatedBy: db.updated_by || "", updatedAt: db.updated_at || null
                };
            }
            aiCfgCache = { at: Date.now(), cfg: cfg };
            resolve(cfg);
        });
    });
}
function aiBustCache() { aiCfgCache = { at: 0, cfg: null }; }
function aiNotReady(res) {
    return res.status(503).json({
        error: "The AI is not switched on yet. The admin can switch it on in one minute from the AI Chat page (the switch-on card). Nothing else is affected."
    });
}

/* One small POST to the AI service (OpenAI chat-completions shape), built on
   node's own http/https so NO new packages are needed. 30s hard timeout. */
function aiChat(messages, opts, cfg) {
    cfg = cfg || AI_ENV; // safety net - callers always pass it
    opts = opts || {};
    return new Promise(function (resolve, reject) {
        const body = JSON.stringify({
            model: cfg.model,
            messages: messages,
            temperature: typeof opts.temperature === "number" ? opts.temperature : 0.5,
            max_tokens: opts.maxTokens || 900
        });
        let u;
        try { u = new URL(cfg.base + "/chat/completions"); }
        catch (e) { return reject(new Error("AI_BASE_URL is not a valid address")); }
        const lib = u.protocol === "http:" ? require("http") : require("https");
        const req = lib.request({
            method: "POST",
            hostname: u.hostname,
            port: u.port || (u.protocol === "http:" ? 80 : 443),
            path: u.pathname + u.search,
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + cfg.key,
                "Content-Length": Buffer.byteLength(body)
            }
        }, function (aiRes) {
            let raw = "";
            aiRes.on("data", function (c) {
                raw += c;
                if (raw.length > 200000) req.destroy(new Error("AI reply too large")); // safety cap
            });
            aiRes.on("end", function () {
                let data = null;
                try { data = JSON.parse(raw); } catch (e) { return reject(new Error("AI reply was not JSON")); }
                if (aiRes.statusCode >= 400) {
                    const m = data && data.error && data.error.message ? data.error.message : ("AI service error " + aiRes.statusCode);
                    return reject(new Error(m));
                }
                const choice = data && data.choices && data.choices[0];
                const text = choice && choice.message ? (choice.message.content || "") : "";
                if (!text.trim()) return reject(new Error("AI sent an empty reply"));
                /* CHANGED (pack 31 - owner: "the ai is giving incomplete
                   message"): also surface finish_reason so the caller can
                   see when the model ran out of room and ask it to
                   continue instead of showing a half answer. */
                resolve({ text: text, finishReason: (choice.finish_reason || "") });
            });
        });
        req.setTimeout(30000, function () { req.destroy(new Error("The AI took too long - please try again")); });
        req.on("error", reject);
        req.write(body);
        req.end();
    });
}

/* FIX (pack 30 - owner: "ai keeps saying The AI stumbled"): Google retired
   gemini-2.0-flash, which was the old default, so every call failed. Now
   the caller's model is tried first, then these current FREE models in
   order - whichever answers becomes the working one. Only "model problem"
   errors move on to the next model; real errors (bad key, quota, network)
   are reported immediately.
   CHANGED (pack 106 - owner: "the public AI is saying 'The assistant is
   taking a short break - please try again in a moment' to every question"):
   the whole list was still 2.5-era. Google has announced the end of the
   2.5-flash family (and 2.5 calls were already erroring for some projects
   ahead of the date), so when the saved model died there was NOT a single
   current free model left in the chain and every AI feature - including
   the public website assistant - answered with the vague "short break".
   Added the current-generation FREE models that work on the same AI
   Studio key (gemini-3.1-flash-lite, gemini-3.8-flash) plus the live
   alias. Each entry only costs one extra attempt when the previous one
   fails, and every model has its OWN free daily quota, so the longer
   chain also multiplies how many chats the school can do per day. */
const AI_FALLBACK_MODELS = [
    "gemini-2.5-flash",       // today's free workhorse (retirement announced for later in 2026)
    "gemini-2.5-flash-lite",  // cheapest free model - its own free quota
    "gemini-3.1-flash-lite",  // current-generation free Flash-Lite - its own free quota
    "gemini-flash-latest",    // Google's live alias - always points at the newest GA flash
    "gemini-3.8-flash"        // newest free Flash (September 2026) - its own free quota
];
function aiModelErr(e) {
    const m = String(e && e.message || e || "");
    /* CHANGED (pack 31 - owner: "can it handle much task"): free-tier
       quota/rate errors now also move on to the next model - each Gemini
       model has its OWN free quota, so the fallback chain multiplies how
       many chats a day the school can do before anyone is told 'slow down'. */
    return /model|retired|deprecated|not found|404|unsupported|invalid|quota|rate.?limit|429|resource.?exhausted|too many/i.test(m);
}
function aiChatSmart(messages, opts, cfg) {
    opts = opts || {};
    const chain = [cfg.model].concat(AI_FALLBACK_MODELS).filter(function (v, i, a) {
        return v && a.indexOf(v) === i;
    });
    let attempt = 0;
    function tryNext(msgs) {
        if (attempt >= chain.length) return Promise.reject(new Error("no usable AI model - or today's free quota is finished (it resets daily)"));
        const model = chain[attempt++];
        const sub = Object.assign({}, cfg, { model: model });
        return aiChat(msgs, opts, sub).then(function (got) {
            /* FIX (pack 31 - owner: "the ai is giving incomplete message"):
               when the model says it stopped because it ran out of room
               (finish_reason 'length'), ask it ONCE to continue exactly
               where it stopped and stitch the two halves together - the
               teacher sees one complete answer. */
            if (got.finishReason === "length" && !opts._continued) {
                const cont = msgs.concat([
                    { role: "assistant", content: got.text },
                    { role: "user", content: "Continue exactly where you stopped. Do not repeat anything you already wrote - just carry on." }
                ]);
                const opts2 = Object.assign({}, opts, { _continued: true });
                return aiChat(cont, opts2, sub).then(function (more) {
                    return { text: got.text.replace(/\s+$/, "") + " " + more.text.replace(/^\s+/, ""), model: model, finishReason: more.finishReason };
                }, function () {
                    return { text: got.text, model: model, finishReason: got.finishReason }; // second half failed - still better than an error
                });
            }
            return { text: got.text, model: model, finishReason: got.finishReason };
        }, function (err) {
            if (attempt < chain.length && aiModelErr(err)) return tryNext(msgs);
            throw err;
        });
    }
    return tryNext(messages);
}

/* Tolerant JSON extractor - AI models sometimes wrap JSON in code fences. */
function aiParseJson(text) {
    let t = String(text || "").trim().replace(/^```(?:json)?/i, "").replace(/```\s*$/, "").trim();
    try { return JSON.parse(t); } catch (e) { /* fall through */ }
    const m = t.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (m) return JSON.parse(m[1]);
    throw new Error("AI reply was not valid JSON");
}

/* Public status ping - the three AI UIs use it to show "AI ready" vs a
   gentle "coming soon" note. Reveals nothing secret. */
app.get("/api/ai/status", (req, res) => {
    // CHANGED (pack 29): key may live in the app now - check both places
    aiConfig().then(function (cfg) { res.json({ enabled: !!cfg.key }); });
});

/* ---------- AI FEATURE 1: exam question generator (staff) ---------------
   Teacher gives class + subject + topic; AI drafts numbered questions the
   teacher can still edit before printing (AI proposes, teacher disposes). */
app.post("/api/ai/exam-questions", requireLogin, async (req, res) => {
    const cfg = await aiConfig(); // CHANGED (pack 29): in-app key counts too
    if (!cfg.key) return aiNotReady(res);
    const f = k => String(req.body[k] == null ? "" : req.body[k]).trim();
    const className = f("className").slice(0, 80);
    const subject   = f("subject").slice(0, 80);
    const topic     = f("topic").slice(0, 200);
    const qtype     = ["objective", "theory", "mixed"].indexOf(f("qtype")) !== -1 ? f("qtype") : "theory";
    const count     = Math.max(1, Math.min(20, parseInt(f("count"), 10) || 5));
    const marks     = f("marks").slice(0, 12);
    if (!topic) return res.status(400).json({ error: "Please type a topic first." });

    const sys =
        "You are an expert exam setter for Ameenullah School of Arabic and Islamic Studies " +
        "in Lagos, Nigeria - an Arabic/Islamic school that also teaches general subjects. " +
        "You write clear, correct, age-appropriate exam questions. Use English or Arabic " +
        "to suit the subject. Reply with JSON only - no commentary, no markdown fences.";
    const usr =
        "Write " + count + " " + qtype + " exam question(s) for class \"" + (className || "secondary") +
        "\" in the subject \"" + (subject || "general") + "\" on this topic: \"" + topic + "\"." +
        (marks ? " Each question carries " + marks + "." : "") +
        (qtype !== "theory" ? " Every objective question must have exactly 4 options labelled A, B, C, D." : "") +
        " JSON shape: {\"questions\":[{\"question\":\"text\",\"options\":[\"A. ...\",\"B. ...\",\"C. ...\",\"D. ...\"] or null}]}";

    try {
        const got = await aiChatSmart([{ role: "system", content: sys }, { role: "user", content: usr }], { maxTokens: 4000, temperature: 0.65 }, cfg); // CHANGED (pack 31): room for full question sets
        const text = got.text;
        const data = aiParseJson(text);
        const list = Array.isArray(data) ? data : (data && data.questions);
        if (!Array.isArray(list)) throw new Error("AI sent no questions");
        const cleaned = list.slice(0, count).map(function (q) {
            const obj = { question: String(q && q.question || "").trim().slice(0, 700) };
            if (Array.isArray(q && q.options)) {
                const opts = q.options.map(o => String(o || "").trim().slice(0, 140)).filter(Boolean).slice(0, 6);
                if (opts.length >= 2) obj.options = opts;
            }
            return obj;
        }).filter(q => q.question);
        if (!cleaned.length) throw new Error("AI sent no usable questions");
        res.json({ questions: cleaned });
    } catch (e) {
        console.log("AI exam-questions error:", e && e.message);
        res.status(502).json({ error: "The AI is busy right now \u2014 please wait a moment and try again. If it keeps happening after a few tries, today's free limit may be finished (it resets daily)." });
    }
});

/* ---------- REMOVED (pack 29 - owner: "I don't need the ai remark,
   remove it and turn it to chat"): the one-note AI Remarks page and its
   /api/ai/remark route are GONE. Teachers now chat with the AI fluently
   on the AI Chat page (ai-remarks.html) - they can still ask the chat to
   draft a remark for any student whenever they want. ------------------- */

/* ---------- AI FEATURE 2: STAFF AI CHAT (pack 29) ---------------------
   Free-flowing, multi-turn conversation for logged-in staff. The page
   keeps the conversation and sends it here each time; the school voice
   (system prompt) is added server-side so the AI always stays the
   "school AI". Per-staff hourly limit keeps the free AI quota safe. */
const aiStaffHits = Object.create(null); // username -> { count, resetAt }
setInterval(function () { // sweep expired buckets (memory hygiene)
    const now = Date.now();
    Object.keys(aiStaffHits).forEach(function (k) { if (aiStaffHits[k].resetAt < now) delete aiStaffHits[k]; });
}, 600000).unref();

app.post("/api/ai/chat", requireLogin, async (req, res) => {
    const cfg = await aiConfig();
    if (!cfg.key) return aiNotReady(res);
    const who = req.session.username || "?";
    const now = Date.now();
    let bucket = aiStaffHits[who];
    if (!bucket || bucket.resetAt < now) bucket = aiStaffHits[who] = { count: 0, resetAt: now + 3600000 };
    if (++bucket.count > 40) {
        return res.status(429).json({ error: "You have chatted a lot this hour - take a short break and continue in a little while." });
    }
    const hist = (Array.isArray(req.body.messages) ? req.body.messages : [])
        .slice(-24).map(function (m) {
            const role = m && m.role === "assistant" ? "assistant" : "user";
            return { role: role, content: String(m && m.content || "").slice(0, 4000) };
        }).filter(function (m) { return m.content; });
    if (!hist.length) return res.status(400).json({ error: "Type something first." });

    const sys =
        "You are AMSAIS AI, the clever, warm assistant built into the school result system used by the staff of " +
        "Ameenullah School of Arabic and Islamic Studies (AMSAIS), Lagos, Nigeria. The person chatting with you is a teacher or school administrator. " +
        "Chat naturally and fluently, like a helpful colleague sitting next to them. You can help with: writing report-card remarks, exam questions, " +
        "letters and messages to parents, teaching ideas and lesson tips, simple English-Arabic translation, Islamic knowledge to support lessons, " +
        "and general school-office writing. " +
        "Style: simple friendly English; short paragraphs; lists or numbered points when helpful; **bold** the key words; keep answers focused and " +
        "offer to go deeper at the end if it is a big topic. A short Islamic greeting is fine when greeted. " +
        "You CANNOT look up private student records, fee balances or results, and you CANNOT perform actions inside the app - if asked, kindly " +
        "point them to the right page in the menu. Never invent school fees, dates or policies.";

    try {
        const got = await aiChatSmart([{ role: "system", content: sys }].concat(hist), { maxTokens: 2048, temperature: 0.7 }, cfg); // CHANGED (pack 31): thinking models spend tokens on reasoning - 800 starved the visible answer
        res.json({ reply: got.text.trim().slice(0, 4000) });
    } catch (e) {
        console.log("AI chat error:", e && e.message);
        const out = { error: "The AI is busy right now \u2014 please wait a moment and try again. If it keeps happening after a few tries, today's free limit may be finished (it resets daily)." };
        if (req.session && req.session.role === "admin") {
            out.detail = String(e && e.message || "unknown").slice(0, 200); // FIX (pack 30): the office can see WHY
        }
        res.status(502).json(out);
    }
});

/* ---------- AI FEATURE 2b: STUDENT LEARNING TUTOR (pack 37) ----------
   The child's own AI chat for learning at home - opened from the Student
   & Parent Portal. Same friendly chat UI as the staff AI, but the AI
   becomes a PATIENT TUTOR: it explains lessons step by step, gives
   practice questions, quizzes gently and helps with homework - in simple
   English or Arabic, sized to the student's class. It never shows
   private records (results, fees, attendance) - it only teaches.
   Portal login required. 20 chats per hour per student keeps the free
   AI quota safe; the message is limited so one child cannot drain it. */
const aiStudentHits = Object.create(null); // studentId -> { count, resetAt }
setInterval(function () { // sweep expired buckets (memory hygiene)
    const now = Date.now();
    Object.keys(aiStudentHits).forEach(function (k) { if (aiStudentHits[k].resetAt < now) delete aiStudentHits[k]; });
}, 600000).unref();

app.post("/api/ai/student-chat", async (req, res) => {
    const cfg = await aiConfig();
    if (!cfg.key) {
        return res.status(503).json({ error: "The AI tutor is not switched on yet. The school office can switch it on in one minute - please try again soon." });
    }
    const sid = req.session && req.session.portalStudentId;
    const staff = req.session && req.session.userId;
    if (!sid && !staff) return res.status(401).json({ error: "Please log in to the Student & Parent Portal first." });

    const who = sid ? ("student:" + sid) : ("staff:" + String(req.session.username || staff));
    const now = Date.now();
    let bucket = aiStudentHits[who];
    if (!bucket || bucket.resetAt < now) bucket = aiStudentHits[who] = { count: 0, resetAt: now + 3600000 };
    if (++bucket.count > 20) {
        return res.status(429).json({ error: "You have chatted with the AI tutor a lot this hour - take a short break and continue in a little while (the limit resets every hour)." });
    }

    const hist = (Array.isArray(req.body.messages) ? req.body.messages : [])
        .slice(-20).map(function (m) {
            const role = m && m.role === "assistant" ? "assistant" : "user";
            return { role: role, content: String(m && m.content || "").slice(0, 3000) };
        }).filter(function (m) { return m.content; });
    if (!hist.length) return res.status(400).json({ error: "Type something first." });

    /* Know the child's name + class so the tutor can talk at the right
       level (e.g. "Basic 4", "JSS 2", "Tahdiri"). Never sent to the AI
       as raw records - only the friendly labels below. */
    const studentRow = await new Promise(function (resolve) {
        if (!sid) return resolve(null);
        connection.query("SELECT full_name, class_name FROM students WHERE student_id = ? LIMIT 1", [sid], function (err, rows) {
            if (err || !rows || !rows.length) return resolve(null);
            resolve(rows[0]);
        });
    });
    const kidFirst = studentRow && studentRow.full_name ? String(studentRow.full_name).trim().split(/\s+/)[0] : "";
    const kidClass = studentRow && studentRow.class_name ? String(studentRow.class_name).trim() : "";
    const kidIntro = (kidFirst ? " You are talking with " + kidFirst + ", a student of Ameenullah School" +
        (kidClass ? " in " + kidClass + "." : ".") : " You are talking with a student of Ameenullah School.");

    const sys =
        "You are Ustaadh AI - the friendly private tutor of Ameenullah School of Arabic and Islamic Studies (AMSAIS), Lagos, Nigeria. " +
        "Motto: Knowledge and Worship. Your only job is to help one child learn at home." + kidIntro +
        " How you help: explain any school lesson step by step in very simple English (or in simple Arabic when the child asks - this is an Arabic/Islamic school), " +
        "break hard ideas into small easy steps, use everyday examples, give clear working for Maths, gently correct mistakes with encouragement, " +
        "make short practice questions and little quizzes on any topic, help with homework by GUIDING and teaching - never just give the answer first, " +
        "help memorise and understand the Qur'an, Arabic grammar, Tawheed, Fiqh, Seerah and general subjects. " +
        "Style: short friendly messages, kind and encouraging, a few numbered steps or a small example when helpful; use **bold** for key words; " +
        "keep answers age-appropriate (the child's class is " + (kidClass || "not known") + "); end with one small question so the child keeps thinking. " +
        "Rules: NEVER invent marks, results, fees, dates or private school records - you only teach, you cannot see the child's results; " +
        "if the child asks about them, kindly say to ask the class teacher or check Results in the portal. " +
        "Never give private information about other students. Keep the tone clean, respectful and full of adab. A short Islamic greeting is fine.";

    try {
        const got = await aiChatSmart([{ role: "system", content: sys }].concat(hist), { maxTokens: 2048, temperature: 0.65 }, cfg);
        res.json({ reply: got.text.trim().slice(0, 4000), student: { first: kidFirst, className: kidClass } });
    } catch (e) {
        console.log("AI student tutor error:", e && e.message);
        // CHANGED (pack 106): "taking a short break" implied the app was
        // broken even when the cause was permanent (model retired / the
        // school's free daily AI quota finished). Say what is true instead.
        const out = { error: "The AI tutor is busy right now \u2014 please wait a moment and try again. If it keeps happening after a few tries, today's free AI limit may be finished (it resets daily)." };
        if (req.session && req.session.role === "admin") {
            out.detail = String(e && e.message || "unknown").slice(0, 200); // the office can see WHY
        }
        res.status(502).json(out);
    }
});

/* ---------- ADMIN AI SWITCH-ON (pack 29) ------------------------------
   The admin pastes the free key once on the AI Chat page -> it lands in
   ai_config -> EVERY AI feature (chat, exam questions, website assistant)
   wakes up at once. GET never returns the full key (only the last 4
   characters) so it is safe to draw the "connected" state. */
app.get("/api/ai/config", requireAdmin, async (req, res) => {
    const cfg = await aiConfig();
    res.json({
        enabled: !!cfg.key,
        source: cfg.source || "",
        keyTail: cfg.key ? "\u2026" + cfg.key.slice(-4) : "",
        baseUrl: cfg.base,
        model: cfg.model,
        updatedBy: cfg.source === "app" ? (cfg.updatedBy || "") : ""
    });
});

app.post("/api/ai/config", requireAdmin, async (req, res) => {
    const apiKey  = String(req.body.apiKey  || "").trim().slice(0, 400);
    const baseUrl = String(req.body.baseUrl || "").trim().slice(0, 200);
    const model   = String(req.body.model   || "").trim().slice(0, 80);
    if (apiKey && !/^[\x20-\x7E]+$/.test(apiKey)) {
        return res.status(400).json({ error: "That key has odd characters - copy and paste it again carefully." });
    }
    if (baseUrl && !/^https?:\/\//i.test(baseUrl)) {
        return res.status(400).json({ error: "The service address must start with https:// - or leave it empty to use the default." });
    }
    const doSave = function (done) {
        if (!apiKey) { // empty key = REMOVE the in-app key (env key is untouched)
            connection.query("DELETE FROM ai_config WHERE id = 1", function (dErr) {
                if (dErr) return res.status(500).json({ error: "Could not remove the key - database error." });
                aiBustCache();
                res.json({ saved: true, cleared: true });
            });
            return;
        }
        const sql =
            "INSERT INTO ai_config (id, api_key, base_url, model, updated_by) VALUES (1, ?, ?, ?, ?) " +
            "ON DUPLICATE KEY UPDATE api_key = VALUES(api_key), base_url = VALUES(base_url), " +
            "model = VALUES(model), updated_by = VALUES(updated_by)";
        connection.query(sql, [apiKey, baseUrl || null, model || null, req.session.username || "admin"], function (err) {
            if (err) return res.status(500).json({ error: "Could not save the key - database error." });
            aiBustCache();
            done();
        });
    };
    doSave(async function () {
        try { /* one tiny test ping - the admin knows instantly it truly works.
                 FIX (pack 30): roomier token budget (newer "thinking" models
                 spend tokens on reasoning) and the fallback chain; when a
                 backup model is the one that answers, we save ITS name so
                 future chats don't waste time retrying the dead one. */
            const fresh = await aiConfig();
            const got = await aiChatSmart([{ role: "user", content: "Reply with the single word: OK" }], { maxTokens: 64, temperature: 0 }, fresh);
            if (got.model !== fresh.model) {
                connection.query("UPDATE ai_config SET model = ? WHERE id = 1", [got.model], function () {});
                aiBustCache();
            }
            res.json({ saved: true, cleared: false, verified: true, model: got.model });
        } catch (e) {
            res.json({
                saved: true, cleared: false, verified: false,
                note: "Saved, but the test call failed: " + (e && e.message || "service error") + ". Check the key and press Save again."
            });
        }
    });
});

/* ---------- AI FEATURE 3: website school assistant (public) -------------
   A receptionist-style chat bubble on the public website. Answers only
   school/website questions. Rate-limited per visitor to keep it polite. */
const aiAssistantHits = Object.create(null); // ip -> { count, resetAt }
setInterval(function () { // sweep expired buckets every 10 min (memory hygiene)
    const now = Date.now();
    Object.keys(aiAssistantHits).forEach(function (k) { if (aiAssistantHits[k].resetAt < now) delete aiAssistantHits[k]; });
}, 600000).unref();

/* CHANGED (Pack 105 - owner: "the ai at the public view is not working"):
   this is the PUBLIC website assistant (visitors/parents who are NOT
   logged in), so it must NOT sit behind requireLogin - that guard made
   every anonymous question fail with 401 and the widget just said "could
   not answer". It stays safe because it is already rate-limited per
   visitor (20/hour) and only ever sends the visitor's question + the
   fixed school facts to the AI service. */
app.post("/api/ai/assistant", async (req, res) => {
    const cfg = await aiConfig(); // CHANGED (pack 29): in-app key counts too
    if (!cfg.key) return aiNotReady(res);
    const ip = req.ip || req.connection.remoteAddress || "?";
    const now = Date.now();
    let bucket = aiAssistantHits[ip];
    if (!bucket || bucket.resetAt < now) bucket = aiAssistantHits[ip] = { count: 0, resetAt: now + 3600000 };
    if (++bucket.count > 20) {
        return res.status(429).json({ error: "You have asked a lot this hour - please chat with the office directly, or come back a little later." });
    }
    const message = String(req.body.message || "").trim().slice(0, 600);
    if (!message) return res.status(400).json({ error: "Type a question first." });
    const history = (Array.isArray(req.body.history) ? req.body.history : [])
        .slice(-8).map(function (h) {
            const role = h && h.role === "assistant" ? "assistant" : "user";
            return { role: role, content: String(h && h.content || "").slice(0, 300) };
        }).filter(h => h.content);

    // Live school facts (name, address, phone...) keep answers accurate.
    connection.query("SELECT * FROM school_settings WHERE id = 1", async (sErr, srows) => {
        const st = (!sErr && srows && srows.length) ? srows[0] : {};
        const facts =
            "School: Ameenullah School of Arabic and Islamic Studies (AMSAIS), Lagos, Nigeria. " +
            "Motto: Knowledge and Worship. " +
            (st.address ? "Address: " + st.address + ". " : "") +
            (st.phone ? "Phone: " + st.phone + ". " : "") +
            (st.email ? "Email: " + st.email + ". " : "") +
            // CHANGED (pack 36 - owner: "ai did not know that tahdiri is in our program"): added the Preparatory (Tahdiri) stage.
            "Programs: Preparatory (Tahdiri), Foundation (Ibtida'i), Middle (I'dadi), Advanced (Thanawi) Arabic/Islamic classes, " +
            "and Tahfeedhul-Qur'an evening memorisation (Thursday-Saturday, 4PM till sunset). " +
            "Website features: parents check results in the Parent Portal (student ID + surname as password), " +
            "chat with the school, see notices, timetables and calendars, upload payment evidence, and apply " +
            "for admission with the website form.";
        const sys =
            "You are the friendly front-desk assistant of Ameenullah School. Use ONLY these facts: " + facts +
            " Rules: answer in 1-4 short sentences, warm and simple English (parents may not be technical). " +
            "NEVER invent fees, dates, results or policies - if unsure, say the school office will confirm " +
            "and share the contact details if known. If a question is not about the school or this website, " +
            "politely say you only answer school questions. A short Islamic greeting is fine when greeted.";
        try {
            const got = await aiChatSmart(
                [{ role: "system", content: sys }].concat(history, [{ role: "user", content: message }]),
                { maxTokens: 1200, temperature: 0.6 }, // CHANGED (pack 31): was 320 - short answers got visibly cut
                cfg
            );
            res.json({ reply: got.text.trim().slice(0, 1200) });
        } catch (e) {
            console.log("AI assistant error:", e && e.message);
            /* FIX (pack 106 - owner: "the public AI is saying The assistant is
               taking a short break"): the old message blamed a "short break"
               even for lasting causes (retired model, free daily quota
               finished), so visitors thought the site itself was broken.
               Say what is true, point to the office contact for urgent
               questions, and let a logged-in admin see the underlying
               reason (same pattern the staff AI chat already uses). */
            const out = { error: "The AI is busy right now \u2014 please wait a moment and try again. If it keeps happening after a few tries, today's free AI limit may be finished (it resets daily). For urgent questions, please use the contact details at the bottom of the page." };
            if (req.session && req.session.role === "admin") {
                out.detail = String(e && e.message || "unknown").slice(0, 200); // the office can see WHY
            }
            res.status(502).json(out);
        }
    });
});

/* ==========================================================================
   NEW (pack 32): WEB PUSH - subscribe, unsubscribe, stats and the sender
   used by the four "golden triggers" below (results published, fee
   received, announcement posted, chat reply). Everything degrades
   silently: if a phone's subscription dies, it is pruned; if push is not
   ready yet, the rest of the system never notices.
   ========================================================================== */

/* ==========================================================================
   REWRITTEN (owner: "the AI is stumbling / generating rubbish images"):
   AI IMAGE GENERATOR - studio-quality pipeline.
   --------------------------------------------------------------------------
   What changed:
     1. PROMPT ENHANCEMENT - when the school AI key is on, a text-model call
        first turns the teacher's idea into professional art direction
        (style, colours, lighting, text, composition) plus a negative list.
        With no key, a built-in professional template does the job instead.
     2. BETTER ENGINE - with a Google AI key it draws through Google's own
        image model (Gemini Flash Image / Nano Banana) which is excellent at
        posters with correct text and Islamic artwork. If that is not
        available (or the free image quota is finished) it automatically
        falls back to Pollinations FLUX - still completely free, no key.
     3. STYLE PRESETS + SHAPE - the teacher chooses a style (poster,
        certificate, logo, islamic-art, watercolour, cartoon, 3D, photo)
        and a shape (square / portrait / landscape / wide); the server bakes
        the school branding into the prompt for every style.
     4. HONEST ERRORS - quota / model / busy problems now say exactly what
        happened instead of a vague "service is busy".
   Endpoints: POST /api/ai/generate-image (requireLogin)
              GET  /ai-image-generator.html
   ========================================================================== */
const aiImgHits = Object.create(null);
setInterval(function () {
    const now = Date.now();
    Object.keys(aiImgHits).forEach(function (k) {
        if (aiImgHits[k].resetAt < now) delete aiImgHits[k];
    });
}, 600000).unref();

/* ---- style presets (labels are sent by the page; hints are added to the
        prompt so every image carries the school's look) ---------------- */
const AI_IMG_STYLES = {
    poster: "A professional school poster design, clean strong typography, clear readable headline, balanced layout with a bold focal point, school branding colours dark emerald green (#1d4a30) and gold (#d9a419).",
    certificate: "An elegant certificate / award border design, fine Islamic geometric corner ornamentation, dark emerald green and gold palette, large clean empty centre panel for the student name, formal and dignified.",
    logo: "A flat vector-style emblem or badge logo, crisp minimal design, dark emerald green and gold colour scheme, Islamic geometric or crescent motif, white or transparent-style background, sharp clean edges, no watermark.",
    islamic: "A beautiful Islamic artwork, elegant Arabic calligraphy, intricate Islamic geometric patterns, mosque or crescent and star motifs, rich dark emerald green and gold palette, serene and respectful.",
    watercolor: "A soft watercolour illustration, gentle washes of dark green and gold, delicate details, light warm background, artistic and graceful.",
    cartoon: "A friendly colourful children's cartoon illustration, cheerful characters, bright safe colours with touches of school green and gold, simple readable design, wholesome and fun.",
    "3d": "A polished 3D render, soft studio lighting, realistic materials, subtle depth of field, dark emerald and gold highlights, premium modern look.",
    photo: "A realistic professional photograph, natural lighting, sharp focus, high detail, candid warm atmosphere."
};
function aiImgStyleHint(style) {
    return AI_IMG_STYLES[style] || AI_IMG_STYLES.poster;
}

/* ---- aspect ratios: page requests a friendly name -------------------- */
const AI_IMG_ASPECTS = {
    square:   { label: "Square",              gem: "1:1",  w: 1024, h: 1024 },
    portrait: { label: "Portrait",            gem: "3:4",  w: 1024, h: 1536 },
    landscape:{ label: "Landscape",           gem: "4:3",  w: 1536, h: 1024 },
    wide:     { label: "Wide banner",         gem: "16:9", w: 1536, h: 864  }
};
function aiImgAspect(name) {
    return AI_IMG_ASPECTS[name] || AI_IMG_ASPECTS.square;
}

/* ---- built-in professional prompt (used when no AI key is available,
        and as the safety net if the enhancement call fails) ------------ */
function aiImgBuiltin(prompt, style) {
    const SCHOOL = "Ameenullah School of Arabic and Islamic Studies";
    const MOTTO = "Knowledge and Worship";
    return {
        prompt: prompt +
            ". School context: " + SCHOOL + ", motto \"" + MOTTO + "\". " +
            aiImgStyleHint(style) +
            " Spell ALL text exactly as quoted and keep every word of text correct and readable. High resolution, crisp, professional finish.",
        negative: "blurry, low quality, distorted text, misspelled words, gibberish text, extra fingers, warped faces, watermark, logo of other brands, cluttered composition, low contrast, smudged colours, cropped important elements"
    };
}

/* ---- AI prompt enhancement (school AI key on): rough idea -> pro art
        direction + negative list. Returns null if the AI can't help. --- */
function aiEnhanceImagePrompt(userPrompt, style, cfg) {
    const fallback = aiImgBuiltin(userPrompt, style);
    if (!cfg || !cfg.key) return Promise.resolve(fallback);
    const sys =
        "You are a professional graphic designer who directs an AI image model for Ameenullah School " +
        "of Arabic and Islamic Studies (motto: Knowledge and Worship - colours: dark emerald green #1d4a30 and gold #d9a419). " +
        "You take a plain idea and return ONE polished image prompt plus a negative prompt. " +
        "Rules: never invent people's names; spell quoted text EXACTLY as given; keep text short and legible; " +
        "mention composition, lighting, colours, style and mood; avoid clich\u00e9s like generic 'artificial intelligence' robots. " +
        "Reply with JSON only - no fences, no commentary: " +
        "{\"prompt\":\"...\",\"negative\":\"...\"}";
    const usr =
        "Idea: \"" + userPrompt + "\"\n" +
        "Style direction: " + aiImgStyleHint(style) + "\n" +
        "Generate the enhanced prompt (max 140 words) and a short negative prompt (what to avoid).";
    return aiChatSmart(
        [{ role: "system", content: sys }, { role: "user", content: usr }],
        { maxTokens: 500, temperature: 0.55 },
        cfg
    ).then(function (got) {
        try {
            const d = aiParseJson(got.text);
            const p = String(d && (d.prompt || d.enhanced_prompt) || "").trim();
            const n = String(d && (d.negative || d.negative_prompt) || "").trim();
            if (!p) throw new Error("no prompt");
            return { prompt: p, negative: n || fallback.negative, enhanced: true };
        } catch (e) {
            return fallback;
        }
    }, function () {
        return fallback;
    });
}

/* ---- Engine 1: Google's own image model (needs the AI key + Google
        base URL). Returns raw base64 + mime or throws. ------------------ */
const AI_IMG_GEMINI_MODELS = ["gemini-2.5-flash-image", "gemini-3.1-flash-image"];
function aiGeminiImage(prompt, cfg, aspect) {
    if (!cfg || !cfg.key || cfg.base.indexOf("generativelanguage.googleapis.com") === -1) {
        return Promise.reject(new Error("gemini-off"));
    }
    /* The saved base may be the OpenAI-compatible ".../v1beta/openai"
       address; the NATIVE image endpoint is ".../v1beta/models/M:generateContent",
       so drop a trailing "/openai" when it is there. */
    const nativeBase = cfg.base.replace(/\/openai$/i, "").replace(/\/+$/, "");
    const models = [String(process.env.AI_IMAGE_MODEL || "").trim()]
        .concat(AI_IMG_GEMINI_MODELS)
        .filter(function (v, i, a) { return v && a.indexOf(v) === i; });
    let attempt = 0;
    function tryOne() {
        if (attempt >= models.length) return Promise.reject(new Error("Gemini image models unavailable for this key"));
        const model = models[attempt++];
        return new Promise(function (resolve, reject) {
            const body = JSON.stringify({
                contents: [{ parts: [{ text: prompt }] }],
                generationConfig: {
                    responseModalities: ["TEXT", "IMAGE"],
                    imageConfig: { aspectRatio: aspect.gem }
                }
            });
            let u;
            try {
                u = new URL(nativeBase + "/models/" + encodeURIComponent(model) + ":generateContent");
            } catch (e) { return reject(new Error("bad URL")); }
            const lib = u.protocol === "http:" ? require("http") : require("https");
            const req = lib.request({
                method: "POST",
                hostname: u.hostname,
                port: u.port || (u.protocol === "http:" ? 80 : 443),
                path: u.pathname + u.search,
                headers: {
                    "Content-Type": "application/json",
                    "x-goog-api-key": cfg.key,
                    "Content-Length": Buffer.byteLength(body)
                }
            }, function (r) {
                let raw = "";
                r.on("data", function (c) { raw += c; if (raw.length > 12 * 1024 * 1024) req.destroy(new Error("image too large")); });
                r.on("end", function () {
                    let d = null;
                    try { d = JSON.parse(raw); } catch (e) { return reject(new Error("Gemini reply was not JSON")); }
                    if (r.statusCode >= 400) {
                        const m = d && d.error && d.error.message ? d.error.message : ("Gemini error " + r.statusCode);
                        return reject(new Error(model + ": " + m));
                    }
                    const cand = d && d.candidates && d.candidates[0];
                    if (!cand) return reject(new Error(model + ": no candidate"));
                    if (cand.promptFeedback && cand.promptFeedback.blockReason) {
                        return reject(new Error("blocked: " + cand.promptFeedback.blockReason));
                    }
                    const parts = (cand.content && cand.content.parts) || [];
                    for (let i = 0; i < parts.length; i++) {
                        const inl = parts[i] && parts[i].inlineData;
                        if (inl && inl.data) {
                            return resolve({ b64: inl.data, mime: inl.mimeType || "image/png", engine: "Gemini " + model });
                        }
                    }
                    reject(new Error(model + ": no image returned"));
                });
            });
            req.setTimeout(120000, function () { req.destroy(new Error(model + " took too long")); });
            req.on("error", function (e) { reject(e); });
            req.write(body);
            req.end();
        }).catch(function (e) {
            const msg = String(e && e.message || "");
            // model/unsupported/quota errors -> try the next Gemini model;
            // anything else is a real problem -> let the caller fall back.
            if (attempt < models.length && /model|not found|unsupported|invalid|quota|rate|429|resource|permission|403|blocked|404/i.test(msg)) {
                return tryOne();
            }
            throw e;
        });
    }
    return tryOne();
}

/* ---- Engine 2: Pollinations FLUX (free, works with NO key). Uses the
        new gen.pollinations.ai endpoint with negative prompt + enhance,
        then retries on the legacy host. --------------------------------- */
function pollinationsImage(prompt, negative, aspect, attempt) {
    attempt = attempt || 1;
    return new Promise(function (resolve, reject) {
        const https = require("https");
        const seed = Math.floor(Math.random() * 999999);
        const enc = encodeURIComponent(prompt);
        const neg = encodeURIComponent(negative || "");
        const base = attempt <= 2
            ? "https://gen.pollinations.ai/image/"
            : "https://image.pollinations.ai/prompt/";
        const url = base + enc +
            "?width=" + aspect.w + "&height=" + aspect.h +
            "&model=flux&seed=" + seed + "&nologo=true&private=true&safe=true" +
            "&enhance=true" +
            (neg ? "&negative_prompt=" + neg : "");

        const req = https.get(url, { headers: { "User-Agent": "AMSAIS-School-App" } }, function (res) {
            if (res.statusCode === 429 || res.statusCode >= 500) {
                res.resume();
                if (attempt < 3) {
                    setTimeout(function () {
                        pollinationsImage(prompt, negative, aspect, attempt + 1).then(resolve).catch(reject);
                    }, 3000 * attempt);
                } else {
                    reject(new Error("The free image service is busy right now - please wait a minute and try again."));
                }
                return;
            }
            if (res.statusCode !== 200) {
                res.resume();
                if (attempt < 3) {
                    setTimeout(function () {
                        pollinationsImage(prompt, negative, aspect, attempt + 1).then(resolve).catch(reject);
                    }, 1500);
                } else {
                    reject(new Error("The image service returned error " + res.statusCode + " - please try again."));
                }
                return;
            }
            const chunks = [];
            const maxBytes = 12 * 1024 * 1024;
            let size = 0;
            res.on("data", function (c) { size += c.length; if (size > maxBytes) { req.destroy(); reject(new Error("Image too large")); return; } chunks.push(c); });
            res.on("end", function () {
                const buf = Buffer.concat(chunks);
                if (buf.length < 1500) {
                    if (attempt < 3) {
                        setTimeout(function () {
                            pollinationsImage(prompt, negative, aspect, attempt + 1).then(resolve).catch(reject);
                        }, 3000 * attempt);
                    } else {
                        reject(new Error("The image service returned an empty image - please try again."));
                    }
                    return;
                }
                const mime = buf[0] === 0x89 && buf[1] === 0x50 ? "image/png" : "image/jpeg";
                resolve({ b64: buf.toString("base64"), mime: mime, engine: "Pollinations FLUX" });
            });
        });
        req.setTimeout(120000, function () {
            req.destroy();
            if (attempt < 3) {
                setTimeout(function () {
                    pollinationsImage(prompt, negative, aspect, attempt + 1).then(resolve).catch(reject);
                }, 2000);
            } else {
                reject(new Error("The free image service took too long - please try again."));
            }
        });
        req.on("error", function (e) {
            if (attempt < 3) {
                setTimeout(function () {
                    pollinationsImage(prompt, negative, aspect, attempt + 1).then(resolve).catch(reject);
                }, 2000);
            } else {
                reject(e);
            }
        });
    });
}

/* ---- the full pipeline: enhance -> Gemini (if key) -> Pollinations --- */
async function aiGenerateImage(userPrompt, style, aspectName, cfg) {
    const aspect = aiImgAspect(aspectName);
    const enhanced = await aiEnhanceImagePrompt(userPrompt, style, cfg);
    let gemErr = null;
    if (cfg && cfg.key) {
        try {
            const g = await aiGeminiImage(enhanced.prompt, cfg, aspect);
            return { b64: g.b64, mime: g.mime, engine: g.engine, revisedPrompt: enhanced.prompt, negativePrompt: enhanced.negative, width: aspect.w, height: aspect.h };
        } catch (e) {
            gemErr = String(e && e.message || "");
            console.log("AI image Gemini fallback:", gemErr.slice(0, 160));
        }
    }
    try {
        const p = await pollinationsImage(enhanced.prompt, enhanced.negative, aspect);
        return { b64: p.b64, mime: p.mime, engine: p.engine, revisedPrompt: enhanced.prompt, negativePrompt: enhanced.negative, width: aspect.w, height: aspect.h };
    } catch (e) {
        const msg = String(e && e.message || "");
        if (gemErr) throw new Error(msg + " (also tried Gemini: " + gemErr.slice(0, 120) + ")");
        throw e;
    }
}

app.get("/ai-image-generator.html", requireLogin, (req, res) => {
    res.sendFile(path.join(__dirname, "ai-image-generator.html"));
});

app.post("/api/ai/generate-image", requireLogin, async (req, res) => {
    const who = req.session.username || String(req.session.userId);
    const now = Date.now();
    let bucket = aiImgHits[who];
    if (!bucket || bucket.resetAt < now) bucket = aiImgHits[who] = { count: 0, resetAt: now + 3600000 };
    if (++bucket.count > 6) {
        return res.status(429).json({
            error: "You have generated 6 images this hour. Take a short break - the AI image quotas reset every hour."
        });
    }

    const prompt = String(req.body.prompt || "").trim();
    if (!prompt) return res.status(400).json({ error: "Please describe the image you want." });
    if (prompt.length > 1000) return res.status(400).json({ error: "Description is too long (max 1000 characters)." });
    const style = /^(poster|certificate|logo|islamic|watercolor|cartoon|3d|photo)$/.test(String(req.body.style || "")) ? req.body.style : "poster";
    const aspectName = /^(square|portrait|landscape|wide)$/.test(String(req.body.aspect || "")) ? req.body.aspect : "square";

    try {
        const cfg = await aiConfig();
        const result = await aiGenerateImage(prompt, style, aspectName, cfg);
        return res.json(result);
    } catch (e) {
        const msg = String(e && e.message || "");
        console.log("AI image error:", msg);
        if (/quota|rate|429|limit|resource/i.test(msg)) {
            return res.status(429).json({ error: "The AI image quota for today/hour is finished. It resets automatically - please try again later." });
        }
        return res.status(502).json({ error: "Could not generate the image right now. " + msg });
    }
});

const webpush = require("web-push");
let PUSH_VAPID = null;
function pushReady() { return !!PUSH_VAPID; }
function pushUseKeys(pub, priv, from) {
    try {
        webpush.setVapidDetails("mailto:madrasatuameenillah22@gmail.com", pub, priv);
        PUSH_VAPID = { publicKey: pub, privateKey: priv };
        console.log("Web push ready (" + from + ").");
    } catch (e) { console.log("Web push key problem:", e && e.message); }
}
function pushInit(attempt) {
    const ep = String(process.env.VAPID_PUBLIC_KEY || "").trim();
    const es = String(process.env.VAPID_PRIVATE_KEY || "").trim();
    if (ep && es) return pushUseKeys(ep, es, "environment");
    connection.query("SELECT * FROM push_keys WHERE id = 1", (err, rows) => {
        if (err) {
            if (attempt < 6) return setTimeout(() => pushInit(attempt + 1), 4000); // table still migrating
            return console.log("Web push key warning:", err.code || err.message);
        }
        if (rows && rows.length) return pushUseKeys(rows[0].public_key, rows[0].private_key, "saved keys");
        try {
            const k = webpush.generateVAPIDKeys(); // first ever boot - create + keep our own identity
            connection.query("INSERT INTO push_keys (id, public_key, private_key) VALUES (1, ?, ?)", [k.publicKey, k.privateKey], (iErr) => {
                if (iErr) console.log("Web push key save warning:", iErr.code || iErr.message);
            });
            pushUseKeys(k.publicKey, k.privateKey, "new keys generated");
        } catch (e) { console.log("Web push key warning:", e && e.message); }
    });
}

/* fire-and-forget send to specific users; dead phones prune themselves */
function amsPushSend(userType, userRefs, payload) {
    if (!pushReady() || !Array.isArray(userRefs) || !userRefs.length) return;
    const uniq = Array.from(new Set(userRefs.filter(Boolean)));
    if (!uniq.length) return;
    connection.query(
        "SELECT * FROM push_subscriptions WHERE user_type = ? AND user_ref IN (" + uniq.map(() => "?").join(",") + ")",
        [userType].concat(uniq),
        (err, subs) => {
            if (err || !subs || !subs.length) return;
            const data = JSON.stringify(payload);
            subs.forEach((sub) => {
                webpush.sendNotification(
                    { endpoint: sub.endpoint, keys: { p256dh: sub.keys_p256dh, auth: sub.keys_auth } },
                    data, { TTL: 86400 }
                ).catch((e) => {
                    if (e && (e.statusCode === 404 || e.statusCode === 410)) {
                        connection.query("DELETE FROM push_subscriptions WHERE id = ?", [sub.id], () => {});
                    } else if (e) {
                        console.log("push send notice:", e.statusCode || "", String(e.body || e.message || "").slice(0, 100));
                    }
                });
            });
        }
    );
}
function amsPushAll(userType, payload) {
    if (!pushReady()) return;
    connection.query("SELECT DISTINCT user_ref FROM push_subscriptions WHERE user_type = ?", [userType], (err, rows) => {
        if (err || !rows || !rows.length) return;
        amsPushSend(userType, rows.map(r => r.user_ref), payload);
    });
}

app.get("/api/push/public-key", (req, res) => {
    if (!pushReady()) return res.status(503).json({ error: "Alerts are warming up - try again in a moment." });
    res.json({ key: PUSH_VAPID.publicKey });
});

function pushSubscribe(req, res, userType, userRef) {
    const sub = req.body && req.body.subscription;
    const endpoint = sub && String(sub.endpoint || "").slice(0, 500);
    const p256dh = sub && sub.keys && String(sub.keys.p256dh || "").slice(0, 128);
    const auth   = sub && sub.keys && String(sub.keys.auth || "").slice(0, 64);
    if (!endpoint || !p256dh || !auth) return res.status(400).json({ message: "That subscription looks broken - close the app and try again." });
    connection.query(
        "INSERT INTO push_subscriptions (endpoint, user_type, user_ref, keys_p256dh, keys_auth, last_seen_at) VALUES (?,?,?,?,?, NOW()) " +
        "ON DUPLICATE KEY UPDATE user_type = VALUES(user_type), user_ref = VALUES(user_ref), " +
        "keys_p256dh = VALUES(keys_p256dh), keys_auth = VALUES(keys_auth), last_seen_at = NOW()",
        [endpoint, userType, userRef, p256dh, auth],
        (err) => {
            if (err) { console.log("push subscribe notice:", err.code || err.message); return res.status(500).json({ message: "Could not save the alert subscription." }); }
            res.json({ message: "Alerts on." });
        }
    );
}
app.post("/api/push-subscribe", requireLogin, (req, res) => pushSubscribe(req, res, "staff", req.session.username));
app.post("/portal/push-subscribe", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    pushSubscribe(req, res, "portal", sid);
});
app.post("/api/push-unsubscribe", requireLogin, (req, res) => {
    const endpoint = String((req.body || {}).endpoint || "").slice(0, 500);
    connection.query("DELETE FROM push_subscriptions WHERE endpoint = ?", [endpoint], () => res.json({ message: "Alerts off." }));
});
app.post("/portal/push-unsubscribe", (req, res) => {
    const endpoint = String((req.body || {}).endpoint || "").slice(0, 500);
    connection.query("DELETE FROM push_subscriptions WHERE endpoint = ?", [endpoint], () => res.json({ message: "Alerts off." }));
});
app.get("/api/push/stats", requireAdmin, (req, res) => {
    connection.query(
        "SELECT user_type, COUNT(DISTINCT user_ref) users, COUNT(*) devices FROM push_subscriptions GROUP BY user_type",
        (err, rows) => {
            if (err) return res.status(500).json({ message: "Database error" });
            const out = { ready: pushReady(), portal: { users: 0, devices: 0 }, staff: { users: 0, devices: 0 } };
            (rows || []).forEach(r => { if (out[r.user_type]) out[r.user_type] = { users: r.users, devices: r.devices }; });
            res.json(out);
        });
});

/* NEW (pack 23): STAFF SETTINGS - change own password (teachers too). */
app.post("/api/change-password", requireLogin, (req, res) => {
    const current = String(req.body.current || "");
    const nextPw  = String(req.body.newPassword || "");
    if (!current || nextPw.length < 4) {
        return res.status(400).json({ message: "New password must be at least 4 characters." });
    }
    connection.query("SELECT * FROM users WHERE username = ?", [req.session.username], (err, rows) => {
        if (err || !rows.length) return res.status(500).json({ message: "Database error" });
        bcrypt.compare(current, rows[0].password_hash, (cErr, match) => {
            if (cErr || !match) return res.status(401).json({ message: "Current password is wrong." });
            bcrypt.hash(nextPw, 10, (hErr, hash) => {
                if (hErr) return res.status(500).json({ message: "Could not set password" });
                connection.query("UPDATE users SET password_hash = ? WHERE username = ?", [hash, req.session.username], (uErr) => {
                    if (uErr) return res.status(500).json({ message: "Database error" });
                    res.json({ message: "Password changed. Use it next time you log in." });
                });
            });
        });
    });
});

/* NEW (pack 23): teacher -> class assignment (admin, for Messages routing). */
app.get("/api/teacher-classes", requireLogin, requireAdmin, (req, res) => {
    connection.query("SELECT id, username, class_name FROM teacher_classes ORDER BY username, class_name", (err, rows) => {
        if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/api/teacher-classes", requireLogin, requireAdmin, (req, res) => {
    const username = String(req.body.username || "").trim();
    const className = String(req.body.class_name || "").trim();
    if (!username || !className) return res.status(400).json({ message: "Teacher and class are required." });
    connection.query(
        "INSERT IGNORE INTO teacher_classes (username, class_name) VALUES (?, ?)",
        [username, className],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Assigned." });
        }
    );
});

app.delete("/api/teacher-classes/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM teacher_classes WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Removed." });
    });
});

app.get("/exams", requireLogin, (req, res) => {
    connection.query(
        "SELECT id, title, class_name, subject, term, session, created_at FROM exams ORDER BY id DESC",
        (err, rows) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json(rows || []);
        }
    );
});

app.get("/exam/:id", requireLogin, (req, res) => {
    connection.query(
        "SELECT * FROM exams WHERE id = ?",
        [req.params.id],
        (err, rows) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            if (rows.length === 0) {
                return res.status(404).json({ message: "Exam not found." });
            }
            res.json(rows[0]);
        }
    );
});

app.delete("/exam/:id", requireLogin, (req, res) => {
    connection.query(
        "DELETE FROM exams WHERE id = ?",
        [req.params.id],
        (err) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error deleting exam." });
            }
            res.json({ message: "Exam deleted." });
        }
    );
});

app.get("/classes", requireLogin, (req, res) => {
    connection.query(
        "SELECT * FROM classes ORDER BY id",
        (err, results) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json(results);
        }
    );
});

app.post("/add-class", requireLogin, (req, res) => {
    const { class_name } = req.body;

    if (!class_name || class_name.trim() === "") {
        return res.status(400).json({ message: "Class name is required." });
    }

    connection.query(
        "INSERT INTO classes (class_name) VALUES (?)",
        [class_name.trim()],
        (err, result) => {
            if (err) {
                if (err.code === "ER_DUP_ENTRY") {
                    return res.status(400).json({ message: "That class already exists." });
                }
                console.log(err);
                return res.status(500).json({ message: "Error adding class" });
            }
            res.json({ message: "Class added successfully", id: result.insertId });
        }
    );
});

app.delete("/delete-class/:id", requireLogin, (req, res) => {
    const id = req.params.id;

    connection.query(
        "DELETE FROM classes WHERE id = ?",
        [id],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json({ message: "Class deleted successfully" });
        }
    );
});

app.get("/subjects", requireLogin, (req, res) => {
    const className = req.query.class;

    // CHANGED (subject enable/disable, request #3): dropdowns (score
    // entry, exam builder) now only show ACTIVE subjects. When the
    // is_active column does not exist yet (older DB), the query falls
    // back to the ORIGINAL behaviour - every subject is returned.
    // No row, no saved result and no calculation is affected.
    function runQuery(filterActive) {
        let sql = "SELECT * FROM subjects";
        let params = [];
        const clauses = [];

        if (className) {
            clauses.push("class_name = ?");
            params.push(className);
        }
        if (filterActive) {
            clauses.push("(is_active = 1)");
        }
        if (clauses.length) {
            sql += " WHERE " + clauses.join(" AND ");
        }

        sql += " ORDER BY subject_name";

        connection.query(sql, params, (err, results) => {
            if (err) {
                if (err.code === "ER_BAD_FIELD_ERROR" && filterActive) {
                    subjectActiveColReady = false;
                    return runQuery(false); // graceful fallback to original query
                }
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json(results);
        });
    }

    runQuery(subjectActiveColReady);
});

app.post("/add-subject", requireLogin, (req, res) => {
    const { subject_name, class_name } = req.body;

    if (!subject_name || !class_name) {
        return res.status(400).json({ message: "Subject name and class are both required." });
    }

    connection.query(
        "INSERT INTO subjects (subject_name, class_name) VALUES (?, ?)",
        [subject_name, class_name],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error adding subject" });
            }
            res.json({ message: "Subject added successfully", id: result.insertId });
        }
    );
});

app.get("/all-subjects", requireLogin, (req, res) => {
    connection.query(
        "SELECT * FROM subjects ORDER BY class_name, subject_name",
        (err, results) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json(results);
        }
    );
});

app.delete("/delete-subject/:id", requireLogin, (req, res) => {
    const id = req.params.id;

    connection.query(
        "DELETE FROM subjects WHERE id = ?",
        [id],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json({ message: "Subject deleted successfully" });
        }
    );
});

// ----------------------------------------------------------------
// NEW (subject editing - request #3): rename a subject or move it to
// another class. ADDITIVE - complements (never changes) the existing
// /add-subject and /delete-subject routes.
// ----------------------------------------------------------------
app.put("/update-subject/:id", requireLogin, (req, res) => {
    const id = req.params.id;
    const { subject_name, class_name } = req.body;
    // CHANGED (subject enable/disable, request #3): optional is_active
    // flag (1 = visible in dropdowns, 0 = hidden/managed-off). Only
    // written when the guarded column exists.
    const hasActiveFlag = subjectActiveColReady && (req.body.is_active === 0 || req.body.is_active === 1);

    if (!subject_name || !class_name) {
        return res.status(400).json({ message: "Subject name and class are both required." });
    }

    const sets = ["subject_name = ?", "class_name = ?"];
    const vals = [subject_name, class_name];
    if (hasActiveFlag) {
        sets.push("is_active = ?");
        vals.push(req.body.is_active);
    }

    connection.query(
        `UPDATE subjects SET ${sets.join(", ")} WHERE id = ?`,
        vals.concat([id]),
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Error updating subject" });
            }
            if (result.affectedRows === 0) {
                return res.status(404).json({ message: "Subject not found." });
            }
            res.json({ message: "Subject updated successfully" });
        }
    );
});

// ----------------------------------------------------------------
// NEW (whole-class results PDF - request #7): returns the RAW saved
// result rows for one class + term + session so the Class Results
// page can render a broadsheet and export ONE combined PDF.
// 100% READ-ONLY - it only SELECTs from the results table; it never
// writes, and it does not change any result calculation. The existing
// per-student "Download Result" feature is completely untouched.
// ----------------------------------------------------------------
app.get("/class-results", requireLogin, (req, res) => {
    const className = (req.query["class"] || "").trim();
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();

    if (!className || !term || !session) {
        return res.status(400).json({ message: "Class, Term and Session are all required." });
    }

    // FIX (pack 88): the broadsheet now mirrors the report sheet -
    //   * LEFT JOIN so scores for students no longer in the register still
    //     appear (they did before on the printed report, but vanished here),
    //   * tolerant class matching (tashkeel / spacing) like every other
    //     result endpoint,
    //   * for 3rd Term the rows are enriched with the same 1st/2nd/3rd term
    //     totals + cumulative average + cumulative grade the report shows,
    //     so class totals / averages / positions agree with the printed card.
    const termFilter = term === "3rd Term" ? "term IN ('1st Term','2nd Term','3rd Term')" : "term = ?";
    const sql = `SELECT r.student_id, COALESCE(s.full_name, r.student_name) AS student_name,
                        r.class_name, r.subject, r.term, r.total, r.grade
                 FROM results r
                 LEFT JOIN students s ON s.student_id = r.student_id
                 WHERE r.session = ? AND ${termFilter}
                 ORDER BY COALESCE(s.full_name, r.student_name), r.subject`;
    const params = term === "3rd Term" ? [session] : [session, term];

    connection.query(sql, params, (err, rows) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ message: "Database Error" });
        }
        const classRows = (rows || []).filter(r => classNamesMatch(r.class_name, className));
        if (term !== "3rd Term") {
            return res.json(classRows.map(r => ({ ...r, term })));
        }

        // Enrich each 3rd-term row with the same cumulative fields as
        // /search-result (subject matching is tolerant).
        const priorByTerm = { "1st Term": {}, "2nd Term": {} };
        classRows.forEach(r => {
            if (r.term === "3rd Term") return;
            const subjKey = normalizeClassName(r.subject);
            if (!subjKey) return;
            const key = String(r.student_id || "").trim().toLowerCase() + "||" + subjKey;
            priorByTerm[r.term][key] = r.total;
        });
        const enriched = classRows.filter(r => r.term === "3rd Term").map(r => {
            const key = String(r.student_id || "").trim().toLowerCase() + "||" + normalizeClassName(r.subject);
            const firstTotal = priorByTerm["1st Term"].hasOwnProperty(key) ? Number(priorByTerm["1st Term"][key]) : null;
            const secondTotal = priorByTerm["2nd Term"].hasOwnProperty(key) ? Number(priorByTerm["2nd Term"][key]) : null;
            const thirdTotal = Number(r.total);
            const present = [firstTotal, secondTotal, thirdTotal].filter(v => v !== null);
            // Match /search-result: expose a per-subject 3-term total for
            // the report-card and class-download renderers.
            const cumulativeTotal = [firstTotal, secondTotal, thirdTotal].reduce(
                (sum, value) => Number.isFinite(value) ? sum + value : sum,
                0
            );
            const cumulativeAverage = present.length
                ? Math.round((present.reduce((a, b) => a + b, 0) / present.length) * 100) / 100
                : null;
            const cumulativeGrade = cumulativeAverage !== null ? amsGradeForTotal(cumulativeAverage) : (r.grade || "");
            return {
                ...r,
                first_term_total: firstTotal,
                second_term_total: secondTotal,
                third_term_total: thirdTotal,
                cumulative_total: cumulativeTotal,
                cumulative_average: cumulativeAverage,
                cumulative_grade: cumulativeGrade
            };
        });
        res.json(enriched);
    });
});

app.get("/dashboard-summary", requireLogin, (req, res) => {
    connection.query(
`
SELECT
    (SELECT COUNT(*) FROM students) AS students,
    (SELECT COUNT(*) FROM subjects) AS subjects,
    (SELECT COUNT(*) FROM results) AS results
`,
(err, data) => {

    if (err) {
        console.log(err);
        return res.status(500).send("Database Error");
    }

    res.json(data[0]);
});

});



    app.post("/save-student", requireLogin, writeRateLimit, upload.single("photo"), (req, res) => {
        const{
            student_id,
            full_name,
            gender,
            class_name,
            date_of_birth
        } = req.body;

        let dobValue = (date_of_birth || "").trim();
        if (dobValue && !/^\d{4}-\d{2}-\d{2}$/.test(dobValue)) {
            dobValue = null;
        }
        if (!dobValue) dobValue = null;

        const photoPath = req.file
            ? `images/students/${req.file.filename}`
            : null;

        const parentName  = (req.body.parent_name  || "").trim();
        const parentPhone = (req.body.parent_phone || "").trim();
        const address     = (req.body.address      || "").trim();
        const stuCity     = (req.body.city          || "").trim();
        const stuState    = (req.body.state         || "").trim();
        const stuCountry  = (req.body.country       || "").trim();
        const hasParentData = studentProfileColsReady && (parentName || parentPhone || address);

        if (hasParentData) {
            connection.query(
                `INSERT INTO students
                 (student_id, full_name, gender, class_name, date_of_birth, photo_path,
                  parent_name, parent_phone, address, city, state, country)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?)
                 ON DUPLICATE KEY UPDATE
                   full_name = VALUES(full_name),
                   gender = VALUES(gender),
                   class_name = VALUES(class_name),
                   date_of_birth = VALUES(date_of_birth),
                   photo_path = COALESCE(VALUES(photo_path), photo_path),
                   parent_name = COALESCE(VALUES(parent_name), parent_name),
                   parent_phone = COALESCE(VALUES(parent_phone), parent_phone),
                   address = COALESCE(VALUES(address), address),
                   city = COALESCE(VALUES(city), city),
                   state = COALESCE(VALUES(state), state),
                   country = COALESCE(VALUES(country), country)`,
                [student_id, full_name, gender, class_name, dobValue, photoPath,
                 parentName || null, parentPhone || null, address || null,
                 stuCity || null, stuState || null, stuCountry || null],
                (err) => {
                    if (err) {
                        if (err.code === "ER_BAD_FIELD_ERROR") {
                            return insertStudentOriginal();
                        }
                        console.log(err);
                        return res.status(500).send("Database Error: " + (err.sqlMessage || err.message || "Could not save student"));
                    }
                    if (photoPath) backupStudentPhoto(student_id, req.file && req.file.path);
                    res.send("Student saved successfully");
                }
            );
            return;
        }

        insertStudentOriginal();

        function insertStudentOriginal() {
            const sql =`
            INSERT INTO students
            (student_id, full_name, gender, class_name, date_of_birth, photo_path)
            VALUES (?,?,?,?,?,?)
            ON DUPLICATE KEY UPDATE
              full_name = VALUES(full_name),
              gender = VALUES(gender),
              class_name = VALUES(class_name),
              date_of_birth = VALUES(date_of_birth),
              photo_path = COALESCE(VALUES(photo_path), photo_path)
            `;

            connection.query(
                sql,
                [
                    student_id,
                    full_name,
                    gender,
                    class_name,
                    dobValue,
                    photoPath
                ],
                (err, result) => {
                    if(err) {
                        console.log(err);
                        res.status(500).send("Database Error: " + (err.sqlMessage || err.message || "Could not save student"));
                    } else {
                        if (photoPath) backupStudentPhoto(student_id, req.file && req.file.path);
                        res.send("Student saved successfully");
                    }
                }
            );
        }
    });

    // ----------------------------------------------------------------
    // NEW (student profile editing - request #4): lets the ADMIN edit
    // every profile field of an existing student:
    //   Full Name, Admission Number (student_id), Gender, Date of Birth,
    //   Class, Parent Name, Parent Phone, Address, Passport Photograph.
    // ADDITIVE: no existing route is changed. Admin-only, like
    // /delete-student. Parent fields are only written when the guarded
    // columns exist (see ensureStudentProfileColumns above).
    //
    // FormData note: the client sends "student_id" BEFORE the photo
    // file, because multer uses it to name the saved image file.
    //
    // Admission Number changes are handled safely: the students row is
    // updated together with results.student_id (plain text link), so a
    // renamed student keeps all of their saved results. Nothing about
    // result VALUES or calculations is touched - only the id text.
    // ----------------------------------------------------------------
    app.post("/update-student/:studentId", requireLogin, requireAdmin, writeRateLimit, upload.single("photo"), (req, res) => {
        const origId = (req.params.studentId || "").trim();

        const fullName = (req.body.full_name || "").trim();
        const gender   = (req.body.gender || "").trim();
        const className = (req.body.class_name || "").trim();
        const dateOfBirth = (req.body.date_of_birth || "").trim() || null;
        const newId = (req.body.student_id || origId).trim() || origId;

        if (!fullName || !gender || !className) {
            return res.status(400).json({ message: "Full Name, Gender and Class are required." });
        }
        if (gender !== "Male" && gender !== "Female") {
            return res.status(400).json({ message: "Gender must be Male or Female." });
        }
        if (!newId) {
            return res.status(400).json({ message: "Admission Number cannot be empty." });
        }

        const photoPath = req.file ? `images/students/${req.file.filename}` : null;

        const parentName  = (req.body.parent_name  || "").trim();
        const parentPhone = (req.body.parent_phone || "").trim();
        const address     = (req.body.address      || "").trim();

        // Build the SET list dynamically so we never write to columns
        // that do not exist on older databases.
        const sets = ["full_name = ?", "gender = ?", "class_name = ?", "date_of_birth = ?"];
        const vals = [fullName, gender, className, dateOfBirth];

        if (studentProfileColsReady) {
            sets.push("parent_name = ?", "parent_phone = ?", "address = ?");
            vals.push(parentName || null, parentPhone || null, address || null);
        }
        if (photoPath) {
            sets.push("photo_path = ?");
            vals.push(photoPath);
        }
        if (newId !== origId) {
            sets.push("student_id = ?");
            vals.push(newId);
        }

        function runUpdate() {
            connection.query(
                `UPDATE students SET ${sets.join(", ")} WHERE student_id = ?`,
                vals.concat([origId]),
                (err, result) => {
                    if (err) {
                        console.log(err);
                        return res.status(500).json({ message: "Database error while updating student." });
                    }
                    if (result.affectedRows === 0) {
                        return res.status(404).json({ message: "No student found with that Admission Number." });
                    }
                    // FIX (pack 20): database copy of the photo (survives disk wipes)
                    if (photoPath) backupStudentPhoto(newId, req.file && req.file.path);
                    res.json({ message: "Student profile updated.", student_id: newId });
                }
            );
        }

        if (newId !== origId) {
            // Make sure the new Admission Number is not already taken.
            connection.query(
                "SELECT student_id FROM students WHERE student_id = ?",
                [newId],
                (err, rows) => {
                    if (err) {
                        console.log(err);
                        return res.status(500).json({ message: "Database error while checking Admission Number." });
                    }
                    if (rows.length > 0) {
                        return res.status(400).json({ message: `Admission Number "${newId}" is already used by another student.` });
                    }
                    // Re-link any saved results to the new id FIRST, so no
                    // result is ever left pointing at a missing student.
                    connection.query(
                        "UPDATE results SET student_id = ? WHERE student_id = ?",
                        [newId, origId],
                        (err2) => {
                            if (err2) {
                                console.log(err2);
                                return res.status(500).json({ message: "Database error while re-linking results." });
                            }
                            runUpdate();
                        }
                    );
                }
            );
        } else {
            runUpdate();
        }
    });

    // ----------------------------------------------------------------
    // NEW (bulk-photo helper): attach or replace the photo of a student
    // who ALREADY exists (e.g. added via bulk Excel upload, which cannot
    // carry photos). ADDITIVE - it changes no existing route or query.
    // The client must send the "student_id" FormData field BEFORE the
    // file, because multer uses it to name the saved file.
    // ----------------------------------------------------------------
    // ----------------------------------------------------------------
    // NEW (feature 2 - student status): mark a student Active /
    // Withdrawn / Graduated. When leaving, status_date records today;
    // reactivating clears it. Admin only. Guards on the status columns
    // so older DBs that rejected the ALTER still respond cleanly.
    // ----------------------------------------------------------------
    app.post("/student-status", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
        const studentId = (req.body.student_id || "").trim();
        const status   = (req.body.status || "").trim().toLowerCase();
        const valid    = ["active", "withdrawn", "graduated"];
        if (!studentId || valid.indexOf(status) === -1) {
            return res.status(400).json({ message: "A valid student_id and status (active / withdrawn / graduated) are required." });
        }
        if (!studentStatusColsReady) {
            return res.status(503).json({ message: "Student status is not available on this database yet." });
        }
        const statusDate = status === "active" ? null : new Date().toISOString().slice(0, 10);
        connection.query(
            "UPDATE students SET status = ?, status_date = ? WHERE student_id = ?",
            [status, statusDate, studentId],
            (err, result) => {
                if (err) { console.log(err); return res.status(500).json({ message: "Database error while updating status." }); }
                if (result.affectedRows === 0) {
                    return res.status(404).json({ message: "No student found with that Admission Number." });
                }
                res.json({ message: "Student marked as " + status + ".", status: status });
            }
        );
    });

    app.post("/update-student-photo", requireLogin, writeRateLimit, upload.single("photo"), (req, res) => {
        if (!req.file) {
            return res.status(400).json({ message: "No photo uploaded." });
        }
        const studentId = (req.body.student_id || "").trim();
        if (!studentId) {
            return res.status(400).json({ message: "Missing student ID." });
        }
        const photoPath = `images/students/${req.file.filename}`;
        connection.query(
            "UPDATE students SET photo_path = ? WHERE student_id = ?",
            [photoPath, studentId],
            (err, result) => {
                if (err) {
                    console.log(err);
                    return res.status(500).json({ message: "Database error while saving photo." });
                }
                if (result.affectedRows === 0) {
                    return res.status(404).json({ message: "No student found with that ID." });
                }
                // FIX (pack 20): database copy of the photo (survives disk wipes)
                backupStudentPhoto(studentId, req.file.path);
                res.json({ message: "Photo saved.", photo_path: photoPath });
            }
        );
    });

    app.get("/download-student-template", requireLogin, (req, res) => {
        const filePath = path.join(__dirname, "templates", "student_upload_template.xlsx");
        res.download(filePath, "student_upload_template.xlsx", (err) => {
            if (err) {
                console.log(err);
                if (!res.headersSent) {
                    res.status(500).send("Could not download template.");
                }
            }
        });
    });

    app.post("/bulk-add-students", requireLogin, writeRateLimit, uploadExcel.single("file"), (req, res) => {
        if (!req.file) {
            return res.status(400).json({ message: "No file uploaded." });
        }

        let rows;
        try {
            const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
            const sheetName = workbook.SheetNames[0];
            const sheet = workbook.Sheets[sheetName];
            rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        } catch (err) {
            console.log(err);
            return res.status(400).json({ message: "Could not read the uploaded file. Make sure it's a valid .xlsx, .xls, or .csv file." });
        }

        if (rows.length === 0) {
            return res.status(400).json({ message: "The file has no student rows in it." });
        }

        // First, fetch the valid class list so we can validate each row's class name.
        connection.query("SELECT class_name FROM classes", (err, classRows) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Database error while checking classes." });
            }

            const validClasses = new Set(classRows.map(c => c.class_name));
            const results = { inserted: 0, errors: [] };

            let index = 0;

            function processNextRow() {
                if (index >= rows.length) {
                    return res.json({
                        message: `${results.inserted} of ${rows.length} student(s) added successfully.`,
                        inserted: results.inserted,
                        total: rows.length,
                        errors: results.errors
                    });
                }

                const row = rows[index];
                const rowNum = index + 2; // +2 because row 1 is the header and index is 0-based
                index++;

                const studentId = String(row["Student ID"] || "").trim();
                const fullName = String(row["Full Name"] || "").trim();
                const gender = String(row["Gender"] || "").trim();
                const className = String(row["Class"] || "").trim();
                let dob = row["Date of Birth (YYYY-MM-DD)"];

                // NEW (template clarity): rows whose Student ID starts with
                // "EXAMPLE" are the template's sample rows - skip them so a
                // forgotten example row can never create a fake student.
                if (studentId.toUpperCase().startsWith("EXAMPLE")) {
                    return processNextRow();
                }

                // Excel sometimes gives dates as JS Date objects instead of strings
                if (dob instanceof Date) {
                    dob = dob.toISOString().split("T")[0];
                } else {
                    dob = String(dob || "").trim();
                    // NEW (template clarity): also accept dates pasted/typed
                    // as DD/MM/YYYY text - convert to the expected YYYY-MM-DD.
                    const mdy = dob.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
                    if (mdy) {
                        dob = `${mdy[3]}-${mdy[2].padStart(2, "0")}-${mdy[1].padStart(2, "0")}`;
                    }
                }

                // CHANGED (pack 20 - owner request): Class is NO LONGER
                // required - some pupils are not yet assigned to a class,
                // some dropped out or were transferred. Rows with a blank
                // Class now upload fine (blank class, assignable later);
                // only misspelt/non-empty class names are still refused.
                if (!studentId || !fullName || !gender) {
                    results.errors.push(`Row ${rowNum}: Missing required field(s) (Student ID, Full Name, and Gender are required; Class may be left blank).`);
                    return processNextRow();
                }

                if (gender !== "Male" && gender !== "Female") {
                    results.errors.push(`Row ${rowNum}: Gender must be exactly "Male" or "Female" (got "${gender}").`);
                    return processNextRow();
                }

                // CHANGED (pack 20): an EMPTY class is allowed (stored blank);
                // only a NON-empty class must exist in the class list.
                if (className && !validClasses.has(className)) {
                    results.errors.push(`Row ${rowNum}: "${className}" is not a recognized class. Check the "Valid Classes" sheet in the template (or leave Class blank to assign the pupil later).`);
                    return processNextRow();
                }

                connection.query(
                    "INSERT INTO students (student_id, full_name, gender, class_name, date_of_birth) VALUES (?,?,?,?,?)",
                    [studentId, fullName, gender, className, dob || null],
                    (err) => {
                        if (err) {
                            if (err.code === "ER_DUP_ENTRY") {
                                results.errors.push(`Row ${rowNum}: Student ID "${studentId}" already exists.`);
                            } else {
                                console.log(err);
                                results.errors.push(`Row ${rowNum}: Database error saving this row.`);
                            }
                        } else {
                            results.inserted++;
                        }
                        processNextRow();
                    }
                );
            }

            processNextRow();
        });
    });

app.post("/promote-class", requireLogin, (req, res) => {
    console.log("PROMOTE ROUTE CALLED");

    const { currentClass, nextClass: reqNextClass, mode } = req.body;
    let nextClass = reqNextClass && reqNextClass.trim() ? reqNextClass.trim() : "";

    if (!nextClass) {
        const promoteMap = {
            // Arabic classes
            "الأوّل التّحضيريّ": "الثّاني التّحضيريّ",
            "الثّاني التّحضيريّ": "الثّالث التّحضيريّ",
            "الثّالث التّحضيريّ": "الأوّل الابتدائيّ",
            "الأوّل الابتدائيّ": "الثّاني الابتدائيّ",
            "الثّاني الابتدائيّ": "الثّالث الابتدائيّ",
            "الثّالث الابتدائيّ": "الرّابع الابتدائيّ",
            "الرّابع الابتدائيّ": "الأوّل الإعداديّ",
            "الأوّل الإعداديّ": "الثّاني الإعداديّ",
            "الثّاني الإعداديّ": "الثّالث الإعداديّ",
            "الثّالث الإعداديّ": "الأوّل الثّانويّ",
            "الأوّل الثّانويّ": "الثّاني الثّانويّ",
            "الثّاني الثّانويّ": "الثّالث الثّانويّ",
            // English classes (JSS, SSS, Primary, Preliminary, Quranic)
            "Primary 1": "Primary 2",
            "Primary 2": "Primary 3",
            "Primary 3": "Primary 4",
            "Primary 4": "Primary 5",
            "Primary 5": "JSS 1",
            "JSS 1": "JSS 2",
            "JSS 2": "JSS 3",
            "JSS 3": "SSS 1",
            "SSS 1": "SSS 2",
            "SSS 2": "SSS 3",
            "Preliminary 1": "Preliminary 2",
            "Preliminary 2": "Preliminary 3",
            "Preliminary 3": "Primary 1"
        };
        nextClass = promoteMap[currentClass] || "";
    }

    if (!nextClass) {
        return res.status(400).send("No target class found. Please select a valid current class or specify Target Next Class.");
    }

    if (mode === "all") {
        const sql = `
            UPDATE students
            SET class_name = ?
            WHERE class_name = ?
        `;
        connection.query(sql, [nextClass, currentClass], (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.send(`🚀 Unconditional Promotion Complete: ${result.affectedRows} student(s) promoted from ${currentClass} to ${nextClass}.`);
        });
        return;
    }

    // ⭐ Smart Merit-Based Promotion: check 3rd Term / session averages
    connection.query(
        "SELECT student_id, full_name FROM students WHERE class_name = ?",
        [currentClass],
        (err, students) => {
            if (err || !students || !students.length) {
                return res.send(`0 student(s) found in class ${currentClass}.`);
            }
            connection.query(
                "SELECT student_id, ROUND(AVG(total), 1) AS avg_total FROM results WHERE class_name = ? GROUP BY student_id",
                [currentClass],
                (err2, avgs) => {
                    const avgMap = {};
                    (avgs || []).forEach(row => { avgMap[row.student_id] = Number(row.avg_total); });

                    const promotedIds = [];
                    const promotedNames = [];
                    const repeatNames = [];

                    students.forEach(st => {
                        const score = avgMap[st.student_id];
                        if (score === undefined || isNaN(score) || score >= 50) {
                            promotedIds.push(st.student_id);
                            promotedNames.push(st.full_name || st.student_id);
                        } else {
                            repeatNames.push(`${st.full_name || st.student_id} (${score}%)`);
                        }
                    });

                    if (!promotedIds.length) {
                        return res.send(`⚠️ Smart Merit-Based Summary for ${currentClass}:\n• 0 students promoted.\n• Held Back to Repeat (${repeatNames.length}): ${repeatNames.join(", ")}`);
                    }

                    const placeholders = promotedIds.map(() => "?").join(",");
                    connection.query(
                        `UPDATE students SET class_name = ? WHERE student_id IN (${placeholders})`,
                        [nextClass].concat(promotedIds),
                        (uErr, uRes) => {
                            if (uErr) {
                                console.log(uErr);
                                return res.status(500).send("Database Error during promotion update");
                            }
                            let summary = `✅ Smart Merit-Based Promotion Summary for ${currentClass}:\n` +
                                `• Promoted to ${nextClass}: ${promotedIds.length} student(s)\n`;
                            if (repeatNames.length > 0) {
                                summary += `• Held Back to Repeat ${currentClass} (<50% average): ${repeatNames.length} student(s)\n  [${repeatNames.join(", ")}]`;
                            } else {
                                summary += `• Repeaters (<50% average): 0 student(s) (100% promotion rate!)`;
                            }
                            res.send(summary);
                        }
                    );
                }
            );
        }
    );
});


// ----------------------------------------------------------------
// NEW (export): download EVERY result in the school as ONE Excel file.
// 100% READ-ONLY - it only SELECTs; no result calculation, style, print
// logic or result page is touched in any way. Uses the existing XLSX
// dependency already installed for bulk student upload.
// ----------------------------------------------------------------
app.get("/export-all-results", requireLogin, (req, res) => {
    // NEW (per-class export): optional ?class=<exact class name> filter.
    // Empty or missing -> export everything (unchanged behaviour).
    const classFilter = (req.query.class || "").trim();
    const where = classFilter ? "WHERE class_name = ?" : "";
    const params = classFilter ? [classFilter] : [];

    connection.query(
        `SELECT student_id, student_name, class_name, term, session, subject,
                first_test, second_test, note_score, attendance_score,
                ca_score, exam_score, total, grade
         FROM results
         ${where}
         ORDER BY session, term, class_name, student_name, subject`,
        params,
        (err, rows) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            if (!rows || rows.length === 0) {
                return res.status(404).send(classFilter
                    ? "No results found for that class yet."
                    : "No results to export yet.");
            }

            // Rename columns once, in human-friendly plain English.
            const data = rows.map((r) => ({
                "Student ID": r.student_id,
                "Student Name": r.student_name,
                "Class": r.class_name,
                "Session": r.session,
                "Term": r.term,
                "Subject": r.subject,
                "1st Test": r.first_test,
                "2nd Test": r.second_test,
                "Note": r.note_score,
                "Attendance": r.attendance_score,
                "CA Total": r.ca_score,
                "Exam Score": r.exam_score,
                "Total": r.total,
                "Grade": r.grade
            }));

            const workbook = XLSX.utils.book_new();
            const sheet = XLSX.utils.json_to_sheet(data);
            sheet["!cols"] = [
                { wch: 12 }, { wch: 28 }, { wch: 24 }, { wch: 12 }, { wch: 10 },
                { wch: 26 }, { wch: 9 }, { wch: 9 }, { wch: 7 }, { wch: 11 },
                { wch: 9 }, { wch: 11 }, { wch: 8 }, { wch: 7 }
            ];
            XLSX.utils.book_append_sheet(workbook, sheet, "All Results");
            const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

            const fileName = classFilter
                ? `results-${classFilter.replace(/[^\w؀-ۿ-]/g, "_")}.xlsx`
                : "all-results.xlsx";
            res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
            // NEW: encodeURIComponent keeps Arabic class names valid in the filename header
            res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`);
            res.send(buffer);
        }
    );
});

app.delete("/delete-result/:id", requireLogin, (req, res) => {
    const id= req.params.id;

    connection.query(
        "DELETE FROM results WHERE id = ?",
        [id],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json({
                message:"Result deleted successfully",
        });
        }
    );
});

app.delete("/delete-results-by-student/:studentId", requireLogin, (req, res) => {
    const studentId = req.params.studentId;

    connection.query(
        "DELETE FROM results WHERE student_id = ?",
        [studentId],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            res.json({
                message: `${result.affectedRows} result(s) deleted successfully`,
                count: result.affectedRows
            });
        }
    );
});

app.delete("/delete-student/:studentId", requireLogin, requireAdmin, (req, res) => {
    const studentId = req.params.studentId;

    connection.query(
        "DELETE FROM students WHERE student_id = ?",
        [studentId],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).send("Database Error");
            }
            // Cascade delete any orphan scores, attendance, tahfeedh, or chat records for this student
            connection.query("DELETE FROM results WHERE student_id = ?", [studentId], () => {});
            connection.query("DELETE FROM attendance WHERE student_id = ?", [studentId], () => {});
            connection.query("DELETE FROM tahfeedh WHERE student_id = ?", [studentId], () => {});
            connection.query("DELETE FROM messages WHERE (sender_type = 'portal' AND sender_ref = ?) OR (recipient_type = 'parent' AND recipient_ref = ?) OR sender_ref = ? OR recipient_ref = ?", [studentId, studentId, studentId, studentId], () => {});

            res.json({
                message: "Student deleted successfully",
            });
        }
    );
});

// NEW (Pack 45): automatic orphan cleanup - removes any ghost scores in results
// where the student_id no longer exists in the students database table.
app.delete("/api/clean-orphan-results", requireLogin, (req, res) => {
    const sql = `
        DELETE r FROM results r
        LEFT JOIN students s ON r.student_id = s.student_id
        WHERE s.student_id IS NULL
    `;
    connection.query(sql, (err, result) => {
        if (err) {
            console.log(err);
            return res.status(500).json({ message: "Database Error while cleaning orphan results" });
        }
        res.json({
            message: `Purged ${result.affectedRows} ghost/orphan score(s) from database.`,
            removed: result.affectedRows
        });
    });
});

// NEW (Pack 45): one-click score deletion for a specific student in a term+session
// directly from the Class Results broadsheet page.
app.delete("/api/delete-student-term-results", requireLogin, (req, res) => {
    const { student_id, term, session } = req.body;
    if (!student_id || !term || !session) {
        return res.status(400).json({ message: "Student ID, Term and Session are required." });
    }
    connection.query(
        "DELETE FROM results WHERE student_id = ? AND term = ? AND session = ?",
        [student_id, term, session],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Database Error" });
            }
            res.json({
                message: `Deleted ${result.affectedRows} result row(s) for student.`,
                count: result.affectedRows
            });
        }
    );
});

// NEW (Pack 45): clear all results for an entire class in a specific term+session.
app.delete("/api/clear-class-term-results", requireLogin, (req, res) => {
    const { class_name, term, session } = req.body;
    if (!class_name || !term || !session) {
        return res.status(400).json({ message: "Class, Term and Session are required." });
    }
    connection.query(
        "DELETE FROM results WHERE class_name = ? AND term = ? AND session = ?",
        [class_name, term, session],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Database Error" });
            }
            res.json({
                message: `Cleared ${result.affectedRows} score row(s) for ${class_name}.`,
                count: result.affectedRows
            });
        }
    );
});

// Admin-only: wipe ALL results and ALL students. Used for clearing test data
// before real use. This does NOT touch subjects or users (login accounts).
app.delete("/wipe-all-data", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM results", (err) => {
        if (err) {
            console.log(err);
            return res.status(500).send("Database Error while clearing results");
        }

        connection.query("DELETE FROM students", (err2) => {
            if (err2) {
                console.log(err2);
                return res.status(500).send("Database Error while clearing students");
            }

            res.json({ message: "All results and student records have been cleared." });
        });
    });
});


/* =====================================================================
   NEW (pack 13) - SCHOOL WEBSITE + PORTAL + MANAGEMENT APIs.
   Everything below is ADDITIVE: new tables only, no existing route,
   query, result calculation or report generation is touched.
   ===================================================================== */

/* ---------- Student / Parent portal (login: Student ID + surname) --- */
app.post("/portal-login", (req, res) => {
    if (!loginRateLimit(req, res)) return;
    const studentId = (req.body.student_id || "").trim();
    const password  = (req.body.password  || "").trim();
    if (!studentId || !password) {
        return res.status(400).json({ message: "Student ID and surname are required." });
    }
    connection.query("SELECT * FROM students WHERE student_id = ?", [studentId], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(401).json({ message: "Invalid Student ID or surname" });
        const st = rows[0];
        const fullName = (st.full_name || "").trim();
        const surname  = fullName ? fullName.split(/\s+/).pop() : "";
        const sendOk = () => {
            req.session.portalStudentId = st.student_id;
            res.json({
                message: "Login successful",
                student: {
                    student_id: st.student_id,
                    full_name: st.full_name,
                    class_name: st.class_name,
                    gender: st.gender,
                    date_of_birth: st.date_of_birth,
                    photo_path: st.photo_path
                }
            });
        };
        // NEW (pack 23): if the family set their own password in portal
        // Settings, it REPLACES the surname rule. Legacy login unchanged
        // for everyone who has not set one yet.
        if (st.portal_password) {
            return bcrypt.compare(password, st.portal_password, (err, match) => {
                if (err || !match) return res.status(401).json({ message: "Invalid Student ID or password" });
                sendOk();
            });
        }
        const ok = password.toLowerCase() === surname.toLowerCase()
                || password.toLowerCase() === fullName.toLowerCase();
        if (!ok) return res.status(401).json({ message: "Invalid Student ID or surname" });
        sendOk();
    });
});

app.get("/portal/me", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json({ loggedIn: false });
    connection.query("SELECT * FROM students WHERE student_id = ?", [sid], (err, rows) => {
        if (err || !rows.length) {
            if (err) console.log(err);
            return res.json({ loggedIn: false });
        }
        res.json({ loggedIn: true, student: rows[0] });
    });
});

app.post("/portal/logout", (req, res) => {
    if (req.session) delete req.session.portalStudentId;
    res.json({ message: "Logged out" });
});

/* Terms/sessions that (a) the student actually has results for AND
   (b) admin has PUBLISHED (per-class row or whole-term row).
   FIX (pack 84): no SQL JOIN (collation-safe) + match current class
   OR the class stored on the result row (promotion-safe). */
app.get("/portal/published-terms", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        `SELECT DISTINCT r.term, r.session, r.class_name
         FROM results r
         WHERE TRIM(r.student_id) = TRIM(?) OR LOWER(TRIM(r.student_id)) = LOWER(TRIM(?))`,
        [sid, sid],
        (err, resultRows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            if (!resultRows || !resultRows.length) return res.json([]);
            connection.query(
                "SELECT class_name, term, session, published FROM result_publish WHERE published = 1",
                (err2, pubs) => {
                    if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                    connection.query(
                        "SELECT class_name FROM students WHERE TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)) LIMIT 1",
                        [sid, sid],
                        (err3, stu) => {
                            const currentClass = (stu && stu[0] && stu[0].class_name) || "";
                            const seen = Object.create(null);
                            const out = [];
                            (resultRows || []).forEach((r) => {
                                const key = String(r.term || "") + "|" + String(r.session || "");
                                if (seen[key]) return;
                                const ok = isTermPublished(pubs, r.term, r.session, r.class_name)
                                    || isTermPublished(pubs, r.term, r.session, currentClass)
                                    || isTermPublished(pubs, r.term, r.session, "");
                                if (ok) {
                                    seen[key] = true;
                                    out.push({ term: r.term, session: r.session });
                                }
                            });
                            out.sort((a, b) => String(b.session).localeCompare(String(a.session)) || String(a.term).localeCompare(String(b.term)));
                            res.json(out);
                        }
                    );
                }
            );
        }
    );
});

/* ---------- Admin: publish / unpublish results ---------------------- */
app.get("/result-publish", requireLogin, requireAdmin, (req, res) => {
    let sql = "SELECT class_name, term, session, published FROM result_publish";
    const params = [];
    const wh = [];
    if (req.query.term)    { wh.push("term = ?");    params.push(req.query.term); }
    if (req.query.session) { wh.push("session = ?"); params.push(req.query.session); }
    if (wh.length) sql += " WHERE " + wh.join(" AND ");
    sql += " ORDER BY session, term, class_name";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

// ADMIN only - "except it is been publish by admin".
app.post("/result-publish", requireLogin, requireAdmin, (req, res) => {
    const className = (req.body.class_name || "").trim(); // '' = whole term
    const term      = (req.body.term || "").trim();
    const session   = (req.body.session || "").trim();
    const published = Number(req.body.published) ? 1 : 0;
    if (!term || !session) {
        return res.status(400).json({ message: "Term and session are required." });
    }
    connection.query(
        `INSERT INTO result_publish (class_name, term, session, published)
         VALUES (?,?,?,?)
         ON DUPLICATE KEY UPDATE published = VALUES(published)`,
        [className, term, session, published],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            /* NEW (pack 32): the moment results go live, every subscribed
               parent's phone rings - "results are out!" (fire-and-forget;
               the save answer itself never waits). */
            if (published) {
                const qs = className
                    ? ["SELECT student_id FROM students WHERE class_name = ?", [className]]
                    : ["SELECT student_id FROM students", []];
                connection.query(qs[0], qs[1], (sErr, studs) => {
                    if (sErr || !studs || !studs.length) return;
                    amsPushSend("portal", studs.map(r => r.student_id), {
                        title: "\u{1F4CA} Results are out!",
                        body: (className ? className + " \u2022 " : "") + term + ", " + session + " - open your portal to see the scores.",
                        url: "/portal.html",
                        tag: "result-" + term + "-" + session
                    });
                });
            }
            res.json({ message: "Saved", class_name: className, term, session, published });
        }
    );
});

/* ---------- Admission enquiries (public website form) --------------- */
app.post("/admission-enquiry", (req, res) => {
    const child  = (req.body.child_name || "").trim();
    const parent = (req.body.parent_name || "").trim();
    const phone  = (req.body.phone || "").trim();
    const cls    = (req.body.class_applied || "").trim();
    const msg    = (req.body.message || "").trim();
    if (!child || !phone) {
        return res.status(400).json({ message: "Child's name and a phone number are required." });
    }
    connection.query(
        "INSERT INTO admission_enquiries (child_name, parent_name, phone, class_applied, message) VALUES (?,?,?,?,?)",
        [child, parent, phone, cls, msg],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Thank you! The school will contact you soon." });
        }
    );
});

app.get("/admission-enquiries", requireLogin, requireAdmin, (req, res) => {
    connection.query(
        // CHANGED (pack 38 - owner: "some of the student information is not
        // displaying" on the admission letter): also return the pack-37
        // pipeline columns so the board + letter can show Admission No,
        // gender and date of birth (additive - old clients ignore extras).
        "SELECT id, child_name, parent_name, phone, class_applied, message, status, created_at, gender, date_of_birth, admitted_student_id, admitted_at FROM admission_enquiries ORDER BY created_at DESC LIMIT 500",
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

app.put("/admission-enquiry/:id", requireLogin, requireAdmin, (req, res) => {
    const status = (req.body.status || "").trim();
    // CHANGED (pack 37): 'declined' added - the enquiry board is now a
    // full little pipeline (new -> contacted -> admitted / declined).
    if (!["new", "contacted", "admitted", "declined"].includes(status)) {
        return res.status(400).json({ message: "Invalid status." });
    }
    connection.query("UPDATE admission_enquiries SET status = ? WHERE id = ?", [status, req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Updated" });
    });
});

/* NEW (pack 37 - admission pipeline): suggested next Student ID.
   Real IDs look like AM/26/143 (AM / admission year / running serial)
   - this takes the biggest serial on record and adds one. */
function amsNextStudentId(cb) {
    connection.query("SELECT student_id FROM students WHERE student_id LIKE 'AM/%/%'", (err, rows) => {
        if (err) return cb(err);
        let max = 0;
        (rows || []).forEach((r) => {
            const m = /^AM\/\d{2}\/(\d+)$/.exec(r.student_id || "");
            if (m) max = Math.max(max, parseInt(m[1], 10));
        });
        const yy = String(new Date().getFullYear()).slice(-2);
        cb(null, "AM/" + yy + "/" + String(max + 1).padStart(3, "0"));
    });
}

app.get("/admission-next-id", requireLogin, requireAdmin, (req, res) => {
    amsNextStudentId((err, sid) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ student_id: sid });
    });
});

/* NEW (pack 37 - admission pipeline): one-tap ADMIT straight from an
   enquiry. Creates the REAL student record (same columns as Add
   Student, photo left blank - it can be added later from Students) so
   the Student/Parent portal login starts working immediately (surname
   = password, until the family changes it), then marks the enquiry
   admitted and stamps the new ID onto it. Never admits twice. */
app.post("/admission-enquiry/:id/admit", requireLogin, requireAdmin, (req, res) => {
    const id = parseInt(req.params.id, 10);
    if (!id) return res.status(400).json({ message: "Invalid enquiry id." });

    const fullName    = (req.body.full_name || "").trim();
    const gender      = (req.body.gender || "").trim();
    const className   = (req.body.class_name || "").trim();
    let   dob         = (req.body.date_of_birth || "").trim();
    const parentName  = (req.body.parent_name || "").trim();
    const parentPhone = (req.body.parent_phone || "").trim();
    let   studentId   = (req.body.student_id || "").trim();

    if (!fullName) return res.status(400).json({ message: "Child's full name is required." });
    if (gender !== "Male" && gender !== "Female") {
        return res.status(400).json({ message: 'Gender must be exactly "Male" or "Female".' }); // same rule as the uploader
    }
    if (!className) return res.status(400).json({ message: "Class is required for admission." });
    if (dob && !/^\d{4}-\d{2}-\d{2}$/.test(dob)) {
        return res.status(400).json({ message: "Date of birth must be YYYY-MM-DD." });
    }

    connection.query("SELECT * FROM admission_enquiries WHERE id = ?", [id], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "Enquiry not found." });
        const enq = rows[0];
        if (enq.status === "admitted" && enq.admitted_student_id) {
            return res.status(409).json({
                message: "Already admitted as " + enq.admitted_student_id + ".",
                student_id: enq.admitted_student_id
            });
        }

        connection.query("SELECT class_name FROM classes", (cErr, cls) => {
            if (cErr) { console.log(cErr); return res.status(500).json({ message: "Database error" }); }
            if (!(cls || []).some((c) => c.class_name === className)) {
                return res.status(400).json({ message: '"' + className + '" is not a recognized class.' }); // same rule as the uploader
            }

            const insertAndMark = (sid) => {
                const finish = () => {
                    // Stamp the pipeline fields back onto the enquiry. If a
                    // column is somehow missing yet (fresh boot race), the
                    // student is still admitted - we just log the notice.
                    connection.query(
                        `UPDATE admission_enquiries
                         SET status = 'admitted',
                             admitted_student_id = ?,
                             admitted_at = COALESCE(admitted_at, NOW()),
                             parent_name = COALESCE(NULLIF(?, ''), parent_name),
                             phone = COALESCE(NULLIF(?, ''), phone),
                             gender = COALESCE(NULLIF(?, ''), gender),
                             class_applied = ?,
                             date_of_birth = COALESCE(?, date_of_birth)
                         WHERE id = ?`,
                        [sid, parentName, parentPhone, gender, className, dob || null, id],
                        (uErr) => { if (uErr) console.log("Pack 37 admit-stamp notice:", uErr.code || uErr.message); }
                    );
                    res.json({
                        message: fullName + " admitted into " + className +
                                 ". Student/Parent portal login is now ACTIVE (password = child's surname).",
                        student_id: sid
                    });
                };
                const onInsert = (iErr) => {
                    if (iErr && iErr.code === "ER_DUP_ENTRY") {
                        return res.status(409).json({ message: 'Student ID "' + sid + '" already exists.' });
                    }
                    if (iErr) { console.log(iErr); return res.status(500).json({ message: "Error saving student" }); }
                    finish();
                };
                // Same shape as /save-student: parent columns when the
                // profile columns exist, otherwise the ORIGINAL insert -
                // backward compatible, no photo (added later if wanted).
                if (studentProfileColsReady) {
                    connection.query(
                        `INSERT INTO students
                         (student_id, full_name, gender, class_name, date_of_birth, photo_path,
                          parent_name, parent_phone, address)
                         VALUES (?,?,?,?,?,NULL,?,?,NULL)`,
                        [sid, fullName, gender, className, dob || null, parentName || null, parentPhone || null],
                        (iErr) => {
                            if (iErr && iErr.code === "ER_BAD_FIELD_ERROR") return insertOriginal();
                            onInsert(iErr);
                        }
                    );
                } else {
                    insertOriginal();
                }
                function insertOriginal() {
                    connection.query(
                        "INSERT INTO students (student_id, full_name, gender, class_name, date_of_birth, photo_path) VALUES (?,?,?,?,?,NULL)",
                        [sid, fullName, gender, className, dob || null],
                        onInsert
                    );
                }
            };

            const go = (sid) => {
                connection.query("SELECT 1 FROM students WHERE student_id = ? LIMIT 1", [sid], (dErr, dup) => {
                    if (dErr) { console.log(dErr); return res.status(500).json({ message: "Database error" }); }
                    if ((dup || []).length) {
                        return res.status(409).json({ message: 'Student ID "' + sid + '" already exists.' });
                    }
                    insertAndMark(sid);
                });
            };

            if (studentId) return go(studentId);
            amsNextStudentId((nErr, sid) => {
                if (nErr) { console.log(nErr); return res.status(500).json({ message: "Database error" }); }
                go(sid);
            });
        });
    });
});

/* NEW (pack 37): remove spam / mistakenly-sent enquiries (admin only). */
app.delete("/admission-enquiry/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM admission_enquiries WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Deleted" });
    });
});

/* ---------- Student attendance -------------------------------------- */
/* ==================================================================
   PACK 108 — the register 500 killer (owner: "the students are still
   not displaying after I select a class to mark the register; the
   mistake is in csrf.js:52 again; 500 internal server error; the page
   says 'Could not load the register. The server answered with an error
   (status 500)'").

   csrf.js:52 is again only where the browser ATTRIBUTES the failed
   call — it is the wrapper's own `nativeFetch(url, options)` line. This
   time the server genuinely answered 500, and the only thing that can
   answer 500 here is the SQL inside GET /attendance/class:

       LEFT JOIN attendance a
         ON a.student_id = s.student_id
        AND a.att_date = ?
        AND LOWER(TRIM(a.class_name)) = LOWER(TRIM(?))
       WHERE TRIM(s.class_name) = TRIM(?)
         AND (s.status IS NULL OR LOWER(TRIM(s.status)) = 'active')

   Four column references on tables that grew over 100+ packs, any one
   of which is a hard 500 on a real school database:
     * `attendance` is provisioned with CREATE TABLE IF NOT EXISTS — it
       NEVER upgrades a table that already exists. A school whose
       attendance table predates pack 13 has no class_name / marked_by
       column → ER_BAD_FIELD_ERROR → 500 → empty register.
     * `attendance` may not exist yet at all (fresh Railway/Render DB, or
       a boot where the add-on block never finished) → ER_NO_SUCH_TABLE.
     * `students.status` came later too — which is also why the class
       dropdown was quietly served by the /classes fallback: that
       endpoint failed for the very same reason and swallowed it.
     * `attendance` and `classes` are NOT in COLLATION_FIX_TABLES, so on
       a database whose tables carry different default collations, the
       cross-table UNION / comparison can die with
       ER_CANT_AGGREGATE_2COLLATIONS ("Illegal mix of collations").

   The fix is to stop ASSUMING the schema and start READING it:
     1. attSchema() asks information_schema which tables, columns and
        indexes actually exist (cached 60s) and every attendance query is
        then BUILT from what is really there.
     2. Saved marks are read by (student_id, date) in their own tiny query
        and merged in JavaScript. No cross-table string comparison
        survives, so no collation clash is possible, and
        `attendance.class_name` is no longer needed to open the register
        (attendance keeps exactly one row per pupil per day, so the class
        condition in the old JOIN never changed the answer anyway).
     3. If the marks half still fails, the register STILL RETURNS the
        class roster — that is the list of children the teacher is
        standing in front of — and says what could not be read through the
        X-AMS-Notice response header. "Everyone present, correct it" beats
        a red 500 and an empty table.
     4. No attendance route answers a bare 500 "Database error" any more:
        the real database message is passed to the page so the teacher
        (and the owner) can read the actual cause instead of a status code.
     5. A guarded boot migration heals the drift itself where it safely
        can (create the table, add the missing columns, add the
        one-row-per-pupil-per-day key when there are no duplicates), so
        most schools never even reach step 3.
   Result data, grading, report cards, fees: completely untouched.
   ==================================================================== */

/* Which attendance tables/columns/indexes are REALLY there. Cached for a
   minute; if the probe itself fails the cache holds `unknown:true` and
   every attHas() answers "yes" so the documented (already correct) queries
   run exactly as before — the guard can only ever add safety. */
const ATT_SCHEMA_TTL = 60000;
let attSchemaCache = null;
let attSchemaWaiters = null;

function attProbeSchema(done) {
    connection.query(
        `SELECT TABLE_NAME AS t, COLUMN_NAME AS c
           FROM information_schema.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE()
            AND TABLE_NAME IN ('attendance', 'students', 'classes')`,
        (err, rows) => {
            if (err) {
                console.log("[attendance] schema probe failed:", err.code || err.message || err);
                attSchemaCache = { at: Date.now(), data: { unknown: true } };
                return done(attSchemaCache.data);
            }
            const sets = { attendance: new Set(), students: new Set(), classes: new Set() };
            (rows || []).forEach(function (r) {
                const t = String(r.t || "").toLowerCase();
                if (sets[t]) sets[t].add(String(r.c || "").toLowerCase());
            });
            connection.query(
                `SELECT INDEX_NAME AS i,
                        GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS cols,
                        MAX(NON_UNIQUE) AS non_unique
                   FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance'
                  GROUP BY INDEX_NAME`,
                (kErr, kRows) => {
                    const idx = kErr ? [] : (kRows || []).map(function (x) {
                        return {
                            cols: String(x.cols || "").toLowerCase().replace(/\s+/g, ""),
                            unique: Number(x.non_unique) === 0
                        };
                    });
                    const data = {
                        unknown: false,
                        attendance: sets.attendance,
                        students: sets.students,
                        classes: sets.classes,
                        hasAttendanceTable: sets.attendance.size > 0,
                        /* (student_id, att_date) unique = the upsert the register
                           relies on. Without it a re-save would pile a second row
                           on the same pupil for the same day. */
                        uniqueDayKey: idx.some(function (k) { return k.unique && k.cols === "student_id,att_date"; })
                    };
                    attSchemaCache = { at: Date.now(), data };
                    done(data);
                }
            );
        }
    );
}

function attSchema(cb) {
    if (attSchemaCache && Date.now() - attSchemaCache.at < ATT_SCHEMA_TTL) return cb(attSchemaCache.data);
    if (attSchemaWaiters) { attSchemaWaiters.push(cb); return; }
    attSchemaWaiters = [cb];
    attProbeSchema(function (data) {
        const waiters = attSchemaWaiters || [];
        attSchemaWaiters = null;
        waiters.forEach(function (f) { try { f(data); } catch (e) { console.log(e); } });
    });
}

/* "does this column exist?" — unknown schema is treated as the documented
   one so this can never make a working query worse. */
function attHas(schema, table, col) {
    if (!schema || schema.unknown) return true;
    const set = schema[table];
    return !!set && set.has(col);
}
function attTable(schema, table) {
    if (!schema || schema.unknown) return true;
    const set = schema[table];
    return !!set && set.size > 0;
}

/* TRIM only — Arabic class names must survive byte for byte (no
   LOWERCASE on either side, it has corrupted Arabic in some engines). */
function attClassName(raw) {
    return String(raw == null ? "" : raw).trim();
}

/* A DATE column never accepts junk: validate here so a stray value gives
   the teacher a 400 with a sentence, not a 1292 error that surfaces as 500. */
function attDateOnly(raw) {
    const v = String(raw == null ? "" : raw).trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : "";
}

/* One-line explanation for the page when part of the job could not be done.
   Response headers must stay 7-bit ASCII, hence the scrub. */
function attNotice(res, text) {
    if (!text) return;
    try {
        res.setHeader("X-AMS-Notice", String(text).replace(/[^\x20-\x7E]+/g, " ").trim().slice(0, 400));
    } catch (e) { /* headers already sent — the notice is optional */ }
}

/* Honest failures: log the real MySQL error AND hand it to the page. */
function attDbFail(res, err, what) {
    const detail = err ? String(err.sqlMessage || err.message || err.code || err) : "unknown database error";
    console.log("[attendance] " + what + " failed:", (err && (err.code || err.sqlMessage || err.message)) || err);
    return res.status(500).json({ message: "Could not " + what + " — database said: " + detail, detail: detail });
}

/* The roster rule used everywhere in this module: pupils of this class that
   are not marked withdrawn/graduated. `status` is only referenced when the
   column exists; matching happens on trimmed bytes. */
function attRosterSql(schema) {
    let sql = "SELECT s.student_id, s.full_name";
    if (attHas(schema, "students", "gender")) sql += ", s.gender";
    sql += " FROM students s";
    const where = [];
    if (attHas(schema, "students", "status")) where.push("(s.status IS NULL OR LOWER(TRIM(s.status)) = 'active')");
    if (attHas(schema, "students", "class_name")) where.push("TRIM(s.class_name) = TRIM(?)");
    if (where.length) sql += " WHERE " + where.join(" AND ");
    return sql + " ORDER BY s.full_name";
}

/* The class names in this school live in two tables (classes + students) and
   are typed by hand, so the same class can differ by a double space, a
   non-breaking space or Latin case. This folder is used ONLY for the
   last-resort comparison; only ASCII is lowercased because lowercasing
   Arabic in some engines corrupts it. */
function attFoldClass(raw) {
    return String(raw == null ? "" : raw)
        .replace(/[\u00A0\u2007\u202F\u200B\uFEFF]/g, " ")
        .replace(/\s+/g, " ")
        .trim()
        .replace(/[A-Z]/g, function (c) { return c.toLowerCase(); });
}

/* Last-resort roster: whole students table, filtered in JavaScript. Needs
   no column guarantees and no collation agreement at all. */
function attRosterFromJs(className, done) {
    connection.query("SELECT * FROM students", (err, rows) => {
        if (err) return done(err, null);
        const want = attFoldClass(className);
        const list = (rows || [])
            .filter(function (s) {
                const st = s.status == null ? "active" : attFoldClass(s.status);
                return (st === "active" || st === "") && attFoldClass(s.class_name) === want;
            })
            .map(function (s) {
                return { student_id: s.student_id, full_name: s.full_name, gender: s.gender == null ? null : s.gender };
            })
            .sort(function (a, b) { return String(a.full_name || "").localeCompare(String(b.full_name || "")); });
        done(null, list);
    });
}

function attLoadRoster(schema, className, done) {
    connection.query(attRosterSql(schema), [className], function (err, rows) {
        if (err) {
            console.log("[attendance] roster query failed, falling back to the JS roster:", err.code || err.sqlMessage || err.message);
            return attRosterFromJs(className, done);
        }
        rows = rows || [];
        if (rows.length) {
            return done(null, rows.map(function (r) {
                return { student_id: r.student_id, full_name: r.full_name, gender: r.gender == null ? null : r.gender };
            }));
        }
        /* Zero rows is the OTHER half of this bug report ("the students are
           not displaying"): an exact comparison that disagrees by one
           invisible space. Retry once with the folded comparison instead of
           telling the teacher the class is empty. */
        return attRosterFromJs(className, function (e2, list) {
            if (e2) {
                console.log("[attendance] roster fallback failed too:", e2.code || e2.sqlMessage || e2.message);
                return done(null, []);
            }
            done(null, list || []);
        });
    });
}

/* NEW (pack 108): the register used to die on `attendance.class_name`, a
   column that only exists on databases created from pack 13 onwards. Marks
   are therefore looked up by pupil + day, which the table has always had
   one row for. Returns {status} per student_id through the callback. */
function attLoadMarks(schema, date, roster, done) {
    if (!attTable(schema, "attendance") || !attHas(schema, "attendance", "att_date") || !attHas(schema, "attendance", "status")) {
        return done({ missing: true });
    }
    const ids = roster.map(function (r) { return String(r.student_id); }).filter(Boolean);
    if (!ids.length) return done(null, {});
    let sql = "SELECT student_id, status FROM attendance WHERE att_date = ? AND student_id IN (?)";
    if (attHas(schema, "attendance", "id")) sql += " ORDER BY id DESC";
    connection.query(sql, [date, ids], function (err, rows) {
        if (err) {
            /* A broken/absent marks table must never hide the class list. */
            console.log("[attendance] marks query failed:", err.code || err.sqlMessage || err.message);
            return done({ failed: err });
        }
        const by = {};
        (rows || []).forEach(function (m) {
            const k = String(m.student_id);
            if (!(k in by)) by[k] = m.status;
        });
        done(null, by);
    });
}

/* Distinct class names from BOTH the classes table AND the students table,
   so the dropdown always offers every class that actually has pupils.
   NEW (pack 108): each side is cast to ONE collation before the UNION —
   mixing two table collations in a UNION is an "Illegal mix of collations"
   error, and that 500 is exactly why the dropdown was falling back to the
   plain /classes list. The characters are untouched (utf8mb4 holds the
   Arabic as-is); only the comparison rules are agreed on. */
app.get("/api/distinct-classes", requireLogin, (req, res) => {
    attSchema(function (schema) {
        const fromStudents = attTable(schema, "students") && attHas(schema, "students", "class_name");
        const fromClasses = attTable(schema, "classes") && attHas(schema, "classes", "class_name");
        const cast = function (alias) {
            return "SELECT DISTINCT CONVERT(TRIM(" + alias + ") USING utf8mb4) COLLATE utf8mb4_unicode_ci AS class_name";
        };
        const parts = [];
        if (fromStudents) {
            let s = cast("class_name") + " FROM students WHERE class_name IS NOT NULL AND TRIM(class_name) != ''";
            if (attHas(schema, "students", "status")) s += " AND (status IS NULL OR LOWER(TRIM(status)) = 'active')";
            parts.push(s);
        }
        if (fromClasses) {
            parts.push(cast("class_name") + " FROM classes WHERE class_name IS NOT NULL AND TRIM(class_name) != ''");
        }
        if (!parts.length) {
            return res.json([]);
        }
        connection.query(parts.join(" UNION ") + " ORDER BY class_name", (err, rows) => {
            if (err) {
                console.log("[attendance] distinct-classes failed:", err.code || err.sqlMessage || err.message);
                /* One side alone is still better than an empty dropdown. */
                if (parts.length > 1) {
                    return connection.query(parts[0] + " ORDER BY class_name", (e2, r2) => {
                        if (e2) return attDbFail(res, e2, "load the class list");
                        res.json((r2 || []).map(function (x) { return { class_name: x.class_name }; }));
                    });
                }
                return attDbFail(res, err, "load the class list");
            }
            res.json((rows || []).map(function (x) { return { class_name: x.class_name }; }));
        });
    });
});

/* Portal: attendance for a student (used by parent portal) */
app.get("/portal/attendance", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]); // return empty array (not 401) so portal handles gracefully
    connection.query(
        `SELECT att_date, status, class_name
         FROM attendance
         WHERE student_id = ?
         ORDER BY att_date DESC
         LIMIT 366`,
        [sid],
        (err, rows) => {
            if (err) { console.log(err); return res.json([]); }
            res.json(rows || []);
        }
    );
});

/* THE MARK REGISTER (pack 108 rewrite — same URL, same JSON array, same
   row fields as always, so nothing else on the page or in the PDFs has to
   change). Steps: roster -> marks -> merge. A failure in step two can only
   ever cost the "already marked today" tick, never the list of pupils. */
app.get("/attendance/class", requireLogin, (req, res) => {
    const className = attClassName(req.query.class_name);
    const date = attDateOnly(req.query.date);
    if (!className) return res.status(400).json({ message: "Pick a class first (class_name is required)." });
    if (!date) return res.status(400).json({ message: "Pick a real date (YYYY-MM-DD) for the register." });

    attSchema(function (schema) {
        if (!attTable(schema, "students") || !attHas(schema, "students", "class_name")) {
            return res.status(503).json({
                message: "The register needs a class_name column in the students table and this database does not have it yet. Restarting the server adds it automatically (nothing else is touched), then the class list appears here."
            });
        }
        attLoadRoster(schema, className, function (rErr, roster) {
            if (rErr) return attDbFail(res, rErr, "load the class list from the students table");
            roster = roster || [];
            if (!roster.length) {
                /* Empty is a real answer here — but say WHY if the table we
                   compare against does not even exist. */
                if (!attTable(schema, "students")) {
                    attNotice(res, "The students table is not available yet, so no class list could be built.");
                }
                return res.json([]);
            }
            attLoadMarks(schema, date, roster, function (mErr, byId) {
                if (mErr && mErr.missing) {
                    attNotice(res, !attTable(schema, "attendance")
                        ? "There is no attendance table in this database yet, so nothing could be read back and everyone starts as Present. The table is created automatically when the server starts - if this message stays after a restart, the database user needs CREATE permission."
                        : "The attendance table does not have its att_date/status column yet, so marks saved earlier could not be shown - everyone starts as Present. Mark the class and save as usual; the start-up repair adds the missing column on the next restart.");
                } else if (mErr) {
                    attNotice(res, "Marks saved earlier could not be read from the attendance table, so everyone starts as Present. You can still mark and save the register.");
                }
                const marks = byId || {};
                res.json(roster.map(function (r) {
                    r.status = marks[String(r.student_id)] || null;
                    return r;
                }));
            });
        });
    });
});

/* SAVE. NEW (pack 108): the insert is built from the columns that exist,
   and when the (student_id, att_date) unique key is missing the day is
   cleared for those pupils first — otherwise ON DUPLICATE KEY UPDATE never
   fires and a second save silently doubles every name in the register. */
app.post("/attendance/save", requireLogin, (req, res) => {
    const className = attClassName(req.body.class_name);
    const date = attDateOnly(req.body.date);
    const records = Array.isArray(req.body.records) ? req.body.records : [];
    if (!className) return res.status(400).json({ message: "class_name is required." });
    if (!date) return res.status(400).json({ message: "A valid date (YYYY-MM-DD) is required." });
    if (!records.length) return res.status(400).json({ message: "No marks to save - load the register first." });

    const valid = ["present", "absent", "late"];
    const markedBy = req.session.username || null;
    const wanted = records
        .filter(r => r && r.student_id && valid.includes(r.status))
        .map(r => ({ student_id: String(r.student_id), status: r.status }));
    if (!wanted.length) return res.status(400).json({ message: "No valid records supplied." });

    attSchema(function (schema) {
        if (!attTable(schema, "attendance")) {
            return res.status(503).json({
                message: "Attendance could not be saved because the 'attendance' table is not in this database yet. It is created automatically when the server starts — if you can see this after a restart, the database user needs CREATE/ALTER permission (then restart once)."
            });
        }
        if (!attHas(schema, "attendance", "att_date") || !attHas(schema, "attendance", "student_id") || !attHas(schema, "attendance", "status")) {
            return res.status(503).json({
                message: "Attendance could not be saved: the 'attendance' table is missing its student_id/att_date/status column. The automatic repair at server start-up will add it — restart the app once and try again."
            });
        }
        const cols = ["student_id", "att_date", "status"];
        if (attHas(schema, "attendance", "class_name")) cols.push("class_name");
        if (attHas(schema, "attendance", "marked_by")) cols.push("marked_by");
        const values = wanted.map(function (w) {
            const out = [w.student_id, date, w.status];
            if (attHas(schema, "attendance", "class_name")) out.push(className);
            if (attHas(schema, "attendance", "marked_by")) out.push(markedBy);
            return out;
        });
        const dup = cols.indexOf("class_name") !== -1
            ? " ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)"
            : " ON DUPLICATE KEY UPDATE status = VALUES(status)";
        const doInsert = function () {
            connection.query(
                "INSERT INTO attendance (" + cols.map(function (c) { return "`" + c + "`"; }).join(", ") + ") VALUES ?" +
                (schema.uniqueDayKey ? dup : ""),
                [values],
                (err) => {
                    if (err) return attDbFail(res, err, "save the attendance register");
                    if (!attHas(schema, "attendance", "class_name")) {
                        attNotice(res, "Saved. Note: this database's attendance table has no class_name column, so the class was not recorded against each row.");
                    }
                    res.json({ message: "Attendance saved", count: values.length });
                }
            );
        };
        if (schema.uniqueDayKey || !attHas(schema, "attendance", "class_name")) return doInsert();
        /* No unique key: replace the day's rows for these pupils instead of
           appending a duplicate set. */
        connection.query(
            "DELETE FROM attendance WHERE att_date = ? AND student_id IN (?)",
            [date, wanted.map(function (w) { return w.student_id; })],
            function (dErr) {
                if (dErr) console.log("[attendance] pre-save clean skipped:", dErr.code || dErr.message);
                doInsert();
            }
        );
    });
});

/* ---------- pack 109: report helpers (single-table, collation-immune) -----
   Each of these reads ONE table. None of them can raise "Illegal mix of
   collations", because that error needs two columns from two tables to meet
   in one comparison — which is exactly what the old JOIN did. */

/* Which pupils belong to this class? Same two-tier rule the register uses:
   exact trimmed match first, folded match (double spaces, non-breaking
   spaces, Latin case) only when that finds nobody. `pupils` is the
   id -> full_name map used later to label the rows. */
function attReportClassIds(schema, className, done) {
    const pick = function (rows) {
        const pupils = {};
        const ids = [];
        (rows || []).forEach(function (s) {
            const id = String(s.student_id == null ? "" : s.student_id).trim();
            if (!id) return;
            pupils[id] = s.full_name == null ? null : s.full_name;
            ids.push(id);
        });
        return { ids: ids, pupils: pupils };
    };
    /* Last resort (no readable class_name column): whole students table,
       filtered in JS. Needs no column guarantees and no collation agreement. */
    const fromJs = function () {
        connection.query("SELECT * FROM students", function (e3, r3) {
            if (e3) return done(e3, null);
            const want = attFoldClass(className);
            const list = (r3 || []).filter(function (s) {
                const st = s.status == null ? "active" : attFoldClass(s.status);
                return (st === "active" || st === "") && attFoldClass(s.class_name) === want;
            });
            done(null, pick(list));
        });
    };
    if (!attTable(schema, "students") || !attHas(schema, "students", "class_name")) return fromJs();
    connection.query(attRosterSql(schema), [className], function (err, rows) {
        if (err) {
            console.log("[attendance] report class list failed, matching in JS:", err.code || err.sqlMessage || err.message);
            return fromJs();
        }
        const exact = pick(rows);
        if (exact.ids.length) return done(null, exact);
        /* Zero rows is usually one invisible space of disagreement, not an
           empty class — retry with the folded comparison. */
        fromJs();
    });
}

/* Every mark in the range for those pupils, from the attendance table alone.
   When the table carries class_name it is used to widen the read (a pupil who
   changed class still keeps the days marked under the old name); the pupil id
   list is the floor in both cases. */
function attReportMarks(schema, className, ids, from, to, done) {
    const hasClassCol = attHas(schema, "attendance", "class_name");
    const want = attFoldClass(className);
    const collect = function (rows) {
        const keep = {};
        ids.forEach(function (id) { keep[id] = true; });
        const marks = [];
        (rows || []).forEach(function (r) {
            const id = String(r.student_id == null ? "" : r.student_id).trim();
            if (!id) return;
            /* Rows reached through the class_name side must belong to a pupil
               of this class too — the id list stays authoritative. */
            if (!keep[id]) return;
            marks.push({ student_id: id, status: r.status });
        });
        return marks;
    };
    if (!hasClassCol) {
        return connection.query(
            "SELECT student_id, status FROM attendance WHERE att_date BETWEEN ? AND ? AND student_id IN (?)",
            [from, to, ids],
            function (err, rows) { if (err) return done(err, null); done(null, collect(rows)); }
        );
    }
    connection.query(
        "SELECT student_id, status, class_name FROM attendance WHERE att_date BETWEEN ? AND ?",
        [from, to],
        function (err, rows) {
            if (err) {
                console.log("[attendance] report marks read failed, retrying by pupil id:", err.code || err.sqlMessage || err.message);
                return connection.query(
                    "SELECT student_id, status FROM attendance WHERE att_date BETWEEN ? AND ? AND student_id IN (?)",
                    [from, to, ids],
                    function (e2, r2) { if (e2) return done(e2, null); done(null, collect(r2)); }
                );
            }
            /* The class column may be stored under a differently-spelled copy
               of the same name, so fold it the same way the roster does. */
            const inClass = (rows || []).filter(function (r) { return attFoldClass(r.class_name) === want; });
            done(null, collect(inClass.length ? inClass : rows));
        }
    );
}

/* One row per pupil that has at least one mark in the range (unchanged
   behaviour: the old GROUP BY only ever returned pupils with marks), sorted
   by name like the old ORDER BY s.full_name did. */
function attReportNames(pupils, marks, done) {
    const by = {};
    (marks || []).forEach(function (m) {
        const e = by[m.student_id] || (by[m.student_id] = {
            student_id: m.student_id, full_name: pupils[m.student_id] == null ? m.student_id : pupils[m.student_id],
            present: 0, absent: 0, late: 0, marked: 0
        });
        e.marked++;
        if (m.status === "present") e.present++;
        else if (m.status === "absent") e.absent++;
        else if (m.status === "late") e.late++;
    });
    const rows = Object.keys(by).map(function (k) { return by[k]; });
    /* Names for pupils the roster did not supply (a pupil who left the class
       but still has marks in the range) — a single-table read, not a JOIN. */
    const missing = rows.filter(function (r) { return pupils[r.student_id] == null; }).map(function (r) { return r.student_id; });
    const finish = function () {
        rows.sort(function (a, b) { return String(a.full_name || "").localeCompare(String(b.full_name || "")); });
        done(null, rows);
    };
    if (!missing.length) return finish();
    connection.query(
        "SELECT student_id, full_name FROM students WHERE student_id IN (?)",
        [missing],
        function (err, r2) {
            if (!err) {
                const named = {};
                (r2 || []).forEach(function (s) { named[String(s.student_id)] = s.full_name; });
                rows.forEach(function (r) { if (named[r.student_id] != null) r.full_name = named[r.student_id]; });
            }
            finish();
        }
    );
}

/* DATE-RANGE REPORT.
   REWRITTEN (pack 109) — same URL, same JSON fields (student_id, full_name,
   present, absent, late, marked), so attendance.js and the A4 PDF are
   untouched.

   WHY: "Load report" died with
     Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and
     (utf8mb4_0900_ai_ci,IMPLICIT) for operation '='
   The old query read
     FROM attendance a JOIN students s ON s.student_id = a.student_id
   and pack 108 had pinned COLLATE only on the *class_name* comparison. But
   `attendance` is created without a pinned collation, so on MySQL 8 its
   student_id carries utf8mb4_0900_ai_ci while `students` carries
   utf8mb4_unicode_ci — the JOIN KEY ITSELF is the illegal mix. That is why
   the retry did not help either: it used the very same JOIN, so the route
   failed twice and the second failure became the 500 the page showed.

   THE FIX follows what this module already proved on the register (pack 108):
   read each table on its own and merge in JavaScript. Every statement below
   touches exactly ONE table, so no two collations ever meet and the report
   works whether or not the boot-time CONVERT was allowed to run.
   Names are fetched for the pupils that actually have marks (a small IN
   list), never by joining. */
app.get("/attendance/report", requireLogin, (req, res) => {
    const className = attClassName(req.query.class_name);
    const from = attDateOnly(req.query.from);
    const to = attDateOnly(req.query.to);
    if (!className) return res.status(400).json({ message: "Pick a class first." });
    if (!from || !to) return res.status(400).json({ message: "Pick a real 'from' and 'to' date (YYYY-MM-DD)." });

    attSchema(function (schema) {
        if (!attTable(schema, "attendance") || !attHas(schema, "attendance", "att_date")) {
            attNotice(res, "There is no readable attendance table yet, so the report is empty.");
            return res.json([]);
        }
        attReportClassIds(schema, className, function (cErr, matched) {
            if (cErr) return attDbFail(res, cErr, "build the attendance report");
            const ids = matched.ids;
            /* A class with no pupils at all is an honest empty report. */
            if (!ids.length) return res.json([]);
            attReportMarks(schema, className, ids, from, to, function (mErr, marks) {
                if (mErr) return attDbFail(res, mErr, "build the attendance report");
                attReportNames(matched.pupils, marks, function (nErr, rows) {
                    if (nErr) return attDbFail(res, nErr, "build the attendance report");
                    res.json(rows);
                });
            });
        });
    });
});

/* ---------- pack 109: shared single-table readers -------------------------
   The "Illegal mix of collations" 500 behind Load Report came from comparing
   a string column of `attendance` with one of `students` inside a JOIN. These
   two readers keep the summary and the per-pupil history on ONE table at a
   time, so no two collations can meet no matter how the tables were built. */

/* The banner's honest answer when nothing could be read. */
function attEmptySummary() {
    return { taken: false, total: 0, present: 0, absent: 0, late: 0, marked_by: null, saved_at: null };
}

/* Count one day for one class without joining: take the class's pupil ids
   (exact match first, folded match as the retry), then count that day inside
   the attendance table alone. */
function attDaySummaryByClass(schema, select, className, date, answer) {
    attReportClassIds(schema, className, function (err, matched) {
        if (err) return answer(err, null);
        const ids = (matched && matched.ids) || [];
        if (!ids.length) return answer(null, [attEmptySummary()]);
        connection.query(select + " FROM attendance WHERE att_date = ? AND student_id IN (?)", [date, ids], answer);
    });
}

/* Read one pupil's name from `students` on its own (the history below used to
   LEFT JOIN for it). A failure costs the name only, never the history. */
function attStudentName(sid, done) {
    connection.query("SELECT full_name FROM students WHERE student_id = ? LIMIT 1", [sid], function (err, rows) {
        if (err) {
            console.log("[attendance] name lookup failed:", err.code || err.sqlMessage || err.message);
            return done(null);
        }
        done(rows && rows[0] ? rows[0].full_name : null);
    });
}

/* "Already taken for this date" banner (pack 14). NEW (pack 108): a missing
   or half-built attendance table simply means "not taken yet" — it must
   never turn into a red error on top of the register. */
app.get("/attendance/summary", requireLogin, (req, res) => {
    const className = attClassName(req.query.class_name);
    const date = attDateOnly(req.query.date);
    if (!className || !date) return res.status(400).json({ message: "class_name and date are required." });

    attSchema(function (schema) {
        if (!attTable(schema, "attendance") || !attHas(schema, "attendance", "att_date")) return res.json(attEmptySummary());
        const hasStatus = attHas(schema, "attendance", "status");
        const hasMarkedBy = attHas(schema, "attendance", "marked_by");
        const hasCreatedAt = attHas(schema, "attendance", "created_at");
        const select = `SELECT COUNT(*) AS total,
                    ${hasStatus ? "SUM(status = 'present') AS present, SUM(status = 'absent') AS absent, SUM(status = 'late') AS late," : "0 AS present, 0 AS absent, 0 AS late,"}
                    ${hasMarkedBy ? "MAX(marked_by) AS marked_by," : "NULL AS marked_by,"}
                    ${hasCreatedAt ? "MAX(created_at) AS saved_at" : "NULL AS saved_at"}
             `;
        const answer = function (err, rows) {
            if (err) {
                console.log("[attendance] summary failed:", err.code || err.sqlMessage || err.message);
                return res.json(attEmptySummary());
            }
            const r = (rows && rows[0]) || {};
            res.json({
                taken: Number(r.total) > 0,
                total: Number(r.total) || 0,
                present: Number(r.present) || 0,
                absent: Number(r.absent) || 0,
                late: Number(r.late) || 0,
                marked_by: r.marked_by || null,
                saved_at: r.saved_at || null
            });
        };
        /* The banner must count THIS CLASS only - and on no account the whole
           school, which is what a bare `att_date = ?` would do.
           NEW (pack 109): this used to branch on whether the attendance table
           carries class_name, matching it either through a pinned COLLATE
           string comparison or through a JOIN to `students`. Both are gone:
             - the JOIN compared attendance.student_id with
               students.student_id, two string columns from tables built with
               different default collations, so on MySQL 8 it raised the very
               same "Illegal mix of collations ... for operation '='" that
               killed Load Report. Here the error was swallowed, so the banner
               quietly read "not taken yet" and a class could be marked twice;
             - the COLLATE comparison was still an exact string match, so a
               class saved as "SS  1" (double space) never matched the "SS 1"
               in the dropdown either.
           The class is now resolved to its pupil ids by the same two-tier
           matcher the register and the report use, and the day is counted
           inside the attendance table alone. One table per statement, so no
           two collations can meet, and the folding makes the banner agree
           with what the register shows. */
        /* No readable class list at all resolves to an empty id list inside
           attDaySummaryByClass, which answers "not taken" - honest, and never
           the whole-school count a bare `att_date = ?` would have produced. */
        attDaySummaryByClass(schema, select, className, date, answer);
    });
});

/* Per-pupil history (pack 17) — same guards, an unreadable table reads as
   "no history yet" instead of a 500.
   NEW (pack 109): the LEFT JOIN on students.student_id = attendance.student_id
   is gone for the same reason the report's JOIN went - two string columns from
   tables with different default collations cannot be compared on MySQL 8. The
   history comes from `attendance` alone and the pupil's name is read
   separately; the JSON keeps its full_name field. */
app.get("/attendance/student", requireLogin, (req, res) => {
    const sid = (req.query.student_id || "").trim();
    if (!sid) return res.status(400).json({ message: "student_id is required." });
    attSchema(function (schema) {
        if (!attTable(schema, "attendance") || !attHas(schema, "attendance", "att_date")) return res.json([]);
        const extra = (attHas(schema, "attendance", "class_name") ? ", class_name" : "") +
            (attHas(schema, "attendance", "status") ? ", status" : "");
        connection.query(
            `SELECT att_date${extra}
             FROM attendance
             WHERE student_id = ?
             ORDER BY att_date DESC
             LIMIT 366`,
            [sid],
            (err, rows) => {
                if (err) {
                    console.log("[attendance] history failed:", err.code || err.sqlMessage || err.message);
                    return res.json([]);
                }
                rows = rows || [];
                if (!rows.length) return res.json(rows);
                attStudentName(sid, function (name) {
                    res.json(rows.map(function (r) { r.full_name = name; return r; }));
                });
            }
        );
    });
});

/* NEW (pack 108): BOOT REPAIR for the attendance table. Purely additive and
   guarded the same way as the other pack migrations (its own short-lived
   connection, information_schema consulted first, retried a few times while
   the database is warming up, silent if the user has no ALTER/CREATE right):
     - creates `attendance` when it is missing entirely;
     - appends only the columns a legacy copy does not have (class_name and
       marked_by are the two that break the register on older databases);
     - adds the (student_id, att_date) unique key when the table holds no
       duplicate day rows, because the register's upsert depends on it.
   No row is renamed or deleted and no mark is rewritten — existing data is
   untouched. (ensureAttendanceCollation() below is the one exception: it may
   re-state the table's comparison rules, never its values.) */
function ensureAttendanceSchema(attempt) {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return attBootRetry(attempt, err); }
        conn.query(
            `SELECT COLUMN_NAME AS c FROM information_schema.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance'`,
            (qErr, rows) => {
                if (qErr) { conn.end(); return attBootRetry(attempt, qErr); }
                const have = new Set((rows || []).map(function (r) { return String(r.c).toLowerCase(); }));
                if (!have.size) {
                    conn.query(
                        `CREATE TABLE IF NOT EXISTS attendance (
                            id INT AUTO_INCREMENT PRIMARY KEY,
                            student_id VARCHAR(100) NOT NULL,
                            class_name VARCHAR(150) NOT NULL DEFAULT '',
                            att_date DATE NOT NULL,
                            status ENUM('present','absent','late') NOT NULL DEFAULT 'present',
                            marked_by VARCHAR(100),
                            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                            UNIQUE KEY uniq_student_day (student_id, att_date),
                            INDEX (att_date)
                        ) DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci`,
                        (cErr) => {
                            conn.end();
                            if (cErr) {
                                console.log("[attendance] boot repair could not create the table:", cErr.code || cErr.message);
                                return attBootRetry(attempt, cErr);
                            }
                            attSchemaCache = null;
                            console.log("Attendance setup ready (attendance table created with the one-row-per-pupil-per-day key).");
                        }
                    );
                    return;
                }
                const adds = [];
                if (!have.has("student_id")) adds.push("ADD COLUMN student_id VARCHAR(100) NOT NULL DEFAULT ''");
                if (!have.has("class_name")) adds.push("ADD COLUMN class_name VARCHAR(150) NOT NULL DEFAULT ''");
                if (!have.has("att_date")) adds.push("ADD COLUMN att_date DATE NULL");
                if (!have.has("status")) adds.push("ADD COLUMN status ENUM('present','absent','late') NOT NULL DEFAULT 'present'");
                if (!have.has("marked_by")) adds.push("ADD COLUMN marked_by VARCHAR(100) NULL");
                if (adds.length) {
                    conn.query("ALTER TABLE attendance " + adds.join(", "), (aErr) => {
                        if (aErr && aErr.code !== "ER_DUP_FIELDNAME") {
                            console.log("[attendance] boot repair skipped (columns):", aErr.code || aErr.message);
                        } else {
                            attSchemaCache = null;
                            console.log("Attendance setup ready (added " + adds.length + " missing column(s) to the attendance table).");
                        }
                        conn.end();
                        ensureAttendanceDayKey();
                    });
                } else {
                    conn.end();
                    ensureAttendanceDayKey();
                }
            }
        );
    });
}

/* NEW (pack 109): heal the collation drift itself, where that is allowed.
   `attendance` is created without a pinned collation on databases that
   predate the pack-108 CREATE, so on MySQL 8 its string columns inherit
   utf8mb4_0900_ai_ci while `students` is utf8mb4_unicode_ci. Every attendance
   route now reads one table at a time and works regardless, but converting the
   table also protects the rest of the app (exports, admin queries, anything
   that still joins attendance to students). Guarded exactly like the other
   boot migrations: information_schema is asked first, the ALTER runs only
   when the collation really differs, and a refusal (no ALTER right, locked
   table, MariaDB without utf8mb4_0900_ai_ci) is logged and skipped - the
   routes do not depend on it. No row values change; only the comparison rules
   for student_id / class_name are agreed with `students`. */
function ensureAttendanceCollation() {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return; }
        conn.query(
            `SELECT TABLE_COLLATION AS tc FROM information_schema.TABLES
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance'`,
            (tErr, rows) => {
                if (tErr || !rows || !rows.length) { conn.end(); return; }
                const current = String(rows[0].tc || "").toLowerCase();
                if (!current || current === "utf8mb4_unicode_ci") { conn.end(); return; }
                conn.query(
                    "ALTER TABLE attendance CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci",
                    (aErr) => {
                        conn.end();
                        if (aErr) {
                            console.log("[attendance] boot repair skipped (collation):", aErr.code || aErr.message);
                            console.log("  -> Not fatal: every attendance query now reads one table at a time, so no two collations meet.");
                            return;
                        }
                        attSchemaCache = null;
                        console.log("Attendance collation healed (was " + current + ", now utf8mb4_unicode_ci) - cross-table comparisons are safe again.");
                    }
                );
            }
        );
    });
}

/* The (student_id, att_date) unique key needs its own guarded pass, because
   it is only safe once we know the table holds no duplicate day rows. */
function ensureAttendanceDayKey() {
    const conn = addonConnection();
    conn.connect((err) => {
        if (err) { conn.destroy(); return; }
        conn.query(
            `SELECT INDEX_NAME AS i, GROUP_CONCAT(COLUMN_NAME ORDER BY SEQ_IN_INDEX) AS cols, MAX(NON_UNIQUE) AS nu
               FROM information_schema.STATISTICS
              WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'attendance'
              GROUP BY INDEX_NAME`,
            (iErr, rows) => {
                if (iErr) {
                    conn.end();
                    return console.log("[attendance] boot repair skipped (index check):", iErr.code || iErr.message);
                }
                const already = (rows || []).some(function (x) {
                    return Number(x.nu) === 0 && String(x.cols || "").toLowerCase().replace(/\s+/g, "") === "student_id,att_date";
                });
                if (already) return conn.end();
                conn.query(
                    "SELECT student_id, att_date FROM attendance GROUP BY student_id, att_date HAVING COUNT(*) > 1 LIMIT 1",
                    (dErr, dRows) => {
                        if (dErr) {
                            conn.end();
                            return console.log("[attendance] boot repair skipped (duplicate check):", dErr.code || dErr.message);
                        }
                        if ((dRows || []).length) {
                            conn.end();
                            console.log("[attendance] the table already holds duplicate day rows - the register upserts by (student_id, date) anyway, so nothing was deleted. Add the unique key once the duplicates are merged if you want it enforced at the table level.");
                            return;
                        }
                        conn.query(
                            "ALTER TABLE attendance ADD UNIQUE KEY uniq_student_day (student_id, att_date)",
                            (aErr) => {
                                conn.end();
                                if (aErr && aErr.code !== "ER_DUP_KEYNAME") {
                                    return console.log("[attendance] boot repair skipped (unique key):", aErr.code || aErr.message);
                                }
                                attSchemaCache = null;
                                console.log("Attendance setup ready (one row per pupil per day enforced).");
                            }
                        );
                    }
                );
            }
        );
    });
}

function attBootRetry(attempt, err) {
    const reason = err && (err.code || err.message) || err;
    if (attempt >= 4) {
        console.log("[attendance] boot repair gave up after 4 attempts:", reason);
        console.log("  -> The register keeps working anyway: every attendance query now adapts to the table it finds.");
        return;
    }
    console.log(`[attendance] boot repair: attempt ${attempt} failed (${reason}); retrying in 4s...`);
    setTimeout(() => ensureAttendanceSchema(attempt + 1), 4000);
}

ensureAttendanceSchema(1);
ensureAttendanceCollation();

/* ---------- Staff attendance + weekly evaluations ------------------- */
app.get("/staff-list", requireLogin, (req, res) => {
    connection.query("SELECT username, role FROM users ORDER BY username", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.get("/staff-attendance", requireLogin, (req, res) => {
    const date = (req.query.date || "").trim();
    if (!date) return res.status(400).json({ message: "date is required." });
    connection.query(
        /* COLLATE hint (pack 109): `staff_attendance` is created without a
           pinned collation, so on MySQL 8 its staff_username is
           utf8mb4_0900_ai_ci while `users` (converted at boot) is
           utf8mb4_unicode_ci - the same illegal mix that broke Load Report,
           on the staff register instead. Pinning the join key keeps the two
           sides agreeing without touching the stored text. */
        `SELECT u.username, u.role, sa.status
         FROM users u
         LEFT JOIN staff_attendance sa
                ON sa.staff_username = u.username COLLATE utf8mb4_unicode_ci
               AND sa.att_date = ?
         ORDER BY u.username`,
        [date],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

app.post("/staff-attendance/save", requireLogin, requireAdmin, (req, res) => {
    const date = (req.body.date || "").trim();
    const records = Array.isArray(req.body.records) ? req.body.records : [];
    if (!date || !records.length) return res.status(400).json({ message: "date and records are required." });
    const markedBy = req.session.username || null;
    const rows = records
        .filter(r => r && r.username && ["present", "absent"].includes(r.status))
        .map(r => [String(r.username), date, r.status, markedBy]);
    if (!rows.length) return res.status(400).json({ message: "No valid records supplied." });
    connection.query(
        `INSERT INTO staff_attendance (staff_username, att_date, status, marked_by)
         VALUES ?
         ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)`,
        [rows],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Staff attendance saved", count: rows.length });
        }
    );
});

app.post("/staff-evaluation/save", requireLogin, requireAdmin, (req, res) => {
    const username = (req.body.username || "").trim();
    const weekStart = (req.body.week_start || "").trim();
    const clamp = v => { const n = parseInt(v, 10); return (n >= 1 && n <= 10) ? n : null; };
    const teaching = clamp(req.body.teaching), punctuality = clamp(req.body.punctuality), conduct = clamp(req.body.conduct);
    const comment = (req.body.comment || "").trim();
    if (!username || !weekStart) return res.status(400).json({ message: "username and week_start are required." });
    connection.query(
        `INSERT INTO staff_evaluations (staff_username, week_start, teaching, punctuality, conduct, comment, created_by)
         VALUES (?,?,?,?,?,?,?)`,
        [username, weekStart, teaching, punctuality, conduct, comment, req.session.username || null],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Evaluation saved" });
        }
    );
});

app.get("/staff-evaluations", requireLogin, requireAdmin, (req, res) => {
    let sql = "SELECT id, staff_username, week_start, teaching, punctuality, conduct, comment, created_by, created_at FROM staff_evaluations";
    const params = [];
    if (req.query.username) { sql += " WHERE staff_username = ?"; params.push(req.query.username); }
    sql += " ORDER BY week_start DESC, id DESC LIMIT 100";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

/* ---------- Finance: fee structure, payments, expenses -------------- */
app.get("/fee-structure", requireLogin, requireAdmin, (req, res) => {
    let sql = "SELECT class_name, term, session, amount FROM fee_structure";
    const params = [], wh = [];
    if (req.query.term)    { wh.push("term = ?");    params.push(req.query.term); }
    if (req.query.session) { wh.push("session = ?"); params.push(req.query.session); }
    if (wh.length) sql += " WHERE " + wh.join(" AND ");
    sql += " ORDER BY class_name";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/fee-structure", requireLogin, requireAdmin, (req, res) => {
    const className = (req.body.class_name || "").trim();
    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    const amount = Number(req.body.amount);
    if (!className || !term || !session || !(amount >= 0)) {
        return res.status(400).json({ message: "class_name, term, session and a valid amount are required." });
    }
    connection.query(
        `INSERT INTO fee_structure (class_name, term, session, amount)
         VALUES (?,?,?,?)
         ON DUPLICATE KEY UPDATE amount = VALUES(amount)`,
        [className, term, session, amount],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Fee saved", class_name: className, amount });
        }
    );
});

app.post("/fee-payment", requireLogin, requireAdmin, (req, res) => {
    const studentId = (req.body.student_id || "").trim();
    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    const amount = Number(req.body.amount);
    const method = (req.body.method || "").trim();
    const note = (req.body.note || "").trim();
    if (!studentId || !term || !session || !(amount > 0)) {
        return res.status(400).json({ message: "student_id, term, session and an amount above 0 are required." });
    }
    // CHANGED (pack 15): payments are tagged with a FEE TYPE (School Fee,
    // Developmental Fee, Exam Fee, custom). Falls back to the original
    // insert if the column is somehow missing (backward compatible).
    const feeType = (req.body.fee_type || "School Fee").trim() || "School Fee";
    connection.query(
        `INSERT INTO fee_payments (student_id, term, session, fee_type, amount, method, note, received_by)
         VALUES (?,?,?,?,?,?,?,?)`,
        [studentId, term, session, feeType, amount, method, note, req.session.username || null],
        (err) => {
            if (err && err.code === "ER_BAD_FIELD_ERROR") {
                return connection.query(
                    `INSERT INTO fee_payments (student_id, term, session, amount, method, note, received_by)
                     VALUES (?,?,?,?,?,?,?)`,
                    [studentId, term, session, amount, method, note, req.session.username || null],
                    (err2) => {
                        if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                        amsPushSend("portal", [studentId], { // NEW (pack 32)
                            title: "\u2705 Payment received",
                            body: "\u20A6" + amount.toLocaleString("en-US") + " (" + feeType + ") for " + term + " has been recorded. Thank you!",
                            url: "/portal.html", tag: "fee-" + studentId
                        });
                        res.json({ message: "Payment recorded", amount });
                    }
                );
            }
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            /* NEW (pack 32): parent's phone confirms instantly - no more
               "did the school see my money?" */
            amsPushSend("portal", [studentId], {
                title: "\u2705 Payment received",
                body: "\u20A6" + amount.toLocaleString("en-US") + " (" + feeType + ") for " + term + ", " + session + " has been recorded. Thank you!",
                url: "/portal.html", tag: "fee-" + studentId
            });
            res.json({ message: "Payment recorded", amount, fee_type: feeType });
        }
    );
});

app.get("/fee-payments", requireLogin, requireAdmin, (req, res) => {
    /* CHANGED (pack 82): LEFT JOIN students so every payment row also carries
       the student's NAME and CLASS (needed for the official receipt). If the
       join ever errors, we gracefully fall back to the original plain
       SELECT * so payment records NEVER break. */
    const params = [], wh = [];
    if (req.query.student_id) { wh.push("fp.student_id = ?"); params.push(req.query.student_id); }
    if (req.query.term)       { wh.push("fp.term = ?");       params.push(req.query.term); }
    if (req.query.session)    { wh.push("fp.session = ?");    params.push(req.query.session); }
    let joinSql = "SELECT fp.*, s.full_name AS student_name, s.class_name AS class_name " +
                  "FROM fee_payments fp LEFT JOIN students s ON s.student_id = fp.student_id";
    if (wh.length) joinSql += " WHERE " + wh.join(" AND ");
    joinSql += " ORDER BY fp.paid_at DESC LIMIT 200";
    connection.query(joinSql, params, (err, rows) => {
        if (!err) return res.json(rows);
        console.log("fee-payments join failed - falling back to plain select:", err.message || err);
        let sql = "SELECT * FROM fee_payments";
        const p2 = [], w2 = [];
        if (req.query.student_id) { w2.push("student_id = ?"); p2.push(req.query.student_id); }
        if (req.query.term)       { w2.push("term = ?");       p2.push(req.query.term); }
        if (req.query.session)    { w2.push("session = ?");    p2.push(req.query.session); }
        if (w2.length) sql += " WHERE " + w2.join(" AND ");
        sql += " ORDER BY paid_at DESC LIMIT 200";
        connection.query(sql, p2, (err2, rows2) => {
            if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
            res.json(rows2);
        });
    });
});

app.get("/fee-balance", requireLogin, requireAdmin, (req, res) => {
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();
    const className = (req.query.class_name || "").trim();
    if (!term || !session) return res.status(400).json({ message: "term and session are required." });
    let sql = `
        SELECT s.student_id, s.full_name, s.class_name,
               COALESCE(fs.amount, 0) AS fee,
               COALESCE(p.paid, 0) AS paid,
               (COALESCE(fs.amount, 0) - COALESCE(p.paid, 0)) AS balance
        FROM students s
        LEFT JOIN fee_structure fs
               ON fs.class_name = s.class_name AND fs.term = ? AND fs.session = ?
        LEFT JOIN (SELECT student_id, SUM(amount) AS paid
                     FROM fee_payments WHERE term = ? AND session = ?
                    GROUP BY student_id) p ON p.student_id = s.student_id
    `;
    const params = [term, session, term, session];
    if (className) { sql += " WHERE s.class_name = ?"; params.push(className); }
    sql += " ORDER BY s.class_name, s.full_name";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.get("/finance-summary", requireLogin, requireAdmin, (req, res) => {
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();
    if (!term || !session) return res.status(400).json({ message: "term and session are required." });
    // CHANGED (pack 15): expected = all fee TYPES x class sizes (v2 table).
    const expectedSql = `
        SELECT COALESCE(SUM(fs.amount * c.cnt), 0) AS expected
        FROM fee_structure2 fs
        JOIN (SELECT class_name, COUNT(*) AS cnt FROM students GROUP BY class_name) c
          ON c.class_name = fs.class_name
        WHERE fs.term = ? AND fs.session = ?
    `;
    connection.query(expectedSql, [term, session], (err, expRows) => {
        if (err) {
            console.log(err);
            return res.json({ expected: 0, received: 0, payments_count: 0, outstanding: 0, expenses_total: 0, expenses_count: 0, term, session, notice: "No finance data recorded yet" });
        }
        connection.query(
            "SELECT COALESCE(SUM(amount),0) AS received, COUNT(*) AS cnt FROM fee_payments WHERE term = ? AND session = ?",
            [term, session],
            (err2, payRows) => {
                if (err2) {
                    console.log(err2);
                    return res.json({ expected: 0, received: 0, payments_count: 0, outstanding: 0, expenses_total: 0, expenses_count: 0, term, session });
                }
                connection.query(
                    "SELECT COALESCE(SUM(amount),0) AS total, COUNT(*) AS cnt FROM expenses",
                    (err3, costRows) => {
                        if (err3) {
                            console.log(err3);
                            return res.json({ expected: 0, received: 0, payments_count: 0, outstanding: 0, expenses_total: 0, expenses_count: 0, term, session });
                        }
                        const expected = (expRows && expRows[0] && Number(expRows[0].expected)) || 0;
                        const received = (payRows && payRows[0] && Number(payRows[0].received)) || 0;
                        const payCnt = (payRows && payRows[0] && Number(payRows[0].cnt)) || 0;
                        const costTotal = (costRows && costRows[0] && Number(costRows[0].total)) || 0;
                        const costCnt = (costRows && costRows[0] && Number(costRows[0].cnt)) || 0;
                        res.json({
                            expected,
                            received,
                            payments_count: payCnt,
                            outstanding: expected - received,
                            expenses_total: costTotal,
                            expenses_count: costCnt,
                            term, session
                        });
                    }
                );
            }
        );
    });
});

app.get("/expenses", requireLogin, requireAdmin, (req, res) => {
    connection.query(
        "SELECT id, title, category, amount, spent_on, note, created_at FROM expenses ORDER BY spent_on DESC, id DESC LIMIT 300",
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

app.post("/expenses", requireLogin, requireAdmin, (req, res) => {
    const title = (req.body.title || "").trim();
    const category = (req.body.category || "").trim();
    const amount = Number(req.body.amount);
    const spentOn = (req.body.spent_on || "").trim() || null;
    const note = (req.body.note || "").trim();
    if (!title || !(amount > 0)) {
        return res.status(400).json({ message: "A title and an amount above 0 are required." });
    }
    connection.query(
        "INSERT INTO expenses (title, category, amount, spent_on, note) VALUES (?,?,?,?,?)",
        [title, category, amount, spentOn, note],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Expense recorded", amount });
        }
    );
});

app.delete("/expense/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM expenses WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Expense deleted" });
    });
});


/* =====================================================================
   NEW (pack 14) - payment delete, attendance "already taken" summary,
   school settings, sessions, user management. All additive.
   ===================================================================== */

/* ---------- Delete a fee payment (owner request) -------------------- */
app.delete("/fee-payment/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM fee_payments WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Payment deleted" });
    });
});

/* GET /attendance/summary (the "already taken for this date" banner) MOVED
   (pack 108) into the student-attendance section above, where it adapts to
   the columns that exist and reports "not taken yet" instead of a 500 when
   the attendance table is missing or half-built. */


/* ---------- School settings ------------------------------------------
   SECURITY (split): the public GET below returns ONLY the harmless
   branding/contact fields the login and landing pages need (name, motto,
   address, phones, email, term info). It deliberately does NOT do a
   SELECT * any more, because school_settings also holds bank_name,
   account_name, account_number and pay_instructions - financial data
   that must not be handed to anonymous visitors. The full row
   (including those bank columns) is served by /school-settings/full,
   which is behind requireLogin. Bank details for the parent portal are
   served separately by /bank-accounts (gated for portal users). */
const PUBLIC_SCHOOL_SETTINGS_COLUMNS =
    "id, school_name, school_name_ar, motto, motto_ar, address, " +
    "phone1, phone2, email, result_notice, term_begins, term_ends, " +
    "next_term_begins, due_day, current_term";

app.get("/school-settings", (req, res) => {
    connection.query(
        "SELECT " + PUBLIC_SCHOOL_SETTINGS_COLUMNS + " FROM school_settings WHERE id = 1",
        (err, rows) => {
            if (err && err.code === "ER_BAD_FIELD_ERROR") {
                // Older schema without the v2 columns (due_day/current_term) -
                // fall back to the guaranteed base branding/contact columns.
                return connection.query(
                    "SELECT id, school_name, school_name_ar, motto, motto_ar, address, phone1, phone2, email FROM school_settings WHERE id = 1",
                    (err2, rows2) => {
                        if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                        res.json(rows2 && rows2.length ? rows2[0] : {});
                    }
                );
            }
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows && rows.length ? rows[0] : {});
        }
    );
});

// Full settings row INCLUDING bank/payment details - staff only.
app.get("/school-settings/full", requireLogin, (req, res) => {
    connection.query("SELECT * FROM school_settings WHERE id = 1", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows && rows.length ? rows[0] : {});
    });
});

app.post("/school-settings", requireLogin, requireAdmin, (req, res) => {
    const f = k => String(req.body[k] == null ? "" : req.body[k]).trim();
    // CHANGED (pack 15): also stores due_day (late-fee alert day of the
    // month) and current_term (used by the dashboard alert). Legacy
    // fallback keeps the pack-14 columns if the v2 columns are absent.
    const dueDay = parseInt(req.body.due_day, 10);
    const currentTerm = f("current_term");
    const fullSql = `INSERT INTO school_settings
         (id, school_name, school_name_ar, motto, motto_ar, address, phone1, phone2, email, due_day, current_term)
         VALUES (1,?,?,?,?,?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE
           school_name = VALUES(school_name), school_name_ar = VALUES(school_name_ar),
           motto = VALUES(motto), motto_ar = VALUES(motto_ar), address = VALUES(address),
           phone1 = VALUES(phone1), phone2 = VALUES(phone2), email = VALUES(email),
           due_day = VALUES(due_day), current_term = VALUES(current_term)`;
    const fullVals = [f("school_name"), f("school_name_ar"), f("motto"), f("motto_ar"), f("address"), f("phone1"), f("phone2"), f("email"),
                      (dueDay >= 1 && dueDay <= 28) ? dueDay : 10, currentTerm || "1st Term"];
    connection.query(fullSql, fullVals, (err) => {
        if (err && err.code === "ER_BAD_FIELD_ERROR") {
            return connection.query(
                `INSERT INTO school_settings
                 (id, school_name, school_name_ar, motto, motto_ar, address, phone1, phone2, email)
                 VALUES (1,?,?,?,?,?,?,?,?,?)
                 ON DUPLICATE KEY UPDATE
                   school_name = VALUES(school_name), school_name_ar = VALUES(school_name_ar),
                   motto = VALUES(motto), motto_ar = VALUES(motto_ar), address = VALUES(address),
                   phone1 = VALUES(phone1), phone2 = VALUES(phone2), email = VALUES(email)`,
                [f("school_name"), f("school_name_ar"), f("motto"), f("motto_ar"), f("address"), f("phone1"), f("phone2"), f("email")],
                (err2) => {
                    if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                    res.json({ message: "School settings saved" });
                }
            );
        }
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "School settings saved" });
    });
});

/* ---------- Academic sessions (admin creates) ------------------------ */
app.get("/sessions", requireLogin, (req, res) => {
    connection.query("SELECT session, is_current FROM sessions ORDER BY session", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/session", requireLogin, requireAdmin, (req, res) => {
    const session = (req.body.session || "").trim();
    const makeCurrent = Number(req.body.is_current) ? 1 : 0;
    if (!session) return res.status(400).json({ message: "Session is required (e.g. 2027/2028)." });
    const insert = () => {
        connection.query(
            "INSERT INTO sessions (session, is_current) VALUES (?, ?) ON DUPLICATE KEY UPDATE is_current = IF(?, 1, is_current)",
            [session, makeCurrent, makeCurrent],
            (err) => {
                if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
                res.json({ message: "Session saved", session, is_current: makeCurrent });
            }
        );
    };
    if (makeCurrent) {
        connection.query("UPDATE sessions SET is_current = 0", (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            insert();
        });
    } else {
        insert();
    }
});

/* ---------- User management (admin creates users of ANY role) -------
   "Let admin be able to create user either admin or teacher and any
   other positions." New roles act like teacher-level everywhere
   (only 'admin' gets admin powers), until you ask otherwise. */
app.get("/users", requireLogin, requireAdmin, (req, res) => {
    connection.query("SELECT id, username, role FROM users ORDER BY username", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/create-user", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const username = (req.body.username || "").trim();
    const password = req.body.password || "";
    const role = (req.body.role || "teacher").trim().toLowerCase().replace(/[^a-z_]/g, "") || "teacher";
    if (!username || password.length < 4) {
        return res.status(400).json({ message: "Username and a password of at least 4 characters are required." });
    }
    connection.query("SELECT id FROM users WHERE username = ?", [username], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (rows.length) return res.status(409).json({ message: "That username already exists." });
        bcrypt.hash(password, 10, (herr, hash) => {
            if (herr) { console.log(herr); return res.status(500).json({ message: "Error securing password" }); }
            connection.query("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
                [username, hash, role],
                (err2) => {
                    if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                    res.json({ message: "User created", username, role });
                });
        });
    });
});

app.post("/reset-user-password", requireLogin, requireAdmin, (req, res) => {
    const userId = Number(req.body.user_id);
    const password = req.body.password || "";
    if (!userId || password.length < 4) {
        return res.status(400).json({ message: "User and a password of at least 4 characters are required." });
    }
    bcrypt.hash(password, 10, (herr, hash) => {
        if (herr) { console.log(herr); return res.status(500).json({ message: "Error securing password" }); }
        connection.query("UPDATE users SET password_hash = ? WHERE id = ?", [hash, userId], (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Password reset" });
        });
    });
});

app.delete("/user/:id", requireLogin, requireAdmin, (req, res) => {
    const userId = Number(req.params.id);
    if (userId === req.session.userId) {
        return res.status(400).json({ message: "You cannot delete your own account." });
    }
    connection.query("DELETE FROM users WHERE id = ?", [userId], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "User deleted" });
    });
});


/* =====================================================================
   NEW (staff profiles & payroll) - staff directory with qualifications,
   salary and bank details, plus a payroll ledger of monthly salary
   payments. Fully additive; uses the new `staff` and `payroll` tables
   created in the startup block above.
   ===================================================================== */

/* ---------- list staff (with last-paid + total paid this term) ------- */
app.get("/staff", requireLogin, requireAdmin, (req, res) => {
    connection.query(
        `SELECT s.*,
                (SELECT MAX(p.pay_month) FROM payroll p WHERE p.staff_id = s.id) AS last_pay_month,
                (SELECT SUM(p.amount) FROM payroll p WHERE p.staff_id = s.id) AS total_paid
         FROM staff s
         ORDER BY s.status ASC, s.full_name ASC`,
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(Array.isArray(rows) ? rows : []);
        }
    );
});

/* ---------- create a staff member ---------- */
app.post("/staff", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const fullName = (req.body.full_name || "").trim();
    if (!fullName) return res.status(400).json({ message: "Staff full name is required." });
    const subject      = (req.body.subject || "").trim();
    const qualification = (req.body.qualification || "").trim();
    const phone        = (req.body.phone || "").trim();
    const salary       = Number(req.body.salary) || 0;
    const bankName     = (req.body.bank_name || "").trim();
    const accountName  = (req.body.account_name || "").trim();
    const accountNumber = (req.body.account_number || "").trim();
    const status       = (req.body.status || "active").trim().toLowerCase();
    connection.query(
        `INSERT INTO staff (full_name, subject, qualification, phone, salary, bank_name, account_name, account_number, status)
         VALUES (?,?,?,?,?,?,?,?,?)`,
        [fullName, subject, qualification, phone, salary, bankName, accountName, accountNumber, status === "inactive" ? "inactive" : "active"],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Staff member added", id: result.insertId });
        }
    );
});

/* ---------- update a staff member ---------- */
app.put("/staff/:id", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const id = Number(req.params.id);
    const fullName = (req.body.full_name || "").trim();
    if (!id || !fullName) return res.status(400).json({ message: "Staff full name is required." });
    const subject      = (req.body.subject || "").trim();
    const qualification = (req.body.qualification || "").trim();
    const phone        = (req.body.phone || "").trim();
    const salary       = Number(req.body.salary) || 0;
    const bankName     = (req.body.bank_name || "").trim();
    const accountName  = (req.body.account_name || "").trim();
    const accountNumber = (req.body.account_number || "").trim();
    const status       = (req.body.status || "active").trim().toLowerCase();
    connection.query(
        `UPDATE staff SET full_name=?, subject=?, qualification=?, phone=?, salary=?, bank_name=?, account_name=?, account_number=?, status=? WHERE id=?`,
        [fullName, subject, qualification, phone, salary, bankName, accountName, accountNumber, status === "inactive" ? "inactive" : "active", id],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Staff member updated" });
        }
    );
});

/* ---------- delete a staff member (and their payroll history) -------- */
app.delete("/staff/:id", requireLogin, requireAdmin, (req, res) => {
    const id = Number(req.params.id);
    connection.query("DELETE FROM staff WHERE id = ?", [id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        connection.query("DELETE FROM payroll WHERE staff_id = ?", [id], () => {});
        res.json({ message: "Staff member deleted" });
    });
});

/* ---------- payroll ledger (optionally filtered by month) ------------ */
app.get("/payroll", requireLogin, requireAdmin, (req, res) => {
    const month = (req.query.month || "").trim();
    let sql = `SELECT p.*, s.full_name, s.salary, s.subject
               FROM payroll p
               JOIN staff s ON s.id = p.staff_id`;
    const params = [];
    if (month) { sql += " WHERE p.pay_month = ?"; params.push(month); }
    sql += " ORDER BY p.paid_at DESC LIMIT 500";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(Array.isArray(rows) ? rows : []);
    });
});

/* ---------- record a salary payment ---------- */
app.post("/payroll", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const staffId = Number(req.body.staff_id);
    const month   = (req.body.pay_month || "").trim();
    const amount  = Number(req.body.amount);
    if (!staffId || !month || !(amount > 0)) {
        return res.status(400).json({ message: "staff_id, pay_month and an amount above 0 are required." });
    }
    const method = (req.body.method || "").trim();
    const note   = (req.body.note || "").trim();
    connection.query(
        `INSERT INTO payroll (staff_id, pay_month, amount, method, note, paid_by)
         VALUES (?,?,?,?,?,?)`,
        [staffId, month, amount, method, note, req.session.username || null],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Salary payment recorded", id: result.insertId });
        }
    );
});

/* ---------- delete a payroll entry ---------- */
app.delete("/payroll/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM payroll WHERE id = ?", [Number(req.params.id)], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Payroll entry deleted" });
    });
});


/* =====================================================================
   NEW (feature: Third Term Results from the internal grade workbook)
   ---------------------------------------------------------------------
   POST /third-term-upload
   Accepts the school's internal grade-tracking workbook (.xlsx): one
   sheet per class, teacher/class in rows 1-3, then per subject the
   F / S / N / A (CA sub-scores /10), a 40-total column, a 60-exam
   column and the ف1 / ف2 / ف3 term scores, then student rows
   (S/N | Adm/Num | Student Name | scores). PARSE-ONLY: nothing is
   written to the database. The frontend renders tables/PDFs from the
   returned JSON and calls /third-term-export-excel for the workbook.

   POST /third-term-export-excel
   Receives the parsed classes (with positions/percentages already
   computed by the page) and returns one consolidated .xlsx with a
   Summary tab + one tab per class.
   ===================================================================== */

/* FIX: use the dedicated permissive receiver, NOT the shared uploadExcel.
   The shared instance whitelisted only a few MIME types (and 5 MB), so
   phones/browsers that send .xlsx as application/octet-stream (or with an
   empty MIME type) were rejected before the route ever ran — the page then
   showed "Network error while parsing the workbook." */
app.post("/third-term-upload", requireLogin, writeRateLimit, receiveThirdTermWorkbook, (req, res) => {
    if (!req.file) return res.status(400).json({ message: "No file uploaded." });

    let parsed;
    try {
        parsed = thirdTermParser.parseWorkbook(req.file.buffer);
    } catch (err) {
        console.log(err);
        return res.status(400).json({
            message: "Could not read the uploaded file. Make sure it is a valid .xlsx / .xls workbook with one sheet per class."
        });
    }

    res.json({
        fileName: req.file.originalname || "workbook.xlsx",
        sheetCount: parsed.classes.length + parsed.errors.length,
        classes: parsed.classes,
        errors: parsed.errors
    });
});

app.post("/third-term-export-excel", requireLogin, writeRateLimit, (req, res) => {
    const classes = Array.isArray(req.body && req.body.classes) ? req.body.classes : [];
    if (!classes.length) {
        return res.status(400).json({ message: "No result data to export. Upload and parse the workbook first." });
    }

    /* Term / session dates typed by the admin on the page - printed on
       every exported sheet. */
    const rawMeta = (req.body && req.body.meta) || {};
    const meta = {
        termEndsOn: String(rawMeta.termEndsOn || "").slice(0, 120),
        newSessionStarts: String(rawMeta.newSessionStarts || "").slice(0, 120)
    };

    let buffer;
    try {
        buffer = thirdTermParser.buildThirdTermWorkbook(classes, meta);
    } catch (err) {
        console.log(err);
        return res.status(500).json({ message: "Could not build the Excel export." });
    }

    const fileName = "third-term-results-" + new Date().toISOString().slice(0, 10) + ".xlsx";
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(fileName)}`);
    res.send(buffer);
});


/* =====================================================================
   NEW (feature 3 - bulk result import): upload an Excel file to import
   scores for a whole class for a given term/session. Uses the same
   uploadExcel multer + XLSX parsing as /bulk-add-students. Total and
   grade are auto-computed when left blank.
   ===================================================================== */

function gradeForTotal(total) {
    const t = Number(total) || 0;
    if (t >= 70) return "A";
    if (t >= 60) return "B";
    if (t >= 50) return "C";
    if (t >= 45) return "D";
    if (t >= 40) return "E";
    return "F";
}

function numOr(v) {
    const n = Number(v);
    return isNaN(n) ? 0 : n;
}

app.post("/bulk-import-results", requireLogin, writeRateLimit, uploadExcel.single("file"), (req, res) => {
    if (!req.file) return res.status(400).json({ message: "No file uploaded." });

    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    const defaultClass = (req.body.class_name || "").trim();
    if (!term || !session) return res.status(400).json({ message: "Term and session are required." });

    let rows;
    try {
        const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
    } catch (err) {
        console.log(err);
        return res.status(400).json({ message: "Could not read the uploaded file. Make sure it's a valid .xlsx, .xls, or .csv file." });
    }
    if (!rows.length) return res.status(400).json({ message: "The file has no result rows in it." });

    connection.query("SELECT student_id, full_name, class_name FROM students", (err, students) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error while loading students." }); }
        const stuMap = {};
        (students || []).forEach(function (s) { stuMap[s.student_id] = s; });

        const results = { inserted: 0, errors: [] };
        let index = 0;

        function processNext() {
            if (index >= rows.length) {
                return res.json({
                    message: results.inserted + " of " + rows.length + " result row(s) imported successfully.",
                    inserted: results.inserted,
                    total: rows.length,
                    errors: results.errors
                });
            }
            const row = rows[index];
            const rowNum = index + 2;
            index++;

            const studentId = String(row["Student ID"] || "").trim();
            const subject = String(row["Subject"] || "").trim();
            if (!studentId || !subject) {
                results.errors.push("Row " + rowNum + ": Student ID and Subject are required.");
                return processNext();
            }

            const stu = stuMap[studentId];
            const studentName = stu ? stu.full_name : studentId;
            const className = (row["Class"] ? String(row["Class"]).trim() : "") || (stu ? stu.class_name : "") || defaultClass;

            const firstTest = numOr(row["First Test"]);
            const secondTest = numOr(row["Second Test"]);
            const noteScore = numOr(row["Note"]);
            const attendanceScore = numOr(row["Attendance"]);
            const examScore = numOr(row["Exam"]);

            const hasCa = String(row["CA"] || "").trim() !== "";
            const caScore = hasCa ? numOr(row["CA"]) : (firstTest + secondTest + noteScore + attendanceScore);

            const hasTotal = String(row["Total"] || "").trim() !== "";
            const total = hasTotal ? numOr(row["Total"]) : (caScore + examScore);

            const gradeRaw = String(row["Grade"] || "").trim();
            const grade = gradeRaw || gradeForTotal(total);

            connection.query(
                `INSERT INTO results
                    (student_id, student_name, class_name, term, session, subject,
                     first_test, second_test, note_score, attendance_score,
                     ca_score, exam_score, total, grade)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
                [studentId, studentName, className, term, session, subject,
                 firstTest, secondTest, noteScore, attendanceScore,
                 caScore, examScore, total, grade],
                (err2) => {
                    if (err2) {
                        console.log(err2);
                        results.errors.push("Row " + rowNum + ": Database error saving this row.");
                    } else {
                        results.inserted++;
                    }
                    processNext();
                }
            );
        }

        processNext();
    });
});


/* =====================================================================
   NEW (feature 4 - discipline records): log warnings, suspensions and
   commendations per student. Staff log them; parents see their child's
   records in the portal. Uses the new `discipline` table.
   ===================================================================== */

app.get("/discipline", requireLogin, (req, res) => {
    const sid = (req.query.student_id || "").trim();
    let sql = "SELECT d.*, s.full_name, s.class_name FROM discipline d LEFT JOIN students s ON s.student_id = d.student_id";
    const params = [];
    if (sid) { sql += " WHERE d.student_id = ?"; params.push(sid); }
    sql += " ORDER BY d.record_date DESC, d.id DESC LIMIT 500";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(Array.isArray(rows) ? rows : []);
    });
});

app.post("/discipline", requireLogin, writeRateLimit, (req, res) => {
    const studentId = (req.body.student_id || "").trim();
    const type = (req.body.type || "warning").trim().toLowerCase();
    const title = (req.body.title || "").trim();
    const description = (req.body.description || "").trim();
    const recordDate = (req.body.record_date || "").trim() || new Date().toISOString().slice(0, 10);
    if (!studentId || !description) {
        return res.status(400).json({ message: "Student and a description are required." });
    }
    if (["warning", "suspension", "commendation"].indexOf(type) === -1) {
        return res.status(400).json({ message: "Type must be warning, suspension or commendation." });
    }
    connection.query(
        `INSERT INTO discipline (student_id, type, title, description, record_date, recorded_by)
         VALUES (?,?,?,?,?,?)`,
        [studentId, type, title, description, recordDate, req.session.username || null],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Record saved", id: result.insertId });
        }
    );
});

app.delete("/discipline/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM discipline WHERE id = ?", [Number(req.params.id)], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Record deleted" });
    });
});

/* Portal: parents/students see their child's discipline record (read-only). */
app.get("/portal/discipline", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query(
        `SELECT type, title, description, record_date FROM discipline
         WHERE student_id = ? ORDER BY record_date DESC LIMIT 100`,
        [sid],
        (err, rows) => {
            if (err) { console.log(err); return res.json([]); }
            res.json(Array.isArray(rows) ? rows : []);
        }
    );
});


/* =====================================================================
   NEW (feature 5 - lesson planner): teachers plan lessons per subject
   per week; visible to admin. Uses the new `lesson_plans` table.
   ===================================================================== */

app.get("/lesson-plans", requireLogin, (req, res) => {
    const teacher = (req.query.teacher || "").trim();
    let sql = "SELECT * FROM lesson_plans";
    const params = [];
    if (teacher) { sql += " WHERE teacher = ?"; params.push(teacher); }
    sql += " ORDER BY week_start DESC, class_name ASC, subject ASC LIMIT 500";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(Array.isArray(rows) ? rows : []);
    });
});

app.post("/lesson-plans", requireLogin, writeRateLimit, (req, res) => {
    const subject = (req.body.subject || "").trim();
    const className = (req.body.class_name || "").trim();
    const weekStart = (req.body.week_start || "").trim();
    const topic = (req.body.topic || "").trim();
    if (!subject || !weekStart || !topic) {
        return res.status(400).json({ message: "Subject, week and topic are required." });
    }
    const teacher = (req.body.teacher || "").trim() || req.session.username || "";
    const objectives = (req.body.objectives || "").trim();
    const activities = (req.body.activities || "").trim();
    const notes = (req.body.notes || "").trim();
    connection.query(
        `INSERT INTO lesson_plans (teacher, subject, class_name, week_start, topic, objectives, activities, notes)
         VALUES (?,?,?,?,?,?,?,?)`,
        [teacher, subject, className, weekStart, topic, objectives, activities, notes],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Lesson plan saved", id: result.insertId });
        }
    );
});

app.delete("/lesson-plans/:id", requireLogin, (req, res) => {
    const id = Number(req.params.id);
    const username = req.session.username || "";
    const isAdmin = req.session.role === "admin";
    const where = isAdmin ? "id = ?" : "id = ? AND teacher = ?";
    const params = isAdmin ? [id] : [id, username];
    connection.query("DELETE FROM lesson_plans WHERE " + where, params, (err, result) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (result.affectedRows === 0) {
            return res.status(403).json({ message: "You can only delete your own lesson plans." });
        }
        res.json({ message: "Lesson plan deleted" });
    });
});


/* =====================================================================
   NEW (feature 6 - online quizzes): staff create quizzes (title, class,
   subject, questions with 4 options + correct answer); students answer
   them from the parent portal and get an instant auto-graded score.
   ===================================================================== */

app.get("/quizzes", requireLogin, (req, res) => {
    connection.query(
        "SELECT id, title, class_name, subject, questions, due_date, created_by, created_at FROM quizzes ORDER BY created_at DESC LIMIT 200",
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(Array.isArray(rows) ? rows : []);
        }
    );
});

app.post("/quizzes", requireLogin, writeRateLimit, (req, res) => {
    const title = (req.body.title || "").trim();
    const class_name = (req.body.class_name || "").trim();
    const subject = (req.body.subject || "").trim();
    const due_date = (req.body.due_date || "").trim() || null;
    let questions = req.body.questions;
    if (Array.isArray(questions)) questions = JSON.stringify(questions);
    if (!title || typeof questions !== "string") {
        return res.status(400).json({ message: "Title and questions are required." });
    }
    connection.query(
        `INSERT INTO quizzes (title, class_name, subject, questions, due_date, created_by)
         VALUES (?,?,?,?,?,?)`,
        [title, class_name, subject, questions, due_date, req.session.username || null],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Quiz saved", id: result.insertId });
        }
    );
});

app.delete("/quizzes/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM quizzes WHERE id = ?", [Number(req.params.id)], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        connection.query("DELETE FROM quiz_attempts WHERE quiz_id = ?", [Number(req.params.id)], () => {});
        res.json({ message: "Quiz deleted" });
    });
});

/* attempts for a quiz (staff review) */
app.get("/quizzes/:id/attempts", requireLogin, (req, res) => {
    connection.query(
        `SELECT a.id, a.student_id, a.student_name, a.score, a.total, a.created_at
         FROM quiz_attempts a WHERE a.quiz_id = ? ORDER BY a.created_at DESC LIMIT 500`,
        [Number(req.params.id)],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(Array.isArray(rows) ? rows : []);
        }
    );
});

/* -------- portal side -------- */

function safeQuizQuestions(quiz) {
    /* strip the answer index before sending to a student */
    let qs = [];
    try { qs = JSON.parse(quiz.questions || "[]"); } catch (e) { qs = []; }
    if (!Array.isArray(qs)) qs = [];
    return qs.map(function (q) {
        return { q: q.q, options: q.options || [] };
    });
}

app.get("/portal/quizzes", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query("SELECT class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err || !rows.length) return res.json([]);
        const cls = rows[0].class_name || "";
        const sql = cls
            ? "SELECT id, title, class_name, subject, due_date, created_at FROM quizzes WHERE class_name = ? OR class_name = '' ORDER BY created_at DESC LIMIT 50"
            : "SELECT id, title, class_name, subject, due_date, created_at FROM quizzes ORDER BY created_at DESC LIMIT 50";
        connection.query(sql, cls ? [cls] : [], (e2, quizzes) => {
            if (e2) { console.log(e2); return res.json([]); }
            connection.query("SELECT quiz_id, score, total, created_at FROM quiz_attempts WHERE student_id = ?", [sid], (e3, attempts) => {
                if (e3) { console.log(e3); return res.json([]); }
                const done = {};
                (attempts || []).forEach(function (a) {
                    if (!done[a.quiz_id] || a.score > done[a.quiz_id]) done[a.quiz_id] = a.score;
                });
                res.json((quizzes || []).map(function (q) {
                    return { id: q.id, title: q.title, subject: q.subject, class_name: q.class_name, due_date: q.due_date, best: done[q.id] !== undefined ? done[q.id] : null };
                }));
            });
        });
    });
});

app.get("/portal/quiz/:id", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query("SELECT * FROM quizzes WHERE id = ? LIMIT 1", [Number(req.params.id)], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "Quiz not found" });
        res.json({ id: rows[0].id, title: rows[0].title, subject: rows[0].subject, due_date: rows[0].due_date, questions: safeQuizQuestions(rows[0]) });
    });
});

app.post("/portal/quiz/:id/submit", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    const quizId = Number(req.params.id);
    const answers = req.body && req.body.answers; // { "0": index, "1": index }
    connection.query("SELECT * FROM quizzes WHERE id = ? LIMIT 1", [quizId], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "Quiz not found" });
        let qs = [];
        try { qs = JSON.parse(rows[0].questions || "[]"); } catch (e) { qs = []; }
        if (!Array.isArray(qs) || !qs.length) return res.status(400).json({ message: "This quiz has no questions." });
        let score = 0;
        qs.forEach(function (q, i) {
            const got = answers ? answers[String(i)] : null;
            if (got != null && String(got) === String(q.answer)) score++;
        });
        connection.query("SELECT full_name FROM students WHERE student_id = ? LIMIT 1", [sid], (e2, stu) => {
            const name = (stu && stu.length && stu[0].full_name) || sid;
            connection.query(
                "INSERT INTO quiz_attempts (quiz_id, student_id, student_name, score, total, answers) VALUES (?,?,?,?,?,?)",
                [quizId, sid, name, score, qs.length, JSON.stringify(answers || {})],
                (e3) => {
                    if (e3) { console.log(e3); return res.status(500).json({ message: "Database error" }); }
                    res.json({ message: "Submitted!", score: score, total: qs.length });
                }
            );
        });
    });
});


/* =====================================================================
   NEW (feature 7 - WhatsApp/SMS notification): a bulk parent-notification
   tool. Picks an audience (all active students / one class / debtors),
   fires a phone push to every parent AND returns ready-made WhatsApp +
   SMS deep links so the school can forward the message manually (no paid
   gateway needed). Also adds WhatsApp links to the debtors board.
   ===================================================================== */

app.post("/bulk-notify", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const audience = (req.body.audience || "all").trim(); // all | class | debtors
    const className = (req.body.class_name || "").trim();
    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    const message = (req.body.message || "").trim();
    if (!message) return res.status(400).json({ message: "Type a message first." });

    function finish(students) {
        const uniq = Array.from(new Set((students || []).map(s => s.student_id).filter(Boolean)));
        amsPushSend("portal", uniq, {
            title: "\u{1F4E2} Message from school",
            body: message.slice(0, 160),
            url: "/portal.html",
            tag: "bulk-" + Date.now()
        });
        const links = (students || []).map(function (s) {
            const phone = (s.parent_phone || "").replace(/[^\d]/g, "");
            return {
                student_id: s.student_id,
                full_name: s.full_name,
                parent_phone: s.parent_phone || "",
                whatsapp: phone ? "https://wa.me/" + phone + "?text=" + encodeURIComponent(message) : null,
                sms: phone ? "sms:" + phone + "?body=" + encodeURIComponent(message) : null
            };
        });
        res.json({ message: "Notification sent to " + uniq.length + " parent(s).", count: uniq.length, links: links });
    }

    if (audience === "class") {
        if (!className) return res.status(400).json({ message: "Pick a class." });
        connection.query("SELECT student_id, full_name, parent_phone FROM students WHERE class_name = ? AND (status IS NULL OR status = 'active')", [className], (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            finish(rows || []);
        });
    } else if (audience === "debtors") {
        if (!term || !session) return res.status(400).json({ message: "Term and session are required for debtors." });
        amsFeeBalanceRows(term, session, className, null, (err, rows) => {
            if (err || !rows) return res.json({ message: "No debtors found.", count: 0, links: [] });
            const debtors = amsDebtorsAggregate(rows).filter(c => c.owed > 0);
            const ids = debtors.map(c => c.student_id);
            if (!ids.length) return res.json({ message: "No debtors found.", count: 0, links: [] });
            connection.query("SELECT student_id, full_name, parent_phone FROM students WHERE student_id IN (" + ids.map(() => "?").join(",") + ")", ids, (e2, rows2) => {
                if (e2) { console.log(e2); return res.status(500).json({ message: "Database error" }); }
                finish(rows2 || []);
            });
        });
    } else {
        connection.query("SELECT student_id, full_name, parent_phone FROM students WHERE (status IS NULL OR status = 'active') ORDER BY class_name, full_name", (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            finish(rows || []);
        });
    }
});


/* =====================================================================
   NEW (feature 8 - parent-teacher appointments): parents book a meeting
   from the portal; staff review, approve or reject it.
   ===================================================================== */

app.get("/portal/appointments", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query("SELECT * FROM appointments WHERE student_id = ? ORDER BY created_at DESC LIMIT 30", [sid], (err, rows) => {
        if (err) { console.log(err); return res.json([]); }
        res.json(rows);
    });
});

app.post("/portal/appointments", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    const requested_date = (req.body.requested_date || "").trim();
    const requested_time = (req.body.requested_time || "").trim();
    const reason = (req.body.reason || "").trim();
    if (!requested_date || !reason) return res.status(400).json({ message: "Date and reason are required." });
    connection.query("SELECT full_name, class_name, parent_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err || !rows.length) return res.status(404).json({ message: "Student not found." });
        connection.query(
            "INSERT INTO appointments (student_id, student_name, class_name, parent_name, requested_date, requested_time, reason) VALUES (?,?,?,?,?,?,?)",
            [sid, rows[0].full_name, rows[0].class_name, rows[0].parent_name || "", requested_date, requested_time, reason],
            (e2) => {
                if (e2) { console.log(e2); return res.status(500).json({ message: "Database error" }); }
                res.json({ message: "Appointment requested. The school will confirm it." });
            }
        );
    });
});

app.get("/api/appointments", requireLogin, (req, res) => {
    const status = req.query.status;
    const sql = status
        ? "SELECT * FROM appointments WHERE status = ? ORDER BY created_at DESC LIMIT 200"
        : "SELECT * FROM appointments ORDER BY created_at DESC LIMIT 200";
    connection.query(sql, status ? [status] : [], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/api/appointments/:id/status", requireLogin, writeRateLimit, (req, res) => {
    const status = req.body.status;
    const note = (req.body.admin_note || "").trim() || null;
    if (["approved", "rejected", "pending"].indexOf(status) === -1) {
        return res.status(400).json({ message: "Invalid status." });
    }
    connection.query("UPDATE appointments SET status = ?, admin_note = ? WHERE id = ?", [status, note, Number(req.params.id)], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Updated." });
    });
});

app.delete("/api/appointments/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM appointments WHERE id = ?", [Number(req.params.id)], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Appointment deleted" });
    });
});


/* =====================================================================
   NEW (pack 15) - fee types, structure v2, parent payment proofs,
   bank accounts, portal fees, madrasah calendar. All additive.
   ===================================================================== */

/* ---------- Fee TYPES (School Fee / Developmental / Exam / custom) -- */
app.get("/fee-types", requireLogin, (req, res) => {
    connection.query("SELECT id, name FROM fee_types ORDER BY id", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/fee-type", requireLogin, requireAdmin, (req, res) => {
    const name = (req.body.name || "").trim();
    if (!name) return res.status(400).json({ message: "Fee type name is required." });
    connection.query("INSERT IGNORE INTO fee_types (name) VALUES (?)", [name], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Fee type saved", name });
    });
});

app.delete("/fee-type/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM fee_types WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Fee type removed" });
    });
});

/* ---------- Fee STRUCTURE v2 (per fee type per class) --------------- */
app.get("/fee-structure2", requireLogin, requireAdmin, (req, res) => {
    let sql = "SELECT fee_type, class_name, term, session, amount FROM fee_structure2";
    const params = [], wh = [];
    if (req.query.term)     { wh.push("term = ?");      params.push(req.query.term); }
    if (req.query.session)  { wh.push("session = ?");   params.push(req.query.session); }
    if (req.query.fee_type) { wh.push("fee_type = ?");  params.push(req.query.fee_type); }
    if (wh.length) sql += " WHERE " + wh.join(" AND ");
    sql += " ORDER BY fee_type, class_name";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/fee-structure2", requireLogin, requireAdmin, (req, res) => {
    const feeType = (req.body.fee_type || "School Fee").trim() || "School Fee";
    const className = (req.body.class_name || "").trim();
    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    const amount = Number(req.body.amount);
    if (!className || !term || !session || !(amount >= 0)) {
        return res.status(400).json({ message: "fee_type, class_name, term, session and a valid amount are required." });
    }
    connection.query(
        `INSERT INTO fee_structure2 (fee_type, class_name, term, session, amount)
         VALUES (?,?,?,?,?)
         ON DUPLICATE KEY UPDATE amount = VALUES(amount)`,
        [feeType, className, term, session, amount],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Fee saved", fee_type: feeType, class_name: className, amount });
        }
    );
});

/* NEW (pack 28 - finance tidy-up): remove ONE charge (e.g. a mistaken
   "Uniform Fee") from ONE class for a term/session. The other classes and
   fee types are untouched. Payments already recorded stay on record. */
app.delete("/fee-structure2", requireLogin, requireAdmin, (req, res) => {
    const feeType = (req.body.fee_type || "").trim();
    const className = (req.body.class_name || "").trim();
    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    if (!feeType || !className || !term || !session) {
        return res.status(400).json({ message: "fee_type, class_name, term and session are all required." });
    }
    if (feeType === "School Fee") {
        return res.status(400).json({ message: "The School Fee row cannot be deleted - set it to 0 instead." });
    }
    connection.query(
        "DELETE FROM fee_structure2 WHERE fee_type = ? AND class_name = ? AND term = ? AND session = ?",
        [feeType, className, term, session],
        (err, out) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Charge removed", deleted: out.affectedRows || 0 });
        }
    );
});

/* ---------- Balance v2: per student, per fee TYPE (admin) ----------- */
app.get("/fee-balance-v2", requireLogin, requireAdmin, (req, res) => {
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();
    const className = (req.query.class_name || "").trim();
    const studentId = (req.query.student_id || "").trim(); // NEW (pack 21): dashboard quick card asks for ONE student
    if (!term || !session) return res.status(400).json({ message: "term and session are required." });
    let sql = `
        SELECT s.student_id, s.full_name, s.class_name,
               fs.fee_type, fs.amount AS fee,
               COALESCE(p.paid, 0) AS paid,
               (fs.amount - COALESCE(p.paid, 0)) AS balance
        FROM students s
        JOIN fee_structure2 fs
          ON fs.class_name = s.class_name AND fs.term = ? AND fs.session = ?
        LEFT JOIN (SELECT student_id, fee_type, SUM(amount) AS paid
                     FROM fee_payments WHERE term = ? AND session = ?
                    GROUP BY student_id, fee_type) p
               ON p.student_id = s.student_id AND p.fee_type = fs.fee_type
    `;
    const params = [term, session, term, session];
    const wh2 = [];
    if (className) { wh2.push("s.class_name = ?"); params.push(className); }
    if (studentId) { wh2.push("s.student_id = ?"); params.push(studentId); } // NEW (pack 21)
    if (wh2.length) sql += " WHERE " + wh2.join(" AND ");
    sql += " ORDER BY s.class_name, s.full_name, fs.fee_type";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

/* ---------- Late-fee ALERTS for the dashboard (admin) ---------------
   Students whose unpaid balance > 0 for the fee type (default
   'School Fee') - flagged late once the day of month passes due_day. */
app.get("/fee-alerts", requireLogin, requireAdmin, (req, res) => {
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();
    const feeType = (req.query.fee_type || "School Fee").trim() || "School Fee";
    if (!term || !session) return res.status(400).json({ message: "term and session are required." });
    connection.query(
        `SELECT s.student_id, s.full_name, s.class_name,
                fs.amount AS fee, COALESCE(p.paid, 0) AS paid,
                (fs.amount - COALESCE(p.paid, 0)) AS balance
         FROM students s
         JOIN fee_structure2 fs
           ON fs.class_name = s.class_name AND fs.term = ? AND fs.session = ? AND fs.fee_type = ?
         LEFT JOIN (SELECT student_id, SUM(amount) AS paid
                      FROM fee_payments WHERE term = ? AND session = ? AND fee_type = ?
                     GROUP BY student_id) p ON p.student_id = s.student_id
         HAVING balance > 0
         ORDER BY s.class_name, s.full_name`,
        [term, session, feeType, term, session, feeType],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            connection.query("SELECT due_day FROM school_settings WHERE id = 1", (e2, srows) => {
                const dueDay = (!e2 && srows && srows.length && srows[0].due_day) ? Number(srows[0].due_day) : 10;
                const today = new Date().getDate();
                const late = today > dueDay;
                res.json({
                    due_day: dueDay, today, is_late: late, fee_type: feeType, term, session,
                    alerts: late ? rows : []   // nobody is "late" before the due day
                });
            });
        }
    );
});

/* ================= NEW (pack 33): DEBTORS BOARD =================
   One admin screen: every student still owing for a term & session,
   summed across ALL fee types, biggest debt first, with one-tap
   reminders (portal chat message + phone push). This is READ-ONLY
   with respect to the existing fee logic: it runs the exact same
   joins as /fee-balance-v2 and only aggregates the rows. */
// NEW (pack 33): shared fee-rows helper - EXACT copy of /fee-balance-v2's
// query so the debtors board always agrees with the Finance numbers.
function amsFeeBalanceRows(term, session, className, studentIds, cb) {
    let sql = `
        SELECT s.student_id, s.full_name, s.class_name,
               fs.fee_type, fs.amount AS fee,
               COALESCE(p.paid, 0) AS paid,
               (fs.amount - COALESCE(p.paid, 0)) AS balance
        FROM students s
        JOIN fee_structure2 fs
          ON fs.class_name = s.class_name AND fs.term = ? AND fs.session = ?
        LEFT JOIN (SELECT student_id, fee_type, SUM(amount) AS paid
                     FROM fee_payments WHERE term = ? AND session = ?
                    GROUP BY student_id, fee_type) p
               ON p.student_id = s.student_id AND p.fee_type = fs.fee_type
    `;
    const params = [term, session, term, session];
    const wh = [];
    if (className) { wh.push("s.class_name = ?"); params.push(className); }
    if (Array.isArray(studentIds) && studentIds.length) {
        wh.push("s.student_id IN (" + studentIds.map(() => "?").join(",") + ")");
        studentIds.forEach((sid) => params.push(sid));
    }
    if (wh.length) sql += " WHERE " + wh.join(" AND ");
    sql += " ORDER BY s.class_name, s.full_name, fs.fee_type";
    connection.query(sql, params, (err, rows) => cb(err, rows));
}

// NEW (pack 33): fold per-fee-type rows into per-student debt cards.
// Overpaying one fee type never hides a debt on another (owed = sum of
// positive per-type balances only); the overpaid part shows as credit.
function amsDebtorsAggregate(rows) {
    const byStudent = {};
    (rows || []).forEach((r) => {
        const sid = r.student_id;
        if (!byStudent[sid]) byStudent[sid] = {
            student_id: sid, full_name: r.full_name, class_name: r.class_name,
            expected: 0, paid: 0, owed: 0, credit: 0, items: []
        };
        const card = byStudent[sid];
        const fee = Number(r.fee) || 0;
        const paid = Number(r.paid) || 0;
        const bal = fee - paid;
        card.expected += fee;
        card.paid += paid;
        if (bal > 0) { card.owed += bal; card.items.push({ fee_type: r.fee_type, balance: bal }); }
        else if (bal < 0) { card.credit += -bal; }
    });
    const list = Object.keys(byStudent).map((k) => byStudent[k]);
    list.sort((a, b) => (b.owed - a.owed) || (a.full_name < b.full_name ? -1 : 1)); // biggest debt first
    return list;
}

// NEW (pack 33): the board - debtors (owed > 0) with totals & due-day flag.
app.get("/fee-debtors", requireLogin, requireAdmin, (req, res) => {
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();
    const className = (req.query.class_name || "").trim();
    if (!term || !session) return res.status(400).json({ message: "term and session are required." });
    amsFeeBalanceRows(term, session, className, null, (err, rows) => {
        if (err || !rows) {
            console.log("fee-debtors notice:", err && err.message);
            return res.json({
                term, session,
                due_day: 10, today: new Date().getDate(), is_late: false,
                students_total: 0, owing_count: 0, cleared_count: 0,
                expected_total: 0, paid_total: 0, outstanding_total: 0,
                debtors: [],
                notice: "No fee balance records found for this session/term"
            });
        }
        connection.query(
            "SELECT student_id, MAX(paid_at) AS last_pay FROM fee_payments WHERE term = ? AND session = ? GROUP BY student_id",
            [term, session],
            (e2, lp) => {
                const lastPay = {};
                if (!e2 && lp) lp.forEach((r) => { lastPay[r.student_id] = r.last_pay; });
                const all = amsDebtorsAggregate(rows);
                const debtors = all.filter((c) => c.owed > 0);
                debtors.forEach((c) => { c.last_pay = lastPay[c.student_id] || null; });
                connection.query("SELECT due_day FROM school_settings WHERE id = 1", (e3, srows) => {
                    const dueDay = (!e3 && srows && srows.length && srows[0].due_day) ? Number(srows[0].due_day) : 10;
                    const today = new Date().getDate();
                    res.json({
                        term, session,
                        due_day: dueDay, today, is_late: today > dueDay,
                        students_total: all.length,
                        owing_count: debtors.length,
                        cleared_count: all.length - debtors.length,
                        expected_total: all.reduce((t, c) => t + c.expected, 0),
                        paid_total: all.reduce((t, c) => t + c.paid, 0),
                        outstanding_total: debtors.reduce((t, c) => t + c.owed, 0),
                        debtors
                    });
                });
            }
        );
    });
});

// NEW (pack 33): one-tap reminder - polite portal chat message + phone push.
// Balance is recomputed live so we never remind a parent who just paid.
app.post("/fee-debtors/remind", requireLogin, requireAdmin, (req, res) => {
    const me = req.session.username;
    const term = String(req.body.term || "").trim();
    const session = String(req.body.session || "").trim();
    let ids = req.body.student_ids;
    if (!term || !session) return res.status(400).json({ message: "term and session are required." });
    if (!Array.isArray(ids) || !ids.length) return res.status(400).json({ message: "Pick at least one student to remind." });
    ids = Array.from(new Set(ids.map((s) => String(s || "").trim()).filter(Boolean))).slice(0, 200);
    if (!ids.length) return res.status(400).json({ message: "Pick at least one student to remind." });
    amsFeeBalanceRows(term, session, "", ids, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        const owedBy = {};
        amsDebtorsAggregate(rows).forEach((c) => { owedBy[c.student_id] = c; });
        const results = {};
        const targets = [];
        ids.forEach((sid) => {
            if (!owedBy[sid]) results[sid] = "not-owing";
            else if (owedBy[sid].owed <= 0) results[sid] = "cleared";
            else targets.push(sid);
        });
        if (!targets.length) return res.json({ sent: 0, skipped: ids.length, failed: 0, results });
        let i = 0, failed = 0;
        const fmtN = (n) => "\u20A6" + Number(n).toLocaleString(undefined, { maximumFractionDigits: 2 });
        (function next() {
            if (i >= targets.length) return res.json({ sent: targets.length - failed, skipped: ids.length - targets.length, failed, results });
            const sid = targets[i++];
            const c = owedBy[sid];
            const parts = c.items.map((it) => it.fee_type + " " + fmtN(it.balance));
            const body = ("Assalamu 'alaikum. Kind reminder: " + fmtN(c.owed) + " is still outstanding for " +
                c.full_name + " (" + term + ", " + session + ")" +
                (parts.length ? " - " + parts.join(", ") : "") +
                ". Please pay to any of the school bank accounts shown on the portal, or send your receipt there. Jazakumullahu khairan.").slice(0, 2000);
            connection.query(
                `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread)
                 VALUES ('staff', ?, ?, 'parent', ?, '', ?, 'admin')`,
                [me, me + " (" + req.session.role + ")", sid, body],
                (iErr) => {
                    if (iErr) { console.log(iErr); failed++; results[sid] = "failed"; }
                    else {
                        results[sid] = "sent";
                        // the parent's phone rings (pack 32 push), tagged so
                        // repeat reminders replace instead of stacking up
                        amsPushSend("portal", [sid], {
                            title: "\u{1F4B3} School fee reminder",
                            body: fmtN(c.owed) + " outstanding for " + term + " - tap to see how to pay.",
                            url: "/portal.html", tag: "debt-" + sid
                        });
                    }
                    next();
                }
            );
        })();
    });
});

/* ---------- BANK ACCOUNTS (many; shown on parent portal) -------------
   SECURITY: this returns the school's bank name / account name / account
   number, so it is no longer fully open. Parents genuinely need it to pay
   fees, so instead of full requireLogin it is gated to callers who hold
   EITHER a staff session (req.session.userId - the School Settings page)
   OR a portal session (req.session.portalStudentId - the parent portal
   "where to pay" card), mirroring how /portal/exams gates portal users.
   Anonymous visitors get a 401. */
app.get("/bank-accounts", (req, res) => {
    const isStaff = !!(req.session && req.session.userId);
    const isPortal = !!(req.session && req.session.portalStudentId);
    if (!isStaff && !isPortal) {
        return res.status(401).json({ message: "Not logged in" });
    }
    connection.query("SELECT id, bank_name, account_name, account_number FROM bank_accounts ORDER BY id", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/bank-account", requireLogin, requireAdmin, (req, res) => {
    const bank = (req.body.bank_name || "").trim();
    const accName = (req.body.account_name || "").trim();
    const accNum = (req.body.account_number || "").trim();
    if (!bank || !accNum) return res.status(400).json({ message: "Bank name and account number are required." });
    connection.query(
        "INSERT INTO bank_accounts (bank_name, account_name, account_number) VALUES (?,?,?)",
        [bank, accName, accNum],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Bank account saved" });
        }
    );
});

app.delete("/bank-account/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM bank_accounts WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Bank account deleted" });
    });
});

/* ---------- PORTAL: my fees & balances (per fee type) ---------------- */
app.get("/portal/fees", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        `SELECT fs.term, fs.session, fs.fee_type, fs.amount AS fee,
                COALESCE(p.paid, 0) AS paid,
                (fs.amount - COALESCE(p.paid, 0)) AS balance
         FROM fee_structure2 fs
         JOIN students st ON st.class_name = fs.class_name AND st.student_id = ?
         LEFT JOIN (SELECT student_id, term, session, fee_type, SUM(amount) AS paid
                      FROM fee_payments WHERE student_id = ?
                     GROUP BY student_id, term, session, fee_type) p
                ON p.term = fs.term AND p.session = fs.session AND p.fee_type = fs.fee_type
         ORDER BY fs.session DESC, fs.term, fs.fee_type`,
        [sid, sid],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

/* NEW (pack 17 - owner request): the parent's own payment rows incl. the
   receipt photo the admin snapped, so "parent will also see it that admin
   has updated the fees in their portal". Legacy fallback keeps working
   while the receipt column warms up. */
app.get("/portal/payments", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    // FIX (pack 17): the payments table stamps paid_at (not created_at).
    connection.query(
        `SELECT id, fee_type, term, session, amount, method, note, receipt_path, paid_at AS created_at
         FROM fee_payments WHERE student_id = ? ORDER BY paid_at DESC LIMIT 100`,
        [sid],
        (err, rows) => {
            if (err && err.code === "ER_BAD_FIELD_ERROR") {
                return connection.query(
                    `SELECT id, amount, method, note, paid_at AS created_at, 'School Fee' AS fee_type, '' AS term, '' AS session, NULL AS receipt_path
                     FROM fee_payments WHERE student_id = ? ORDER BY paid_at DESC LIMIT 100`,
                    [sid],
                    (err2, rows2) => {
                        if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                        res.json(rows2);
                    }
                );
            }
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

/* ---------- PORTAL: parent uploads payment proof (screenshot/PDF) ---- */
const evidenceDir = path.join(__dirname, "uploads", "payment-evidence");
try { fs.mkdirSync(evidenceDir, { recursive: true }); } catch (e) { /* exists */ }

const evidenceStorage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, "uploads/payment-evidence/"),
    filename: (req, file, cb) => {
        const safe = (file.originalname || "proof").replace(/[^a-zA-Z0-9.\-_]/g, "_");
        cb(null, "ev_" + Date.now() + "_" + safe);
    }
});
const uploadEvidence = multer({
    storage: evidenceStorage,
    limits: { fileSize: 8 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const ok = /^image\/(png|jpe?g|gif|webp)$/.test(file.mimetype) || file.mimetype === "application/pdf";
        cb(ok ? null : new Error("Only an image (PNG/JPG) or PDF is allowed."), ok);
    }
});

app.post("/portal/payment-submission", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    uploadEvidence.single("evidence")(req, res, (upErr) => {
        if (upErr) {
            return res.status(400).json({ message: upErr.message || "Upload failed" });
        }
        const feeType = (req.body.fee_type || "School Fee").trim() || "School Fee";
        const term = (req.body.term || "").trim();
        const session = (req.body.session || "").trim();
        const amount = Number(req.body.amount);
        const note = (req.body.note || "").trim();
        if (!term || !session || !(amount > 0)) {
            return res.status(400).json({ message: "Fee type, term, session and a valid amount are required." });
        }
        const evidencePath = req.file ? ("uploads/payment-evidence/" + req.file.filename) : null;
        // FIX (pack 20): keep a database copy of the proof so it cannot
        // disappear when the host wipes its disk.
        const evidenceData = req.file ? fs.readFileSync(req.file.path) : null;
        queryImageSave(
            `INSERT INTO payment_submissions
             (student_id, fee_type, term, session, amount, note, evidence_path, evidence_data)
             VALUES (?,?,?,?,?,?,?,?)`,
            [sid, feeType, term, session, amount, note, evidencePath, evidenceData],
            `INSERT INTO payment_submissions
             (student_id, fee_type, term, session, amount, note, evidence_path)
             VALUES (?,?,?,?,?,?,?)`,
            [sid, feeType, term, session, amount, note, evidencePath],
            (err) => {
                if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
                res.json({ message: "Payment proof sent. The school will review it shortly." });
            }
        );
    });
});

app.get("/portal/my-submissions", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query(
        `SELECT id, fee_type, term, session, amount, note, evidence_path, status, created_at
         FROM payment_submissions WHERE student_id = ? ORDER BY created_at DESC LIMIT 50`,
        [sid],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

/* ---------- ADMIN: review parent payment proofs ---------------------- */
app.get("/payment-submissions", requireLogin, requireAdmin, (req, res) => {
    let sql = `
        SELECT ps.*, st.full_name, st.class_name
        FROM payment_submissions ps
        LEFT JOIN students st ON st.student_id = ps.student_id
    `;
    const params = [];
    if (req.query.status) { sql += " WHERE ps.status = ?"; params.push(req.query.status); }
    sql += " ORDER BY ps.created_at DESC LIMIT 300";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

function reviewSubmission(req, res, approve) {
    connection.query("SELECT * FROM payment_submissions WHERE id = ?", [req.params.id], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "Submission not found." });
        const sub = rows[0];
        if (sub.status !== "pending") {
            return res.status(400).json({ message: "Already " + sub.status + "." });
        }
        const finish = () => {
            connection.query(
                "UPDATE payment_submissions SET status = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?",
                [approve ? "approved" : "rejected", req.session.username || null, req.params.id],
                (err3) => {
                    if (err3) { console.log(err3); return res.status(500).json({ message: "Database error" }); }
                    res.json({ message: approve ? "Approved - added to the student's payments." : "Rejected." });
                }
            );
        };
        if (!approve) return finish();
        // Approved: becomes a REAL payment for the student (tagged by fee type)
        connection.query(
            `INSERT INTO fee_payments (student_id, term, session, fee_type, amount, method, note, received_by)
             VALUES (?,?,?,?,?,?,?,?)`,
            [sub.student_id, sub.term, sub.session, sub.fee_type || "School Fee", sub.amount,
             "Parent upload", "Parent proof #" + sub.id, req.session.username || null],
            (err2) => {
                if (err2 && err2.code === "ER_BAD_FIELD_ERROR") {
                    return connection.query(
                        `INSERT INTO fee_payments (student_id, term, session, amount, method, note, received_by)
                         VALUES (?,?,?,?,?,?,?)`,
                        [sub.student_id, sub.term, sub.session, sub.amount,
                         "Parent upload", "Parent proof #" + sub.id, req.session.username || null],
                        (err2b) => {
                            if (err2b) { console.log(err2b); return res.status(500).json({ message: "Database error" }); }
                            finish();
                        }
                    );
                }
                if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                finish();
            }
        );
    });
}

app.post("/payment-submission/:id/approve", requireLogin, requireAdmin, (req, res) => reviewSubmission(req, res, true));
app.post("/payment-submission/:id/reject",  requireLogin, requireAdmin, (req, res) => reviewSubmission(req, res, false));

/* ---------- NEW (pack 17 - owner request): receipt photo on a recorded
   payment. Admin snaps the receipt written in school and attaches it to
   the payment; the parent sees it in their portal (My Fees & Balance);
   admin can remove it if it is not clear. Reuses the image upload
   machinery (uploads/payment-evidence) built for parent proofs. */
app.post("/fee-payment/:id/receipt", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    uploadEvidence.single("receipt")(req, res, (upErr) => {
        if (upErr) return res.status(400).json({ message: upErr.message || "Upload failed" });
        if (!req.file) return res.status(400).json({ message: "Choose the receipt photo first." });
        const p = "uploads/payment-evidence/" + req.file.filename;
        // FIX (pack 20): database copy of the receipt photo too.
        const recData = fs.readFileSync(req.file.path);
        queryImageSave(
            "UPDATE fee_payments SET receipt_path = ?, receipt_data = ? WHERE id = ?",
            [p, recData, req.params.id],
            "UPDATE fee_payments SET receipt_path = ? WHERE id = ?",
            [p, req.params.id],
        (err, result) => {
            if (err) {
                // migration still creating the column (first boot after update)
                if (err.code === "ER_BAD_FIELD_ERROR") {
                    return res.status(503).json({ message: "Receipt feature is warming up - wait one minute and try again." });
                }
                console.log(err); return res.status(500).json({ message: "Database error" });
            }
            if (!result.affectedRows) return res.status(404).json({ message: "Payment not found." });
            res.json({ message: "Receipt photo saved - the parent can now see it in their portal.", path: p });
        });
    });
});

// Remove an unclear/wrong receipt photo (file is deleted too).
app.delete("/fee-payment/:id/receipt", requireLogin, requireAdmin, (req, res) => {
    connection.query("SELECT receipt_path FROM fee_payments WHERE id = ?", [req.params.id], (err, rows) => {
        if (err) {
            if (err.code === "ER_BAD_FIELD_ERROR") return res.status(503).json({ message: "Receipt feature is warming up - try again shortly." });
            console.log(err); return res.status(500).json({ message: "Database error" });
        }
        const p = rows && rows[0] && rows[0].receipt_path;
        connection.query("UPDATE fee_payments SET receipt_path = NULL WHERE id = ?", [req.params.id], (err2) => {
            if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
            if (p && String(p).indexOf("uploads/") === 0) {
                try { fs.unlinkSync(path.join(__dirname, p)); } catch (e) { /* file already gone */ }
            }
            res.json({ message: "Receipt photo removed." });
        });
    });
});

/* NEW (pack 17 - owner request): dashboard reminder - every payment in
   the current term/session that still has NO snapped receipt photo,
   listed WITH the student names so admin knows exactly who is missing. */
app.get("/receipt-alerts", requireLogin, requireAdmin, (req, res) => {
    const term = (req.query.term || "").trim();
    const schoolSession = (req.query.session || "").trim();
    // FIX (pack 17): the payments table stamps paid_at (not created_at).
    let sql = `SELECT fp.id, fp.student_id, st.full_name, fp.fee_type, fp.amount, fp.paid_at AS created_at
               FROM fee_payments fp
               LEFT JOIN students st ON st.student_id = fp.student_id
               WHERE (fp.receipt_path IS NULL OR fp.receipt_path = '')`;
    const params = [];
    if (term) { sql += " AND fp.term = ?"; params.push(term); }
    if (schoolSession) { sql += " AND fp.session = ?"; params.push(schoolSession); }
    sql += " ORDER BY fp.paid_at DESC LIMIT 200";
    connection.query(sql, params, (err, rows) => {
        if (err && err.code === "ER_BAD_FIELD_ERROR") return res.json([]); // column warming up
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

/* GET /attendance/student (per-pupil history, pack 17) MOVED (pack 108) into
   the student-attendance section above, where it now reads the schema first
   and answers an empty history instead of a 500 when the table is missing. */


/* ---------- MADRASAH CALENDAR (admin) --------------------------------
   publishes ONE at a time: publishing auto-unpublishes the rest so the
   parent portal never shows duplicates from different terms. */
app.get("/calendars", requireLogin, (req, res) => {
    // NEW (pack 16): ?published=1 returns ONLY the live calendar - teachers
    // read this on their dashboard (same rule as the parent portal). The
    // plain list (admin studio) still returns everything, unchanged.
    const onlyLive = String(req.query.published || "") === "1";
    const sql = onlyLive
        ? "SELECT * FROM calendars WHERE published = 1 ORDER BY updated_at DESC LIMIT 5"
        : "SELECT * FROM calendars ORDER BY updated_at DESC";
    connection.query(sql, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

/* Portal sees ONLY published calendars; unpublish/delete => it is gone. */
app.get("/portal/calendars", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    connection.query("SELECT * FROM calendars WHERE published = 1 ORDER BY updated_at DESC LIMIT 5", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows);
    });
});

app.post("/calendar", requireLogin, requireAdmin, (req, res) => {
    const id = Number(req.body.id) || 0;
    const title = (req.body.title || "").trim();
    const docStr = typeof req.body.doc === "string" ? req.body.doc : JSON.stringify(req.body.doc || {});
    if (!title) return res.status(400).json({ message: "Calendar title is required." });
    if (id) {
        connection.query("UPDATE calendars SET title = ?, doc = ? WHERE id = ?", [title, docStr, id], (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Calendar saved", id });
        });
    } else {
        connection.query("INSERT INTO calendars (title, doc, published) VALUES (?,?,0)", [title, docStr], (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Calendar saved", id: result.insertId });
        });
    }
});

app.post("/calendar-publish", requireLogin, requireAdmin, (req, res) => {
    const id = Number(req.body.id);
    const publish = Number(req.body.published) ? 1 : 0;
    if (!id) return res.status(400).json({ message: "Calendar is required." });
    const apply = () => connection.query("UPDATE calendars SET published = ? WHERE id = ?", [publish, id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: publish ? "Published - now visible on the parent portal." : "Unpublished - removed from the parent portal." });
    });
    if (publish) {
        // ONE live calendar at a time - no duplicates from other terms.
        connection.query("UPDATE calendars SET published = 0", (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            apply();
        });
    } else {
        apply();
    }
});

app.delete("/calendar/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM calendars WHERE id = ?", [req.params.id], (err) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json({ message: "Calendar deleted" });
    });
});

// ==========================================================================
// NEW (pack 39 - owner chose "One-tap backup" as the new beneficial
// feature): ADMIN-ONLY full JSON backup of the whole school database.
// One tap on the teacher dashboard downloads ameenullah-backup-YYYY-MM-DD.json.
// Student passport photo blobs are replaced with a short note so the file
// stays small enough for a phone to handle; everything else is complete.
// Additive route - nothing else was touched.
// ==========================================================================
app.get("/backup.json", requireLogin, requireAdmin, (req, res) => {
    connection.query("SHOW TABLES", (err, tables) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        const key = Object.keys(tables[0] || {})[0];
        const names = tables.map(r => r[key]);
        const out = {
            app: "Ameenullah School Result System",
            kind: "full-backup",
            version: 2,
            created_at: new Date().toISOString(),
            tables: {}
        };
        let i = 0;
        const nextTable = () => {
            if (i >= names.length) {
                const stamp = new Date().toISOString().slice(0, 10);
                res.setHeader("Content-Type", "application/json");
                res.setHeader("Content-Disposition", 'attachment; filename="ameenullah-backup-' + stamp + '.json"');
                return res.send(JSON.stringify(out));
            }
            const t = names[i++];
            connection.query("SELECT * FROM `" + t + "`", (e2, rows) => {
                if (e2) { console.log(e2); out.tables[t] = { error: "could not read table" }; return nextTable(); }
                if (t === "students") {
                    rows.forEach(r => {
                        if (r.photo_path) {
                            try {
                                const abs = path.join(__dirname, r.photo_path);
                                if (fs.existsSync(abs)) r.photo_base64 = fs.readFileSync(abs).toString("base64");
                            } catch (e) {}
                        }
                        if (r.photo_data && Buffer.isBuffer(r.photo_data)) {
                            r.photo_base64 = r.photo_data.toString("base64");
                        }
                        r.photo_data = "[photo stored in photo_base64]";
                    });
                }
                if (t === "signatures") {
                    rows.forEach(r => {
                        if (r.signature_path) {
                            try {
                                const abs = path.join(__dirname, r.signature_path);
                                if (fs.existsSync(abs)) r.signature_base64 = fs.readFileSync(abs).toString("base64");
                            } catch (e) {}
                        }
                    });
                }
                out.tables[t] = rows;
                nextTable();
            });
        };
        nextTable();
    });
});

// NEW (Pack 72/74): One-Click Restore from Backup JSON (ameenullah-backup-YYYY-MM-DD.json)
// Re-populates any empty or fresh MySQL database with all saved students, results, fees, classes, settings, photos & signatures.
app.post("/api/restore-backup", requireLogin, requireAdmin, writeRateLimit, uploadStore.single("backup"), (req, res) => {
    if (!req.file && !req.body.json_data) {
        return res.status(400).json({ message: "No backup file uploaded." });
    }
    let data;
    try {
        const raw = req.file ? fs.readFileSync(req.file.path, "utf8") : req.body.json_data;
        data = JSON.parse(raw);
    } catch (e) {
        return res.status(400).json({ message: "Invalid JSON backup file format." });
    }

    const tablesObj = data.tables || data;
    const tableNames = Object.keys(tablesObj);
    if (!tableNames.length) {
        return res.status(400).json({ message: "No table records found in backup file." });
    }

    let restoredTables = 0;
    let totalRows = 0;

    tableNames.forEach((tbl) => {
        const rows = tablesObj[tbl];
        if (!Array.isArray(rows) || !rows.length) return;
        restoredTables++;
        rows.forEach((row) => {
            const cols = Object.keys(row).filter(c => c !== "photo_data" && c !== "photo_base64" && c !== "signature_base64" && c !== "id" && row[c] !== undefined);
            if (!cols.length) return;
            const vals = cols.map(c => row[c]);
            const placeholders = cols.map(() => "?").join(",");
            const colNames = cols.map(c => "`" + c + "`").join(",");

            const sql = `INSERT IGNORE INTO \`${tbl}\` (${colNames}) VALUES (${placeholders})`;
            connection.query(sql, vals, () => {
                // Restore student photos onto server disk and database
                if (tbl === "students" && row.photo_base64 && row.student_id) {
                    try {
                        const buf = Buffer.from(row.photo_base64, "base64");
                        const targetDir = path.join(__dirname, "images", "students");
                        fs.mkdirSync(targetDir, { recursive: true });
                        const destPath = path.join(targetDir, row.student_id + ".png");
                        fs.writeFileSync(destPath, buf);
                        connection.query("UPDATE students SET photo_data = ?, photo_path = ? WHERE student_id = ?", [buf, `images/students/${row.student_id}.png`, row.student_id], () => {});
                    } catch (e) {}
                }
                // Restore staff signature images onto server disk
                if (tbl === "signatures" && row.signature_base64 && row.role) {
                    try {
                        const buf = Buffer.from(row.signature_base64, "base64");
                        const targetDir = path.join(__dirname, "images", "signatures");
                        fs.mkdirSync(targetDir, { recursive: true });
                        const destPath = path.join(targetDir, row.role + ".png");
                        fs.writeFileSync(destPath, buf);
                    } catch (e) {}
                }
            });
            totalRows++;
        });
    });

    res.json({
        message: `🎉 Backup Restored Successfully! Processed ${restoredTables} tables and ${totalRows} records. All students, photos & signatures are restored!`,
        restoredTables,
        totalRows
    });
});

/* ==========================================================================
   NEW (pack 40a - owner chose "all" the suggested features):

   1) TAHFEEDH TRACKER: store each student's Qur'an memorisation progress
      (0-30 juz). Table is created here at boot (additive, IF NOT EXISTS).
      GET  /tahfeedh?class_name=...  -> class roster LEFT JOIN progress
      POST /tahfeedh {student_id, juz} -> save (upsert). Login required.

   2) HONOUR ROLL: PUBLIC read-only endpoint for the website - top 3
      students per class by average total in the LATEST term+session on
      record. Nothing is written; only name/avg/photo are exposed.
========================================================================== */
connection.query(
    `CREATE TABLE IF NOT EXISTS tahfeedh (
        student_id VARCHAR(50) NOT NULL PRIMARY KEY,
        juz TINYINT UNSIGNED NOT NULL DEFAULT 0,
        note VARCHAR(200) NULL,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        updated_by VARCHAR(64) NULL
    )`,
    (e) => { if (e) console.log("Pack 40 tahfeedh table notice:", e.code || e.message); else console.log("Pack 40 setup ready (tahfeedh)."); }
);
// FIX (pack 40): a tahfeedh table may already exist WITHOUT updated_by -
// add it in that case (guarded; never alters anything else).
connection.query("ALTER TABLE tahfeedh ADD COLUMN updated_by VARCHAR(64) NULL", (e2) => {
    if (e2 && e2.code !== "ER_DUP_FIELDNAME") console.log("Pack 40 tahfeedh upgrade notice:", e2.code || e2.message);
});

app.get("/tahfeedh", requireLogin, (req, res) => {
    const className = (req.query.class_name || "").trim();
    if (!className) return res.status(400).json({ message: "class_name is required." });
    connection.query(
        `SELECT s.student_id, s.full_name, s.gender, s.photo_path,
                COALESCE(t.juz, 0) AS juz, t.note, t.updated_at
         FROM students s
         LEFT JOIN tahfeedh t ON t.student_id = s.student_id
         WHERE s.class_name = ?
         ORDER BY s.full_name`,
        [className],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows);
        }
    );
});

app.post("/tahfeedh", requireLogin, (req, res) => {
    const sid = String(req.body.student_id || "").trim();
    const juz = Math.max(0, Math.min(30, parseInt(req.body.juz, 10) || 0));
    const note = String(req.body.note || "").trim().slice(0, 200) || null;
    if (!sid) return res.status(400).json({ message: "student_id is required." });
    connection.query(
        `INSERT INTO tahfeedh (student_id, juz, note, updated_by)
         VALUES (?,?,?,?)
         ON DUPLICATE KEY UPDATE juz = VALUES(juz), note = VALUES(note), updated_by = VALUES(updated_by)`,
        [sid, juz, note, req.session.username || null],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Saved", student_id: sid, juz: juz });
        }
    );
});

/* NEW (pack 40b): PUBLIC honour roll for the website. Read-only, tiny
   in-memory cache (60s) so the busy homepage never hammers the DB. */
let amsHonourCache = { at: 0, data: null };
app.get("/honour-roll", (req, res) => {
    if (amsHonourCache.data && Date.now() - amsHonourCache.at < 60000) {
        return res.json(amsHonourCache.data);
    }
    connection.query(
        `SELECT session, term FROM results
         ORDER BY session DESC, FIELD(term,'3rd Term','2nd Term','1st Term') LIMIT 1`,
        (e0, latest) => {
            if (e0) { console.log(e0); return res.status(500).json({ message: "Database error" }); }
            if (!latest || !latest.length) return res.json({ session: null, term: null, classes: [] });
            const session = latest[0].session, term = latest[0].term;
            connection.query(
                `SELECT r.class_name, r.student_id, MAX(r.student_name) AS full_name,
                        ROUND(AVG(r.total), 1) AS avg_total, COUNT(*) AS subjects
                 FROM results r
                 WHERE r.session = ? AND r.term = ?
                 GROUP BY r.class_name, r.student_id
                 ORDER BY r.class_name, avg_total DESC`,
                [session, term],
                (err, rows) => {
                    if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
                    const byClass = {};
                    (rows || []).forEach((r) => {
                        (byClass[r.class_name] = byClass[r.class_name] || []).push(r);
                    });
                    const classes = Object.keys(byClass).map((c) => ({
                        class_name: c,
                        students: byClass[c].slice(0, 3)
                    }));
                    const data = { session, term, classes };
                    amsHonourCache = { at: Date.now(), data };
                    res.json(data);
                }
            );
        }
    );
});

/* =====================================================================
   NEW (Pack 47/49): SCHOOL FILE STORE / DIGITAL VAULT ENDPOINTS
   Allows teachers/admins to create folders, upload any files, preview, and download.
===================================================================== */
function fixUtf8(str) {
    if (!str) return str;
    try {
        const buf = Buffer.from(str, "latin1");
        if (buf.toString("utf8").length < str.length || /[\u0600-\u06FF]/.test(buf.toString("utf8"))) {
            return buf.toString("utf8");
        }
    } catch (e) {}
    return str;
}

function syncExamsToVault(cb) {
    connection.query(
        "SELECT id FROM school_file_store WHERE folder_path = '/' AND file_name = 'Saved Exams' AND is_folder = 1",
        (err, rows) => {
            if (!rows || !rows.length) {
                connection.query("INSERT INTO school_file_store (folder_path, file_name, original_name, is_folder) VALUES ('/', 'Saved Exams', 'Saved Exams', 1)", () => {});
            }
            connection.query("SELECT * FROM exams", (err2, exams) => {
                if (err2 || !exams || !exams.length) { if (cb) cb(); return; }
                exams.forEach((ex) => {
                    // CHANGED (pack 82): dedup on the single new "(Printable).html" name...
                    const printOriginalName = `${ex.class_name} - ${ex.subject} - ${ex.title} (Printable).html`;
                    // ...and REMOVE any leftover pre-pack-82 duplicates (the bare
                    // ".doc" and the duplicate "(Printable Sheet).html") so no exam
                    // ever appears twice in the vault.
                    connection.query(
                        "DELETE FROM school_file_store WHERE folder_path = '/Saved Exams' AND original_name IN (?, ?)",
                        [
                            `${ex.class_name} - ${ex.subject} - ${ex.title}.doc`,
                            `${ex.class_name} - ${ex.subject} - ${ex.title} (Printable Sheet).html`
                        ],
                        () => {}
                    );
                    connection.query(
                        "SELECT id FROM school_file_store WHERE folder_path = '/Saved Exams' AND original_name = ?",
                        [printOriginalName],
                        (err3, exist) => {
                            if (!exist || !exist.length) {
                                autoStoreExamToVault(ex.title, ex.class_name, ex.subject, ex.term, ex.session, ex.duration, ex.instructions, ex.body_html);
                            }
                        }
                    );
                });
                if (cb) cb();
            });
        }
    );
}

app.get("/api/store/list", requireLogin, (req, res) => {
    let folder = (req.query.folder || "/").trim();
    let p1 = folder;
    let p2 = folder.endsWith("/") && folder !== "/" ? folder.slice(0, -1) : (folder === "/" ? "/" : folder + "/");
    let p3 = folder.replace(/^\//, "");
    let p4 = p3.endsWith("/") && p3 !== "" ? p3.slice(0, -1) : p3 + "/";
    if (!p3) p3 = "/";
    if (!p4) p4 = "/";

    syncExamsToVault(() => {
        connection.query(
            "SELECT * FROM school_file_store WHERE (folder_path = ? OR folder_path = ? OR folder_path = ? OR folder_path = ?) ORDER BY is_folder DESC, file_name ASC",
            [p1, p2, p3, p4],
            (err, rows) => {
                if (err) {
                    console.log(err);
                    return res.status(500).json({ message: "Database Error" });
                }
                const cleaned = (rows || []).map((r) => ({
                    ...r,
                    file_name: fixUtf8(r.file_name),
                    original_name: fixUtf8(r.original_name)
                }));
                res.json(cleaned);
            }
        );
    });
});

app.post("/api/store/create-folder", requireLogin, (req, res) => {
    const { folder_path, folder_name } = req.body;
    if (!folder_name || !folder_name.trim()) {
        return res.status(400).json({ message: "Folder name is required." });
    }
    const pathVal = folder_path || "/";
    connection.query(
        "INSERT INTO school_file_store (folder_path, file_name, original_name, is_folder) VALUES (?, ?, ?, 1)",
        [pathVal, folder_name.trim(), folder_name.trim()],
        (err, result) => {
            if (err) {
                console.log(err);
                return res.status(500).json({ message: "Database Error" });
            }
            res.json({ message: "Folder created successfully.", id: result.insertId });
        }
    );
});

app.post("/api/store/upload", requireLogin, writeRateLimit, uploadStore.array("files", 20), (req, res) => {
    let files = req.files || [];
    if (!files.length && req.file) files = [req.file];
    if (!files.length) {
        return res.status(400).json({ message: "No file(s) uploaded." });
    }
    const folder = req.body.folder_path || "/";
    let saved = 0;
    files.forEach((file) => {
        const cleanOriginalName = fixUtf8(file.originalname || "file");
        connection.query(
            "INSERT INTO school_file_store (folder_path, file_name, original_name, file_size, file_type, file_path, is_folder) VALUES (?, ?, ?, ?, ?, ?, 0)",
            [
                folder,
                cleanOriginalName,
                cleanOriginalName,
                file.size,
                file.mimetype || "application/octet-stream",
                file.filename
            ],
            () => {}
        );
        saved++;
    });
    res.json({ message: `Uploaded ${saved} file(s) successfully.`, count: saved });
});

app.delete("/api/store/delete/:id", requireLogin, (req, res) => {
    const id = req.params.id;
    connection.query("SELECT * FROM school_file_store WHERE id = ?", [id], (err, rows) => {
        if (err || !rows || !rows.length) {
            return res.status(404).json({ message: "Item not found." });
        }
        const item = rows[0];
        connection.query("DELETE FROM school_file_store WHERE id = ?", [id], (err2) => {
            if (err2) return res.status(500).json({ message: "Database Error" });
            if (item.is_folder === 0 && item.file_path) {
                const fp1 = path.join(storeDir, path.basename(item.file_path));
                const fp2 = path.join(__dirname, item.file_path);
                try { if (fs.existsSync(fp1)) fs.unlinkSync(fp1); else if (fs.existsSync(fp2)) fs.unlinkSync(fp2); } catch (e) {}
            }
            res.json({ message: "Deleted successfully." });
        });
    });
});

function resolveStoreFilePath(item) {
    if (!item) return null;
    const candidates = [
        item.file_path,
        item.file_name,
        item.original_name
    ].filter(Boolean);

    for (const cand of candidates) {
        const base = path.basename(cand);
        const paths = [
            path.join(storeDir, base),
            path.join(__dirname, "uploads", base),
            path.join(__dirname, "uploads", "payment-evidence", base),
            path.join(__dirname, "uploads", "store", base),
            path.join(__dirname, "images", base),
            path.join(__dirname, "images", "students", base),
            path.join(__dirname, "images", "signatures", base),
            path.join(__dirname, cand),
            path.join(__dirname, "uploads", cand),
            cand
        ];
        for (const p of paths) {
            try {
                if (fs.existsSync(p) && fs.statSync(p).isFile()) {
                    return p;
                }
            } catch (e) {}
        }
    }
    return null;
}

app.get("/api/store/download/:id", requireLogin, (req, res) => {
    const id = req.params.id;
    connection.query("SELECT * FROM school_file_store WHERE id = ?", [id], (err, rows) => {
        if (err || !rows || !rows.length || rows[0].is_folder === 1) {
            return res.status(404).send("File not found.");
        }
        const item = rows[0];
        const fp = resolveStoreFilePath(item);
        if (!fp) {
            return res.status(404).send("File missing on server storage: " + (item.file_name || item.original_name));
        }
        const cleanName = fixUtf8(item.original_name || item.file_name || "download");
        res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(cleanName)}`);
        res.setHeader("Content-Type", item.file_type || "application/octet-stream");
        res.sendFile(fp);
    });
});

app.get("/api/store/view/:id", requireLogin, (req, res) => {
    const id = req.params.id;
    connection.query("SELECT * FROM school_file_store WHERE id = ?", [id], (err, rows) => {
        if (err || !rows || !rows.length || rows[0].is_folder === 1) {
            return res.status(404).send("File not found.");
        }
        const item = rows[0];
        const fp = resolveStoreFilePath(item);
        if (!fp) {
            return res.status(404).send("File missing on server storage: " + (item.file_name || item.original_name));
        }
        const cleanName = fixUtf8(item.original_name || item.file_name || "view");
        res.setHeader("Content-Disposition", `inline; filename*=UTF-8''${encodeURIComponent(cleanName)}`);
        res.setHeader("Content-Type", item.file_type || "application/octet-stream");
        res.sendFile(fp);
    });
});

app.get("/test", (req, res) => {
    res.send("Server is working");
});

/* ==========================================================================
   PACK 65 — NEW PARENT PORTAL FEATURE ROUTES
   ========================================================================== */

/* ---------- PROGRESS CHART: subject scores across terms ---------- */
app.get("/portal/progress", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query(
        `SELECT subject, term, session, total, grade
         FROM results WHERE student_id = ?
         ORDER BY session, term, subject`,
        [sid], (err, rows) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json(rows);
        }
    );
});

/* ---------- CLASS POSITION per term/session ---------- */
/* FIX (pack 88): the portal "Class Position" list came back empty for
   promoted students and for classes whose Arabic name differed by
   tashkeel/spacing (results were looked up under the CURRENT class only,
   with an exact SQL =). Now every (term, session) the student actually
   has results for is resolved to the class stored on THEIR result rows,
   all matching is tolerant, and the 3rd Term position uses the same
   cumulative three-term average as the report sheet - so the sidebar
   always agrees with the printed report. */
app.get("/portal/position", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query(
        `SELECT DISTINCT term, session, class_name FROM results
         WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))`,
        [sid, sid],
        (err, ownRows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            const pairs = [];
            const seen = Object.create(null);
            (ownRows || []).forEach(r => {
                const key = String(r.term || "") + "|" + String(r.session || "");
                if (seen[key]) return;
                seen[key] = true;
                pairs.push({ term: r.term, session: r.session, class_name: r.class_name });
            });
            if (!pairs.length) return res.json([]);

            connection.query(
                `SELECT class_name FROM students
                 WHERE TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)) LIMIT 1`,
                [sid, sid],
                (err2, stu) => {
                    if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                    const currentClass = (stu && stu[0] && stu[0].class_name) || "";
                    const result = [];
                    let i = 0;
                    const next = () => {
                        if (i >= pairs.length) {
                            result.sort((a, b) =>
                                String(b.session).localeCompare(String(a.session)) ||
                                amsTermOrder(b.term) - amsTermOrder(a.term)
                            );
                            return res.json(result);
                        }
                        const p = pairs[i++];
                        connection.query(
                            `SELECT DISTINCT class_name FROM results
                             WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))
                               AND TRIM(term) = TRIM(?) AND TRIM(session) = TRIM(?)`,
                            [sid, sid, p.term, p.session],
                            (err3, ownRows2) => {
                                if (err3) { console.log(err3); return next(); }
                                const ownClasses = (ownRows2 || []).map(x => x.class_name).filter(Boolean);
                                const resolved = ownClasses.find(c => classNamesMatch(c, currentClass)) || ownClasses[0] || p.class_name || currentClass;
                                const termFilter = p.term === "3rd Term" ? "term IN ('1st Term','2nd Term','3rd Term')" : "term = ?";
                                const sql = `SELECT student_id, class_name, subject, term, total
                                             FROM results WHERE session = ? AND ${termFilter}`;
                                const params = p.term === "3rd Term" ? [p.session] : [p.session, p.term];
                                connection.query(sql, params, (err4, rows) => {
                                    if (err4) { console.log(err4); return next(); }
                                    const classRows = (rows || []).filter(r => classNamesMatch(r.class_name, resolved));
                                    const doRank = (finalRows) => {
                                        const rank = amsRankClassResults(finalRows, p.term, sid);
                                        if (rank.position > 0) {
                                            result.push({ term: p.term, session: p.session, position: rank.position, total: rank.total });
                                        }
                                        next();
                                    };
                                    if (p.term !== "3rd Term") return doRank(classRows);
                                    // Merge the student's own 1st/2nd-term rows
                                    // (any class) - same rule as /student-position.
                                    connection.query(
                                        `SELECT student_id, class_name, subject, term, total FROM results
                                         WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))
                                           AND session = ? AND term IN ('1st Term','2nd Term')`,
                                        [sid, sid, p.session],
                                        (eOwn, ownRows) => {
                                            if (eOwn) { console.log(eOwn); return doRank(classRows); }
                                            doRank(amsAppendOwnPriorRows(classRows, ownRows, sid));
                                        }
                                    );
                                });
                            }
                        );
                    };
                    next();
                }
            );
        }
    );
});

/* ---------- SUBJECTS LIST for student's class ---------- */
app.get("/portal/subjects", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query("SELECT class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err || !rows.length) return res.status(404).json([]);
        connection.query(
            "SELECT DISTINCT subject_name FROM subjects WHERE class_name = ? ORDER BY subject_name",
            [rows[0].class_name], (err2, subs) => {
                if (err2) return res.status(500).json([]);
                res.json(subs.map(s => s.subject_name));
            }
        );
    });
});

/* ---------- HOMEWORK: portal view (read only) ---------- */
app.get("/portal/homework", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query("SELECT class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err || !rows.length) return res.json([]);
        connection.query(
            `SELECT id, subject, title, description, due_date, posted_by, created_at
             FROM homework WHERE class_name = ?
             ORDER BY due_date IS NULL, due_date ASC, created_at DESC
             LIMIT 30`,
            [rows[0].class_name], (err2, hw) => {
                if (err2) return res.status(500).json([]);
                res.json(hw);
            }
        );
    });
});

/* ---------- HOMEWORK: admin/teacher management ---------- */
app.get("/api/homework", requireLogin, (req, res) => {
    const cls = req.query.class_name;
    const sql = cls
        ? "SELECT * FROM homework WHERE class_name = ? ORDER BY created_at DESC LIMIT 100"
        : "SELECT * FROM homework ORDER BY created_at DESC LIMIT 100";
    const params = cls ? [cls] : [];
    connection.query(sql, params, (err, rows) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(rows);
    });
});

app.post("/api/homework", requireLogin, writeRateLimit, (req, res) => {
    const { class_name, subject, title, description, due_date } = req.body;
    if (!class_name || !subject || !title) return res.status(400).json({ message: "Class, subject and title are required." });
    const postedBy = req.session.username || "Staff";
    const dd = due_date && /^\d{4}-\d{2}-\d{2}$/.test(due_date) ? due_date : null;
    connection.query(
        "INSERT INTO homework (class_name, subject, title, description, due_date, posted_by) VALUES (?,?,?,?,?,?)",
        [class_name, subject, title, description || null, dd, postedBy],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Homework posted." });
        }
    );
});

app.delete("/api/homework/:id", requireLogin, (req, res) => {
    connection.query("DELETE FROM homework WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Deleted." });
    });
});

/* ---------- HEALTH RECORDS ---------- */
app.get("/portal/health", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json({});
    connection.query("SELECT * FROM student_health WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(rows[0] || {});
    });
});

app.get("/api/health/:studentId", requireLogin, (req, res) => {
    connection.query("SELECT * FROM student_health WHERE student_id = ? LIMIT 1", [req.params.studentId], (err, rows) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(rows[0] || {});
    });
});

app.post("/api/health/:studentId", requireLogin, writeRateLimit, (req, res) => {
    const { blood_group, allergies, medical_conditions, emergency_contact_name, emergency_contact_phone, notes,
            height_cm, weight_kg, bmi, genotype, doctor_name, doctor_phone, insurance_no,
            current_medications, last_checkup, special_needs } = req.body;
    const sid = req.params.studentId;
    connection.query(
        `INSERT INTO student_health (student_id, blood_group, allergies, medical_conditions, emergency_contact_name, emergency_contact_phone, notes,
             height_cm, weight_kg, bmi, genotype, doctor_name, doctor_phone, insurance_no,
             current_medications, last_checkup, special_needs)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE
             blood_group=VALUES(blood_group), allergies=VALUES(allergies),
             medical_conditions=VALUES(medical_conditions), emergency_contact_name=VALUES(emergency_contact_name),
             emergency_contact_phone=VALUES(emergency_contact_phone), notes=VALUES(notes),
             height_cm=VALUES(height_cm), weight_kg=VALUES(weight_kg), bmi=VALUES(bmi),
             genotype=VALUES(genotype), doctor_name=VALUES(doctor_name), doctor_phone=VALUES(doctor_phone),
             insurance_no=VALUES(insurance_no), current_medications=VALUES(current_medications),
             last_checkup=VALUES(last_checkup), special_needs=VALUES(special_needs)`,
        [sid, blood_group||'', allergies||null, medical_conditions||null, emergency_contact_name||'', emergency_contact_phone||'', notes||null,
         height_cm||null, weight_kg||null, bmi||null, genotype||'', doctor_name||'', doctor_phone||'', insurance_no||'',
         current_medications||null, last_checkup||null, special_needs||null],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Health record saved." });
        }
    );
});

/* ---------- TRANSPORT ROUTES ---------- */
app.get("/api/transport/routes", requireLogin, (req, res) => {
    connection.query("SELECT * FROM transport_routes ORDER BY route_name", (err, rows) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(rows);
    });
});

app.post("/api/transport/routes", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const { route_name, bus_number, driver_name, driver_phone, pickup_time, dropoff_time, notes } = req.body;
    if (!route_name) return res.status(400).json({ message: "Route name is required." });
    connection.query(
        "INSERT INTO transport_routes (route_name, bus_number, driver_name, driver_phone, pickup_time, dropoff_time, notes) VALUES (?,?,?,?,?,?,?)",
        [route_name, bus_number||'', driver_name||'', driver_phone||'', pickup_time||'', dropoff_time||'', notes||null],
        (err, result) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Route added.", id: result.insertId });
        }
    );
});

app.delete("/api/transport/routes/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM transport_routes WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Route deleted." });
    });
});

app.post("/api/transport/assign", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const { student_id, route_id, pickup_point, notes } = req.body;
    if (!student_id) return res.status(400).json({ message: "Student ID is required." });
    connection.query(
        `INSERT INTO transport_assignments (student_id, route_id, pickup_point, notes)
         VALUES (?,?,?,?)
         ON DUPLICATE KEY UPDATE route_id=VALUES(route_id), pickup_point=VALUES(pickup_point), notes=VALUES(notes)`,
        [student_id, route_id||null, pickup_point||'', notes||''],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Transport assigned." });
        }
    );
});

app.get("/portal/transport", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json(null);
    connection.query(
        `SELECT tr.route_name, tr.bus_number, tr.driver_name, tr.driver_phone,
                tr.pickup_time, tr.dropoff_time, tr.notes AS route_notes,
                ta.pickup_point, ta.notes AS assignment_notes
         FROM transport_assignments ta
         JOIN transport_routes tr ON tr.id = ta.route_id
         WHERE ta.student_id = ? LIMIT 1`,
        [sid], (err, rows) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json(rows[0] || null);
        }
    );
});

/* ---------- GALLERY ---------- */
app.get("/portal/gallery", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query(
        "SELECT id, title, caption, image_type, uploaded_by, created_at FROM school_gallery ORDER BY created_at DESC LIMIT 50",
        (err, rows) => {
            if (err) return res.status(500).json([]);
            res.json(rows);
        }
    );
});

app.get("/api/gallery/image/:id", requireLogin, (req, res) => {
    connection.query("SELECT image_data, image_type FROM school_gallery WHERE id = ? LIMIT 1", [req.params.id], (err, rows) => {
        if (err || !rows.length || !rows[0].image_data) return res.status(404).end();
        res.set("Content-Type", rows[0].image_type || "image/jpeg");
        res.set("Cache-Control", "public, max-age=86400");
        res.send(rows[0].image_data);
    });
});

app.get("/portal/gallery/image/:id", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).end();
    connection.query("SELECT image_data, image_type FROM school_gallery WHERE id = ? LIMIT 1", [req.params.id], (err, rows) => {
        if (err || !rows.length || !rows[0].image_data) return res.status(404).end();
        res.set("Content-Type", rows[0].image_type || "image/jpeg");
        res.set("Cache-Control", "public, max-age=86400");
        res.send(rows[0].image_data);
    });
});

app.get("/api/gallery", requireLogin, (req, res) => {
    connection.query("SELECT id, title, caption, image_type, uploaded_by, created_at FROM school_gallery ORDER BY created_at DESC LIMIT 100", (err, rows) => {
        if (err) return res.status(500).json([]);
        res.json(rows);
    });
});

const galleryUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 }, fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith("image/")) cb(null, true); else cb(new Error("Images only"));
}});

app.post("/api/gallery", requireLogin, writeRateLimit, galleryUpload.single("image"), (req, res) => {
    if (!req.file) return res.status(400).json({ message: "Image file required." });
    const { title, caption } = req.body;
    connection.query(
        "INSERT INTO school_gallery (title, caption, image_data, image_type, uploaded_by) VALUES (?,?,?,?,?)",
        [title||'', caption||null, req.file.buffer, req.file.mimetype, req.session.username||'Admin'],
        (err, result) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Photo uploaded.", id: result.insertId });
        }
    );
});

app.delete("/api/gallery/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM school_gallery WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Deleted." });
    });
});

/* ---------- LEAVE REQUESTS ---------- */
app.get("/portal/leave", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query("SELECT * FROM leave_requests WHERE student_id = ? ORDER BY created_at DESC LIMIT 20", [sid], (err, rows) => {
        if (err) return res.status(500).json([]);
        res.json(rows);
    });
});

app.post("/portal/leave", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.status(401).json({ message: "Not logged in" });
    const { reason, from_date, to_date } = req.body;
    if (!reason || !from_date || !to_date) return res.status(400).json({ message: "Reason, from date and to date are required." });
    connection.query("SELECT full_name, class_name FROM students WHERE student_id = ? LIMIT 1", [sid], (err, rows) => {
        if (err || !rows.length) return res.status(404).json({ message: "Student not found." });
        connection.query(
            "INSERT INTO leave_requests (student_id, student_name, class_name, reason, from_date, to_date) VALUES (?,?,?,?,?,?)",
            [sid, rows[0].full_name, rows[0].class_name, reason, from_date, to_date],
            (err2) => {
                if (err2) return res.status(500).json({ message: "Database error" });
                res.json({ message: "Leave request submitted. The school will review it." });
            }
        );
    });
});

app.get("/api/leave-requests", requireLogin, (req, res) => {
    const status = req.query.status;
    const sql = status
        ? "SELECT * FROM leave_requests WHERE status = ? ORDER BY created_at DESC LIMIT 100"
        : "SELECT * FROM leave_requests ORDER BY created_at DESC LIMIT 100";
    connection.query(sql, status ? [status] : [], (err, rows) => {
        if (err) return res.status(500).json([]);
        res.json(rows);
    });
});

app.post("/api/leave-requests/:id/status", requireLogin, writeRateLimit, (req, res) => {
    const { status, admin_note } = req.body;
    const valid = ["approved", "rejected", "pending"];
    if (!valid.includes(status)) return res.status(400).json({ message: "Invalid status." });
    connection.query(
        "UPDATE leave_requests SET status = ?, admin_note = ? WHERE id = ?",
        [status, admin_note||null, req.params.id],
        (err) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Updated." });
        }
    );
});

/* ---------- BROADCASTS ---------- */
app.get("/portal/broadcasts", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query("SELECT id, title, message, pinned, posted_by, created_at FROM broadcasts ORDER BY pinned DESC, created_at DESC LIMIT 30", (err, rows) => {
        if (err) return res.status(500).json([]);
        res.json(rows);
    });
});

app.get("/api/broadcasts", requireLogin, (req, res) => {
    connection.query("SELECT * FROM broadcasts ORDER BY pinned DESC, created_at DESC LIMIT 100", (err, rows) => {
        if (err) return res.status(500).json([]);
        res.json(rows);
    });
});

app.post("/api/broadcasts", requireLogin, requireAdmin, writeRateLimit, (req, res) => {
    const { title, message, pinned } = req.body;
    if (!title || !message) return res.status(400).json({ message: "Title and message are required." });
    connection.query(
        "INSERT INTO broadcasts (title, message, pinned, posted_by) VALUES (?,?,?,?)",
        [title, message, pinned ? 1 : 0, req.session.username||'Admin'],
        (err, result) => {
            if (err) return res.status(500).json({ message: "Database error" });
            res.json({ message: "Broadcast sent.", id: result.insertId });
        }
    );
});

app.delete("/api/broadcasts/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM broadcasts WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Deleted." });
    });
});

/* Serve new admin pages */
app.get("/homework.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "homework.html")));
app.get("/gallery.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "gallery.html")));
app.get("/transport.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "transport.html")));
app.get("/leave-requests.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "leave-requests.html")));
app.get("/broadcast.html", requireLogin, requireAdmin, (req, res) => res.sendFile(path.join(__dirname, "broadcast.html")));

app.get("/health.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "health.html")));
app.get("/library.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "library.html")));
app.get("/remarks.html", requireLogin, (req, res) => res.sendFile(path.join(__dirname, "remarks.html")));

/* =====================================================================
   PACK 84 — Health clinic, library, term remarks
   ===================================================================== */

app.get("/api/health-records", requireLogin, (req, res) => {
    const cls = (req.query.class_name || "").trim();
    // COLLATE hint: student_health may still carry the database-default
    // collation on old installs; forcing utf8mb4_unicode_ci makes the JOIN
    // with students immune to "Illegal mix of collations" -> empty list.
    let sql = `SELECT s.student_id, s.full_name, s.class_name, s.gender,
                      h.blood_group, h.allergies, h.medical_conditions,
                      h.emergency_contact_name, h.emergency_contact_phone, h.notes,
                      h.height_cm, h.weight_kg, h.bmi, h.genotype,
                      h.doctor_name, h.doctor_phone, h.insurance_no,
                      h.current_medications, h.last_checkup, h.special_needs,
                      h.updated_at
               FROM students s
               LEFT JOIN student_health h ON h.student_id = s.student_id COLLATE utf8mb4_unicode_ci`;
    const params = [];
    if (cls) { sql += " WHERE s.class_name = ?"; params.push(cls); }
    sql += " ORDER BY s.class_name, s.full_name LIMIT 800";
    connection.query(sql, params, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows || []);
    });
});

app.get("/api/clinic-visits/:studentId", requireLogin, (req, res) => {
    connection.query(
        "SELECT * FROM clinic_visits WHERE student_id = ? ORDER BY visit_date DESC, id DESC LIMIT 80",
        [req.params.studentId],
        (err, rows) => {
            if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
            res.json(rows || []);
        }
    );
});

app.post("/api/clinic-visits/:studentId", requireLogin, writeRateLimit, (req, res) => {
    const sid = req.params.studentId;
    const visit_date = (req.body.visit_date || "").trim() || new Date().toISOString().slice(0, 10);
    const complaint = (req.body.complaint || "").trim();
    const treatment = (req.body.treatment || "").trim();
    if (!complaint) return res.status(400).json({ message: "Write the complaint / reason for visit." });
    connection.query(
        "INSERT INTO clinic_visits (student_id, visit_date, complaint, treatment, recorded_by) VALUES (?,?,?,?,?)",
        [sid, visit_date, complaint, treatment, req.session.username || ""],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Clinic visit saved.", id: result.insertId });
        }
    );
});

app.delete("/api/clinic-visits/:id", requireLogin, (req, res) => {
    connection.query("DELETE FROM clinic_visits WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Deleted." });
    });
});

app.get("/api/vaccinations/:studentId", requireLogin, (req, res) => {
    connection.query(
        "SELECT * FROM vaccinations WHERE student_id = ? ORDER BY given_date DESC, id DESC LIMIT 80",
        [req.params.studentId],
        (err, rows) => {
            if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
            res.json(rows || []);
        }
    );
});

app.post("/api/vaccinations/:studentId", requireLogin, writeRateLimit, (req, res) => {
    const sid = req.params.studentId;
    const vaccine_name = (req.body.vaccine_name || "").trim();
    const given_date = (req.body.given_date || "").trim() || null;
    const notes = (req.body.notes || "").trim();
    if (!vaccine_name) return res.status(400).json({ message: "Vaccine name is required." });
    connection.query(
        "INSERT INTO vaccinations (student_id, vaccine_name, given_date, notes, recorded_by) VALUES (?,?,?,?,?)",
        [sid, vaccine_name, given_date, notes, req.session.username || ""],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Vaccination saved.", id: result.insertId });
        }
    );
});

app.delete("/api/vaccinations/:id", requireLogin, (req, res) => {
    connection.query("DELETE FROM vaccinations WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json({ message: "Deleted." });
    });
});

app.get("/portal/health-extra", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json({ visits: [], vaccinations: [] });
    connection.query("SELECT visit_date, complaint, treatment FROM clinic_visits WHERE student_id = ? ORDER BY visit_date DESC LIMIT 20", [sid], (err, visits) => {
        connection.query("SELECT vaccine_name, given_date, notes FROM vaccinations WHERE student_id = ? ORDER BY given_date DESC LIMIT 20", [sid], (err2, vax) => {
            res.json({ visits: visits || [], vaccinations: vax || [] });
        });
    });
});

app.get("/api/library/books", requireLogin, (req, res) => {
    connection.query("SELECT * FROM library_books ORDER BY title LIMIT 400", (err, rows) => {
        if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
        res.json(rows || []);
    });
});

app.post("/api/library/books", requireLogin, writeRateLimit, (req, res) => {
    const title = (req.body.title || "").trim();
    const author = (req.body.author || "").trim();
    const isbn = (req.body.isbn || "").trim();
    const copies = Math.max(1, parseInt(req.body.copies, 10) || 1);
    if (!title) return res.status(400).json({ message: "Book title is required." });
    connection.query(
        "INSERT INTO library_books (title, author, isbn, copies, available) VALUES (?,?,?,?,?)",
        [title, author, isbn, copies, copies],
        (err, result) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Book added.", id: result.insertId });
        }
    );
});

app.delete("/api/library/books/:id", requireLogin, requireAdmin, (req, res) => {
    connection.query("DELETE FROM library_books WHERE id = ?", [req.params.id], (err) => {
        if (err) return res.status(500).json({ message: "Database error" });
        connection.query("DELETE FROM library_loans WHERE book_id = ? AND returned_at IS NULL", [req.params.id], () => {});
        res.json({ message: "Book deleted." });
    });
});

app.get("/api/library/loans", requireLogin, (req, res) => {
    const open = String(req.query.open || "") === "1";
    const sql = open
        ? `SELECT l.*, b.title, b.author, s.full_name, s.class_name
           FROM library_loans l
           JOIN library_books b ON b.id = l.book_id
           LEFT JOIN students s ON s.student_id = l.student_id COLLATE utf8mb4_unicode_ci
           WHERE l.returned_at IS NULL
           ORDER BY l.issued_at DESC LIMIT 300`
        : `SELECT l.*, b.title, b.author, s.full_name, s.class_name
           FROM library_loans l
           JOIN library_books b ON b.id = l.book_id
           LEFT JOIN students s ON s.student_id = l.student_id COLLATE utf8mb4_unicode_ci
           ORDER BY l.issued_at DESC LIMIT 300`;
    connection.query(sql, (err, rows) => {
        if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
        res.json(rows || []);
    });
});

app.post("/api/library/issue", requireLogin, writeRateLimit, (req, res) => {
    const bookId = Number(req.body.book_id);
    const studentId = (req.body.student_id || "").trim();
    const due = (req.body.due_date || "").trim() || null;
    if (!bookId || !studentId) return res.status(400).json({ message: "Book and student are required." });
    connection.query("SELECT available FROM library_books WHERE id = ?", [bookId], (err, rows) => {
        if (err || !rows.length) return res.status(404).json({ message: "Book not found." });
        if (Number(rows[0].available) < 1) return res.status(400).json({ message: "No copies available." });
        const issued = new Date().toISOString().slice(0, 10);
        connection.query(
            "INSERT INTO library_loans (book_id, student_id, issued_at, due_date, issued_by) VALUES (?,?,?,?,?)",
            [bookId, studentId, issued, due, req.session.username || ""],
            (err2) => {
                if (err2) { console.log(err2); return res.status(500).json({ message: "Database error" }); }
                connection.query("UPDATE library_books SET available = GREATEST(available - 1, 0) WHERE id = ?", [bookId], () => {});
                res.json({ message: "Book issued." });
            }
        );
    });
});

app.post("/api/library/return/:id", requireLogin, writeRateLimit, (req, res) => {
    const id = Number(req.params.id);
    connection.query("SELECT book_id, returned_at FROM library_loans WHERE id = ?", [id], (err, rows) => {
        if (err || !rows.length) return res.status(404).json({ message: "Loan not found." });
        if (rows[0].returned_at) return res.status(400).json({ message: "Already returned." });
        const today = new Date().toISOString().slice(0, 10);
        connection.query("UPDATE library_loans SET returned_at = ? WHERE id = ?", [today, id], (err2) => {
            if (err2) return res.status(500).json({ message: "Database error" });
            connection.query("UPDATE library_books SET available = LEAST(available + 1, copies) WHERE id = ?", [rows[0].book_id], () => {});
            res.json({ message: "Book returned." });
        });
    });
});

app.get("/portal/library", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query(
        `SELECT l.id, l.issued_at, l.due_date, l.returned_at, b.title, b.author
         FROM library_loans l JOIN library_books b ON b.id = l.book_id
         WHERE l.student_id = ? ORDER BY l.issued_at DESC LIMIT 40`,
        [sid],
        (err, rows) => {
            if (err) return res.json([]);
            res.json(rows || []);
        }
    );
});

app.get("/api/remarks", requireLogin, (req, res) => {
    const cls = (req.query.class_name || "").trim();
    const term = (req.query.term || "").trim();
    const session = (req.query.session || "").trim();
    const q = `SELECT s.student_id, s.full_name, s.class_name,
                      r.teacher_remark, r.principal_remark, r.updated_at
               FROM students s
               LEFT JOIN term_remarks r
                 ON r.student_id = s.student_id COLLATE utf8mb4_unicode_ci
                    AND r.term = ? AND r.session = ?
               ${cls ? "WHERE s.class_name = ?" : ""}
               ORDER BY s.full_name LIMIT 500`;
    const p = cls ? [term, session, cls] : [term, session];
    connection.query(q, p, (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows || []);
    });
});

app.post("/api/remarks/:studentId", requireLogin, writeRateLimit, (req, res) => {
    const sid = req.params.studentId;
    const term = (req.body.term || "").trim();
    const session = (req.body.session || "").trim();
    const teacher_remark = (req.body.teacher_remark || "").trim();
    const principal_remark = (req.body.principal_remark || "").trim();
    if (!term || !session) return res.status(400).json({ message: "Term and session are required." });
    connection.query(
        `INSERT INTO term_remarks (student_id, term, session, teacher_remark, principal_remark, recorded_by)
         VALUES (?,?,?,?,?,?)
         ON DUPLICATE KEY UPDATE teacher_remark = VALUES(teacher_remark), principal_remark = VALUES(principal_remark), recorded_by = VALUES(recorded_by)`,
        [sid, term, session, teacher_remark, principal_remark, req.session.username || ""],
        (err) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json({ message: "Remark saved." });
        }
    );
});

app.get("/portal/remarks", (req, res) => {
    const sid = req.session && req.session.portalStudentId;
    if (!sid) return res.json([]);
    connection.query(
        "SELECT term, session, teacher_remark, principal_remark, updated_at FROM term_remarks WHERE student_id = ? ORDER BY session DESC, term DESC LIMIT 20",
        [sid],
        (err, rows) => {
            if (err) return res.json([]);
            res.json(rows || []);
        }
    );
});

/* =====================================================================
   PACK 86 — Analytics, Grade Book, Class Management, Staff Chat
   Additive routes only. Existing routes / tables / auth are untouched.
   ===================================================================== */

function amsGradeForTotal(total) {
    const t = Number(total) || 0;
    if (t >= 70) return "A";
    if (t >= 60) return "B";
    if (t >= 50) return "C";
    if (t >= 45) return "D";
    if (t >= 40) return "E";
    return "F";
}

/* ---------- Analytics (admin only) ---------- */
app.get("/api/analytics", requireLogin, requireAdmin, (req, res) => {
    const out = { subjects: [], attendance: [], fees: [], classes: [], session: "" };

    function finish() { res.json(out); }

    connection.query(
        `SELECT subject, ROUND(AVG(total), 1) AS avg_score, COUNT(*) AS n
         FROM results WHERE subject IS NOT NULL AND subject <> ''
         GROUP BY subject ORDER BY avg_score ASC LIMIT 40`,
        (err, rows) => {
            if (!err && rows) out.subjects = rows;

            connection.query(
                `SELECT YEARWEEK(att_date, 1) AS yw,
                        SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) AS present,
                        COUNT(*) AS total
                 FROM attendance
                 WHERE att_date >= DATE_SUB(CURDATE(), INTERVAL 10 WEEK)
                 GROUP BY yw ORDER BY yw ASC`,
                (e2, weeks) => {
                    if (!e2 && weeks) {
                        out.attendance = weeks.map((w, i) => {
                            const tot = Number(w.total) || 0;
                            const present = Number(w.present) || 0;
                            return {
                                yw: w.yw,
                                label: "W" + (i + 1),
                                pct: tot ? Math.round((present / tot) * 100) : 0,
                                present: present,
                                total: tot
                            };
                        });
                    }

                    connection.query(
                        `SELECT class_name, ROUND(AVG(total), 1) AS avg_score,
                                COUNT(DISTINCT student_id) AS students, COUNT(*) AS scores
                         FROM results
                         GROUP BY class_name ORDER BY avg_score DESC LIMIT 40`,
                        (e3, cls) => {
                            if (!e3 && cls) out.classes = cls;

                            connection.query(
                                "SELECT session FROM sessions WHERE is_current = 1 LIMIT 1",
                                (e4, sessRows) => {
                                    const sessionName = (!e4 && sessRows && sessRows[0] && sessRows[0].session)
                                        ? sessRows[0].session
                                        : "";
                                    out.session = sessionName;

                                    function feeForSession(session) {
                                        if (!session) return finish();
                                        connection.query(
                                            `SELECT COALESCE(SUM(fs.amount * c.cnt), 0) AS expected
                                             FROM fee_structure2 fs
                                             JOIN (SELECT class_name, COUNT(*) AS cnt FROM students GROUP BY class_name) c
                                               ON c.class_name = fs.class_name
                                             WHERE fs.session = ?`,
                                            [session],
                                            (e5, expRows) => {
                                                const expected = (!e5 && expRows && expRows[0]) ? Number(expRows[0].expected) || 0 : 0;
                                                connection.query(
                                                    `SELECT DATE_FORMAT(paid_at, '%Y-%m') AS ym, SUM(amount) AS collected
                                                     FROM fee_payments WHERE session = ?
                                                     GROUP BY ym ORDER BY ym ASC`,
                                                    [session],
                                                    (e6, months) => {
                                                        if (e6 || !months || !months.length) {
                                                            out.fees = expected
                                                                ? [{ label: session, collected: 0, outstanding: expected }]
                                                                : [];
                                                            return finish();
                                                        }
                                                        let running = 0;
                                                        out.fees = months.map((m) => {
                                                            running += Number(m.collected) || 0;
                                                            const leftover = Math.max(0, expected - running);
                                                            const parts = String(m.ym || "").split("-");
                                                            const label = parts.length === 2
                                                                ? ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][Number(parts[1]) - 1] + " " + parts[0].slice(2)
                                                                : m.ym;
                                                            return {
                                                                label: label,
                                                                collected: Number(m.collected) || 0,
                                                                outstanding: leftover
                                                            };
                                                        });
                                                        finish();
                                                    }
                                                );
                                            }
                                        );
                                    }

                                    if (sessionName) return feeForSession(sessionName);
                                    connection.query(
                                        "SELECT session FROM fee_payments ORDER BY paid_at DESC LIMIT 1",
                                        (e7, last) => {
                                            const fallback = (!e7 && last && last[0]) ? last[0].session : "";
                                            out.session = fallback;
                                            feeForSession(fallback);
                                        }
                                    );
                                }
                            );
                        }
                    );
                }
            );
        }
    );
});

/* ---------- Grade Book ---------- */
/* FIX (pack 87): exact class_name = ? hid most of the class when Arabic
   names differed by tashkeel/spaces, and results stored under a slightly
   different class spelling never attached to a cell — so many students
   appeared with no editor. Matching now uses classNamesMatch (same as
   the publish gate) and every student in the class gets a row. */
function amsSidKey(s) {
    return String(s || "").trim().toLowerCase();
}
function amsBuildGradebook(className, term, session, cb) {
    function fail(err) {
        console.log(err);
        cb(err || new Error("Database error"));
    }
    function withStudents(allStudents) {
        connection.query(
            "SELECT subject_name, class_name, is_active FROM subjects",
            (e2, allSubs) => {
                const takeSubs = (subs) => {
                    connection.query(
                        `SELECT id, student_id, student_name, class_name, subject, first_test, second_test,
                                note_score, attendance_score, ca_score, exam_score, total, grade
                         FROM results WHERE TRIM(term) = TRIM(?) AND TRIM(session) = TRIM(?)`,
                        [term, session],
                        (e3, results) => {
                            if (e3) return fail(e3);
                            finish(allStudents || [], subs || [], results || []);
                        }
                    );
                };
                if (e2 && e2.code === "ER_BAD_FIELD_ERROR") {
                    return connection.query("SELECT subject_name, class_name FROM subjects", (e2b, subs2) => {
                        if (e2b) return fail(e2b);
                        takeSubs(subs2 || []);
                    });
                }
                if (e2) return fail(e2);
                takeSubs(allSubs || []);
            }
        );
    }
    function finish(allStudents, allSubs, results) {
        const classStudents = allStudents.filter((s) => classNamesMatch(s.class_name, className));
        const inClassIds = {};
        classStudents.forEach((s) => { inClassIds[amsSidKey(s.student_id)] = 1; });
        const relevantResults = results.filter((r) =>
            classNamesMatch(r.class_name, className) || inClassIds[amsSidKey(r.student_id)]
        );
        const seen = {};
        classStudents.forEach((s) => { seen[amsSidKey(s.student_id)] = s; });
        relevantResults.forEach((r) => {
            const k = amsSidKey(r.student_id);
            if (!seen[k]) {
                const roster = allStudents.find((s) => amsSidKey(s.student_id) === k);
                seen[k] = roster || {
                    student_id: r.student_id,
                    full_name: r.student_name || r.student_id,
                    class_name: r.class_name
                };
            }
        });
        const students = Object.keys(seen).map((k) => seen[k]).sort((a, b) =>
            String(a.full_name || "").localeCompare(String(b.full_name || ""), undefined, { sensitivity: "base" })
        );
        const subSeen = {};
        let subjects = [];
        (allSubs || []).forEach((s) => {
            if (!classNamesMatch(s.class_name, className)) return;
            if (s.is_active !== undefined && s.is_active !== null && Number(s.is_active) === 0) return;
            const name = s.subject_name;
            const k = normalizeClassName(name);
            if (!k || subSeen[k]) return;
            subSeen[k] = 1;
            subjects.push(name);
        });
        relevantResults.forEach((r) => {
            const k = normalizeClassName(r.subject);
            if (k && !subSeen[k]) { subSeen[k] = 1; subjects.push(r.subject); }
        });
        subjects.sort((a, b) => String(a).localeCompare(String(b), undefined, { sensitivity: "base" }));
        cb(null, {
            class_name: className,
            term: term,
            session: session,
            students: students,
            subjects: subjects,
            results: relevantResults
        });
    }
    connection.query(
        "SELECT student_id, full_name, class_name, status FROM students ORDER BY full_name",
        (err, rows) => {
            if (err && err.code === "ER_BAD_FIELD_ERROR") {
                return connection.query(
                    "SELECT student_id, full_name, class_name FROM students ORDER BY full_name",
                    (e2, rows2) => { if (e2) return fail(e2); withStudents(rows2 || []); }
                );
            }
            if (err) return fail(err);
            withStudents(rows || []);
        }
    );
}

app.get("/api/gradebook", requireLogin, (req, res) => {
    const className = String(req.query.class || req.query.class_name || "").trim();
    const term = String(req.query.term || "").trim();
    const session = String(req.query.session || "").trim();
    if (!className || !term || !session) {
        return res.status(400).json({ message: "Class, term and session are required." });
    }
    amsBuildGradebook(className, term, session, (err, pack) => {
        if (err) return res.status(500).json({ message: "Database error" });
        res.json(pack);
    });
});

app.get("/api/gradebook/export", requireLogin, (req, res) => {
    const className = String(req.query.class || req.query.class_name || "").trim();
    const term = String(req.query.term || "").trim();
    const session = String(req.query.session || "").trim();
    if (!className || !term || !session) {
        return res.status(400).json({ message: "Class, term and session are required." });
    }
    amsBuildGradebook(className, term, session, (err, pack) => {
        if (err) return res.status(500).json({ message: "Database error" });
        const map = {};
        (pack.results || []).forEach((r) => {
            map[amsSidKey(r.student_id) + "||" + normalizeClassName(r.subject)] = r.total;
        });
        const header = ["Student ID", "Student Name"].concat(pack.subjects);
        const aoa = [header];
        (pack.students || []).forEach((st) => {
            const row = [st.student_id, st.full_name];
            pack.subjects.forEach((sub) => {
                const v = map[amsSidKey(st.student_id) + "||" + normalizeClassName(sub)];
                row.push(v == null ? "" : Number(v));
            });
            aoa.push(row);
        });
        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.aoa_to_sheet(aoa);
        XLSX.utils.book_append_sheet(wb, ws, "Grade Book");
        const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
        const safe = className.replace(/[^a-zA-Z0-9_\\-]+/g, "_");
        res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        res.setHeader("Content-Disposition", 'attachment; filename="gradebook-' + safe + '.xlsx"');
        res.send(buf);
    });
});

/* FIX (pack 87): dedicated upsert so every student/subject cell can be
   saved without the 30-writes/15-min cap on /save-result, and so we
   UPDATE the existing row even when student_id / subject spelling
   differs by case, spaces or tashkeel (instead of inserting a ghost). */
app.post("/api/gradebook/cell", requireLogin, (req, res) => {
    const student_id = String(req.body.student_id || "").trim();
    const student_name = String(req.body.student_name || "").trim();
    const class_name = String(req.body.class_name || "").trim();
    const term = String(req.body.term || "").trim();
    const session = String(req.body.session || "").trim();
    const subject = String(req.body.subject || "").trim();
    if (!student_id || !class_name || !term || !session || !subject) {
        return res.status(400).json({ message: "Student, class, term, session and subject are required." });
    }
    const clamp = (n, max) => {
        const v = Number(n);
        if (!isFinite(v)) return 0;
        return Math.max(0, Math.min(max, v));
    };
    const first_test = clamp(req.body.first_test, 10);
    const second_test = clamp(req.body.second_test, 10);
    const note_score = clamp(req.body.note_score, 10);
    const attendance_score = clamp(req.body.attendance_score, 10);
    const ca_score = clamp(req.body.ca_score, 40);
    const exam_score = clamp(req.body.exam_score, 60);
    let total = Number(req.body.total_score);
    if (!isFinite(total)) total = ca_score + exam_score;
    total = Math.max(0, Math.min(100, total));
    const grade = String(req.body.grade || amsGradeForTotal(total)).slice(0, 10);

    connection.query(
        `SELECT id, subject FROM results
         WHERE (TRIM(student_id) = TRIM(?) OR LOWER(TRIM(student_id)) = LOWER(TRIM(?)))
           AND TRIM(term) = TRIM(?) AND TRIM(session) = TRIM(?)`,
        [student_id, student_id, term, session],
        (err, rows) => {
            if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
            const want = normalizeClassName(subject);
            const match = (rows || []).find((r) => normalizeClassName(r.subject) === want);
            if (match) {
                connection.query(
                    `UPDATE results SET
                        student_id = ?, student_name = ?, class_name = ?, subject = ?,
                        first_test = ?, second_test = ?, note_score = ?, attendance_score = ?,
                        ca_score = ?, exam_score = ?, total = ?, grade = ?
                     WHERE id = ?`,
                    [student_id, student_name, class_name, subject,
                     first_test, second_test, note_score, attendance_score,
                     ca_score, exam_score, total, grade, match.id],
                    (uErr) => {
                        if (uErr) { console.log(uErr); return res.status(500).json({ message: "Could not update that score." }); }
                        res.json({ message: "Saved", id: match.id, total: total, grade: grade, ca_score: ca_score, exam_score: exam_score });
                    }
                );
            } else {
                connection.query(
                    `INSERT INTO results
                        (student_id, student_name, class_name, term, session, subject,
                         first_test, second_test, note_score, attendance_score,
                         ca_score, exam_score, total, grade)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
                    [student_id, student_name, class_name, term, session, subject,
                     first_test, second_test, note_score, attendance_score,
                     ca_score, exam_score, total, grade],
                    (iErr, result) => {
                        if (iErr) { console.log(iErr); return res.status(500).json({ message: "Could not save that score." }); }
                        res.json({ message: "Saved", id: result.insertId, total: total, grade: grade, ca_score: ca_score, exam_score: exam_score });
                    }
                );
            }
        }
    );
});

/* ---------- Class Management ---------- */
app.get("/api/manage-classes", requireLogin, (req, res) => {
    connection.query(
        `SELECT c.id, c.class_name, COUNT(s.student_id) AS student_count
         FROM classes c
         LEFT JOIN students s ON s.class_name = c.class_name
         GROUP BY c.id, c.class_name
         ORDER BY c.class_name`,
        (err, rows) => {
            if (err) {
                console.log(err);
                return connection.query("SELECT id, class_name FROM classes ORDER BY class_name", (e2, plain) => {
                    if (e2) return res.status(500).json({ message: "Database error" });
                    res.json((plain || []).map((r) => ({ id: r.id, class_name: r.class_name, student_count: 0 })));
                });
            }
            res.json(rows || []);
        }
    );
});

app.put("/api/manage-classes/:id", requireLogin, writeRateLimit, (req, res) => {
    const id = Number(req.params.id);
    const nextName = String(req.body.class_name || "").trim();
    if (!id || !nextName) return res.status(400).json({ message: "Class name is required." });
    connection.query("SELECT class_name FROM classes WHERE id = ?", [id], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "Class not found." });
        const oldName = rows[0].class_name;
        if (oldName === nextName) return res.json({ message: "Name is unchanged." });
        connection.query("SELECT id FROM classes WHERE class_name = ? AND id <> ?", [nextName, id], (e2, clash) => {
            if (e2) { console.log(e2); return res.status(500).json({ message: "Database error" }); }
            if (clash && clash.length) return res.status(400).json({ message: "That class name already exists." });
            connection.query("UPDATE classes SET class_name = ? WHERE id = ?", [nextName, id], (e3) => {
                if (e3) {
                    if (e3.code === "ER_DUP_ENTRY") return res.status(400).json({ message: "That class name already exists." });
                    console.log(e3);
                    return res.status(500).json({ message: "Database error" });
                }
                const tables = ["students", "results", "attendance", "subjects"];
                let i = 0;
                (function nextTable() {
                    if (i >= tables.length) {
                        return res.json({ message: "Class renamed. Students, results, attendance and subjects were updated." });
                    }
                    const tbl = tables[i++];
                    connection.query("UPDATE `" + tbl + "` SET class_name = ? WHERE class_name = ?", [nextName, oldName], (uErr) => {
                        if (uErr) console.log("rename " + tbl + " notice:", uErr.code || uErr.message);
                        nextTable();
                    });
                })();
            });
        });
    });
});

app.delete("/api/manage-classes/:id", requireLogin, writeRateLimit, (req, res) => {
    const id = Number(req.params.id);
    if (!id) return res.status(400).json({ message: "Class is required." });
    connection.query("SELECT class_name FROM classes WHERE id = ?", [id], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "Class not found." });
        const name = rows[0].class_name;
        connection.query("SELECT COUNT(*) AS c FROM students WHERE class_name = ?", [name], (e2, cnt) => {
            if (e2) { console.log(e2); return res.status(500).json({ message: "Database error" }); }
            if (cnt && cnt[0] && Number(cnt[0].c) > 0) {
                return res.status(400).json({ message: "This class still has students. Move or remove them first." });
            }
            connection.query("DELETE FROM classes WHERE id = ?", [id], (e3) => {
                if (e3) { console.log(e3); return res.status(500).json({ message: "Database error" }); }
                res.json({ message: "Class deleted." });
            });
        });
    });
});

/* ---------- Staff internal messaging ---------- */
app.get("/api/staff-chat/users", requireLogin, (req, res) => {
    connection.query("SELECT id, username, role FROM users ORDER BY username", (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        res.json(rows || []);
    });
});

app.get("/api/staff-chat", requireLogin, (req, res) => {
    const me = req.session.username;
    connection.query(
        `SELECT id, sender_type, sender_ref, sender_name, recipient_type, recipient_ref,
                body, created_at, read_at, thread, kind, duration, message_type
         FROM messages
         WHERE message_type = 'staff'
           AND ((sender_ref = ? AND recipient_ref <> '') OR recipient_ref = ?)
         ORDER BY created_at ASC LIMIT 800`,
        [me, me],
        (err, rows) => {
            if (err && err.code === "ER_BAD_FIELD_ERROR") {
                return connection.query(
                    `SELECT id, sender_type, sender_ref, sender_name, recipient_type, recipient_ref,
                            body, created_at, read_at, thread, kind, duration
                     FROM messages
                     WHERE thread = 'staff'
                       AND ((sender_ref = ?) OR recipient_ref = ?)
                     ORDER BY created_at ASC LIMIT 800`,
                    [me, me],
                    (e2, rows2) => {
                        if (e2) { if (e2.code === "ER_NO_SUCH_TABLE") return res.json([]); return res.status(500).json({ message: "Database error" }); }
                        res.json(rows2 || []);
                    }
                );
            }
            if (err) { if (err.code === "ER_NO_SUCH_TABLE") return res.json([]); console.log(err); return res.status(500).json({ message: "Database error" }); }
            res.json(rows || []);
        }
    );
});

app.post("/api/staff-chat", requireLogin, writeRateLimit, (req, res) => {
    const me = req.session.username;
    const to = String(req.body.to || "").trim();
    const body = String(req.body.body || "").trim().slice(0, 2000);
    if (!to || !body) return res.status(400).json({ message: "Recipient and message are required." });
    if (to === me) return res.status(400).json({ message: "You cannot message yourself." });
    connection.query("SELECT username, role FROM users WHERE username = ? LIMIT 1", [to], (err, rows) => {
        if (err) { console.log(err); return res.status(500).json({ message: "Database error" }); }
        if (!rows.length) return res.status(404).json({ message: "That staff account was not found." });
        connection.query(
            `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread, message_type)
             VALUES ('staff', ?, ?, 'staff', ?, '', ?, 'staff', 'staff')`,
            [me, me + " (" + (req.session.role || "staff") + ")", to, body],
            (iErr) => {
                if (iErr && iErr.code === "ER_BAD_FIELD_ERROR") {
                    return connection.query(
                        `INSERT INTO messages (sender_type, sender_ref, sender_name, recipient_type, recipient_ref, recipient_class, body, thread)
                         VALUES ('staff', ?, ?, 'staff', ?, '', ?, 'staff')`,
                        [me, me + " (" + (req.session.role || "staff") + ")", to, body],
                        (iErr2) => {
                            if (iErr2) { console.log(iErr2); return res.status(500).json({ message: "Database error" }); }
                            res.json({ message: "Message sent." });
                        }
                    );
                }
                if (iErr) { console.log(iErr); return res.status(500).json({ message: "Database error" }); }
                try {
                    amsPushSend("staff", [to], {
                        title: "Staff message from " + me,
                        body: body.slice(0, 90),
                        url: "/staff-chat.html",
                        tag: "staff-" + me
                    });
                } catch (e) { /* push is optional */ }
                res.json({ message: "Message sent." });
            }
        );
    });
});

app.post("/api/staff-chat/read", requireLogin, (req, res) => {
    const me = req.session.username;
    const from = String(req.body.username || "").trim();
    if (!from) return res.json({ message: "ok" });
    connection.query(
        `UPDATE messages SET read_at = NOW()
         WHERE message_type = 'staff' AND sender_ref = ? AND recipient_ref = ? AND read_at IS NULL`,
        [from, me],
        (err) => {
            if (err && err.code === "ER_BAD_FIELD_ERROR") {
                return connection.query(
                    `UPDATE messages SET read_at = NOW()
                     WHERE thread = 'staff' AND sender_ref = ? AND recipient_ref = ? AND read_at IS NULL`,
                    [from, me],
                    () => res.json({ message: "ok" })
                );
            }
            res.json({ message: "ok" });
        }
    );
});

app.get("/api/staff-chat/unread", requireLogin, (req, res) => {
    const me = req.session.username;
    connection.query(
        "SELECT COUNT(*) AS c FROM messages WHERE message_type = 'staff' AND recipient_ref = ? AND read_at IS NULL",
        [me],
        (err, rows) => {
            if (err) {
                if (err.code === "ER_BAD_FIELD_ERROR" || err.code === "ER_NO_SUCH_TABLE") return res.json({ count: 0 });
                return res.status(500).json({ message: "Database error" });
            }
            res.json({ count: rows && rows[0] ? Number(rows[0].c) : 0 });
        }
    );
});

// Handle multer errors (bad file type, too large, etc.) with a clean response
app.use((err, req, res, next) => {
    const isMulter = err instanceof multer.MulterError
        || err.message === "Only JPG and PNG images are allowed."
        || err.message === "Only .xlsx, .xls, or .csv files are allowed."
        || err.message === "Only .xlsx or .xls workbooks are allowed.";
    if (isMulter) {
        /* JSON for the Third Term upload (and any fetch that asked for it)
           so the page never treats a plain-text multer reply as a network error. */
        const wantsJson = req.path === "/third-term-upload"
            || (req.headers.accept && String(req.headers.accept).indexOf("application/json") !== -1);
        if (wantsJson) {
            const msg = (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE")
                ? "The workbook is too large. Save a smaller copy and try again."
                : err.message;
            return res.status(400).json({ message: msg });
        }
        return res.status(400).send(err.message);
    }
    next(err);
});

/* Keepalive: ping the DB every 4 minutes so Aiven free tier never powers
   off while the server is running. (UptimeRobot keeps the server awake;
   this keeps the database connection alive.) */
setInterval(function () {
    connection.query("SELECT 1", function (err) {
        if (err) console.log("[keepalive] DB ping error:", err.message);
    });
}, 240000);

const PORT = process.env.PORT || 3000;

// NEW (Pack 64): Render 502 Bad Gateway compliance - bind explicitly to 0.0.0.0
// and increase keepAliveTimeout/headersTimeout to 120s as advised in Render docs.
const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT} bound to 0.0.0.0`);
});
server.keepAliveTimeout = 120000; // 120 seconds (Render official recommendation)
server.headersTimeout = 120000;   // 120 seconds
